create view EPIMV_10304 as select ID, PLT_10306."F_1" as F_1004364, PLT_10306."F_12349" as F_1004366 from PLT_10306
go

