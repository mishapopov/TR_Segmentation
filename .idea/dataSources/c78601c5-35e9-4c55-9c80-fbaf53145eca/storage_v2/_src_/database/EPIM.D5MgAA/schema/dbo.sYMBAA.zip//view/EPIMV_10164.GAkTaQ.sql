create view EPIMV_10164 as select ID, PLT_10166."F_1" as F_1004364, PLT_10166."F_12660" as F_1004679 from PLT_10166
go

