
  CREATE PROCEDURE [dbo].[TR_GetPriceTierIdsForRequestForValidationById]
  	@requestId VARCHAR(200),  -- Internal Record ID of the Request
  	@source VARCHAR(10)	-- Name of source (Build, Clone, Change, State)
    AS BEGIN

        -- TR_GetPriceIdsForRequestForValidationById - Retrieves the Price IDs of all linked records for the designated
        -- request record (by InternalRecordId) in the designated request pre-stage repository (Clone, Build, Change, or
        -- State).  Returns a commad-delimited list of all linked Price Ids of each repository.  If a repository has no
        -- linked records, return 'none' instead of the IDs.
        --
        --
        -- Example SQL:
        --
        --  EXEC TR_GetPriceIdsForRequestForValidationById '5770609','Build'
        --
        -- Workflow Activity:
        --
        -- EXEC TR_GetPriceIdsForRequestForValidationById '%itemIds%','%source%'

        DECLARE @sql NVARCHAR(max)
		DECLARE @productVariantPriceTier VARCHAR(max)


        -----------------------------------------------------------------------------
        -- Get list of product variant price records
        -----------------------------------------------------------------------------

        set @sql = 'SELECT @productVariantPriceTier = isnull(STUFF((select distinct '','' + cast(pvpt.InternalRecordId as VARCHAR) as [text()] ' +
		'from Request_' + @source + ' r ' +
		'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
		'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
		'join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID ' +
		'join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' pvpt on pvpt.Product_Price_ID = pvp.Product_Price_ID ' +
		'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
	print 'productVariantPriceTier - ' + @sql;

	-- Catch errors in case repository doesn't exist
	BEGIN TRY
		exec sp_executesql @sql, N'@productVariantPriceTier varchar(max) out', @productVariantPriceTier out
	END TRY
	BEGIN CATCH
	 	set @productVariantPriceTier = 'none';
	END CATCH


        -----------------------------------------------------------------------------
       	-- Return all ids
        -----------------------------------------------------------------------------

       	select @productVariantPriceTier as productVariantPriceTier

    END
  go

