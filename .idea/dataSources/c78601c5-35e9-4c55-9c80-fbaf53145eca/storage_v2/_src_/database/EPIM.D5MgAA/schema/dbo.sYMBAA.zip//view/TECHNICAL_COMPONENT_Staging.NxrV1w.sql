CREATE VIEW dbo.[TECHNICAL_COMPONENT_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004605 AS [Cloned_From_Technical_Component_ID], F_1004536 AS [Customer_Type], F_1004533 AS [Technical_Component_Description], F_1004530 AS [Technical_Component_ID], F_1004531 AS [Technical_Component_Name] FROM dbo.B_SNAPSHOT_10165 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on TECHNICAL_COMPONENT_Staging to dbadmin
go

grant select on TECHNICAL_COMPONENT_Staging to ewsys
go

grant select on TECHNICAL_COMPONENT_Staging to boomi
go

grant select on TECHNICAL_COMPONENT_Staging to informatica
go

grant select on TECHNICAL_COMPONENT_Staging to som
go

grant select on TECHNICAL_COMPONENT_Staging to apttus
go

grant select on TECHNICAL_COMPONENT_Staging to epmdev
go

grant select on TECHNICAL_COMPONENT_Staging to MDMAdmin
go

grant select on TECHNICAL_COMPONENT_Staging to produser1
go

grant select on TECHNICAL_COMPONENT_Staging to produser3
go

grant select on TECHNICAL_COMPONENT_Staging to produser2
go

grant select on TECHNICAL_COMPONENT_Staging to integration_team
go

grant select on TECHNICAL_COMPONENT_Staging to digital
go

