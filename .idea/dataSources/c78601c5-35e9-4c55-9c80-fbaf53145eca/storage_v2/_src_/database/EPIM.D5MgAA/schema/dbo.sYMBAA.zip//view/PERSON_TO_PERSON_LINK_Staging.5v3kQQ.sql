CREATE VIEW dbo.[PERSON_TO_PERSON_LINK_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005048 AS [Create_Date], F_1005049 AS [From_Enable_Person_ID], F_1005050 AS [Link_Type_Code], F_1005051 AS [To_Enable_Person_ID] FROM dbo.B_SNAPSHOT_10256 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PERSON_TO_PERSON_LINK_Staging to dbadmin
go

grant select on PERSON_TO_PERSON_LINK_Staging to ewsys
go

grant select on PERSON_TO_PERSON_LINK_Staging to boomi
go

grant select on PERSON_TO_PERSON_LINK_Staging to informatica
go

grant select on PERSON_TO_PERSON_LINK_Staging to som
go

grant select on PERSON_TO_PERSON_LINK_Staging to apttus
go

grant select on PERSON_TO_PERSON_LINK_Staging to epmdev
go

grant select on PERSON_TO_PERSON_LINK_Staging to MDMAdmin
go

grant select on PERSON_TO_PERSON_LINK_Staging to produser1
go

grant select on PERSON_TO_PERSON_LINK_Staging to produser3
go

grant select on PERSON_TO_PERSON_LINK_Staging to produser2
go

grant select on PERSON_TO_PERSON_LINK_Staging to integration_team
go

grant select on PERSON_TO_PERSON_LINK_Staging to digital
go

