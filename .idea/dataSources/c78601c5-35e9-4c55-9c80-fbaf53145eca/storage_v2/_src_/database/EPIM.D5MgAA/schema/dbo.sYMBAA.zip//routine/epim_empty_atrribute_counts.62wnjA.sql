--#BEGIN#
-- ******************************************
-- epim_empty_atrribute_counts
-- ******************************************

-- report of number of repository records that have empty atytributes by attributes
-- parameters:
--       repositoryName - repository name
CREATE PROCEDURE [dbo].[epim_empty_atrribute_counts] 
	@repositoryName NVARCHAR(255)
AS
BEGIN
	DECLARE @debug int;
	declare @attrName NVARCHAR(100)
	declare @fName NVARCHAR(20)
	declare @sqlStr NVARCHAR(max)
	declare @profileId int
	declare @repoId int
	declare @fId int
	declare @count int
	declare @ParmDefinition as NVARCHAR(MAX)

	DECLARE @Results TABLE
	(
	  Attribute nvarchar(255), 
	  EmptyCount int
	)

	--SET @debug=null; 
	SET @debug=1; 

	if (@debug is null) SET NOCOUNT ON;	
	if (@debug is not null) print ('For Repository: ' + @repositoryName);
	SELECT @repoId = MASTER_REPOSITORY_ID from B_MASTER_REPOSITORY where NAME = @repositoryName;
	SELECT @profileId = PROFILE_ID from B_MASTER_REPOSITORY where NAME = @repositoryName;
	DECLARE attributeCursor CURSOR FOR SELECT format_attr_id, name FROM B_FORMAT_ATTR WHERE profile_id = @profileId ORDER BY name;
	OPEN attributeCursor

	FETCH NEXT FROM attributeCursor INTO @fId, @attrName
	WHILE @@FETCH_STATUS = 0
	BEGIN
		   
	   SET @sqlStr = 'INSERT INTO @Results (Attribute,EmptyCount) SELECT [' + @attrName + '], count(*) as cnt from  B_MASTER_REPOSITORY_ITEM where repository_id=' + cast(@repoId as nvarchar) + ' and (ATTR_DATA.exist(''/Item/F_' + cast(@fId as nvarchar) + ''')=0 or ATTR_DATA.exist(''/Item/F_' + cast(@fId as nvarchar) + '[.= sql:variable("''''")]'') =1)';
	   if (@debug is not null) print(@sqlStr);
	   EXEC @sqlStr
		/*
		SET @sqlStr = 'SELECT @count = count(*) from  B_MASTER_REPOSITORY_ITEM ' +
			 'where repository_id=' + cast(@repoId as nvarchar) + ' and (ATTR_DATA.exist(''/Item/F_' +
			 cast(@fId as nvarchar) + ''')=0 or ATTR_DATA.value(''(/Item/F_' + cast(@fId as nvarchar) + ')[1]'', ''varchar(max)'')='''')';

		SET @ParmDefinition = '@count int output' 
		if (@debug is not null) print('strSql = ' + @sqlStr);
		EXEC sp_executesql  @sqlStr, @ParmDefinition,  @count = @count OUTPUT;
		INSERT INTO @Results (Attribute,EmptyCount) VALUES(@attrName,@count);
		if (@debug is not null) print('count = ' + cast(@count as nvarchar));
		IF (@count > 0 AND @debug is not null)
		begin
			print('Attribute: ' + @attrName + ' is null in ' + cast(@count as nvarchar) + ' records.');
		end
		*/
		FETCH NEXT FROM attributeCursor INTO @fId, @attrName
	END

	CLOSE attributeCursor
	DEALLOCATE attributeCursor
	SELECT Attribute,EmptyCount from @Results;
END

go

