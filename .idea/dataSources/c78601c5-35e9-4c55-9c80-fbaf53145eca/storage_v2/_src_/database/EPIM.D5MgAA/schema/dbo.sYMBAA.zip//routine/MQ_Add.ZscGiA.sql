
--
--  8/30/2016 BZ Updated to generate just an INSERT/SELECT statement instead of building a stored procedure
--
--
-- MQ_Add - adds requests on the internal outbound message queue via a SELECT statement
-- that is passed as a parameter to this procedure.  The SQL must produce a result set
-- with the following columns in the following order:
--
-- streamName, messageId, repositoryId, internalRecordId, savedSetId, messageTimestamp, message
--
-- Where:
-- 
--   streamName - name of the target stream as defined in the MQ_Registry in the MQ_Stream_Name attribute.
--   messageId - ID for message (can be null)
--   repositoryId - repository ID for messages (can be null)
--   internalRecordId - ITEM_ID/InternalRecordId of each record being sent (can be null)
--   savedSetId - ID of the saved set of records being sent (can be null)
--   messageTimestamp - data and tme of when message is sent (e.g., GETDATE())
--   message - message body (can be null)
--
-- Each message that is queue must have one of the follownig fields populated:
--
--   internalRecordId, savedSetId, or message
--
-- Example:  Exec MQ_Add N'select ''Item/SKU Single'', null, null, i.ITEM_ID, null, getdate(), null from B_MASTER_REPOSITORY m join B_MASTER_REPOSITORY_ITEM i on i.REPOSITORY_ID = m.MASTER_REPOSITORY_ID where m.name like ''SKU_Production'''
--




CREATE PROCEDURE [dbo].[MQ_Add]
@selectsql varchar(max)
AS
BEGIN
/* $Id: MQ_Add.sql 1104 2019-11-13 01:55:19Z brian.zupke@enterworks.com $ */  

declare @sql varchar(max)
DECLARE @myid varchar(max) --uniqueidentifier  
SET @myid = cast(NEWID() as varchar(max))

-- Start by creating the insert clause

set @sql = 'insert into MQ_MessageQueue(streamName, messageId, repositoryId, internalRecordId, savedSetId, messageTimestamp, message) ';

-- now add the select parameter

set @sql = @sql + @selectSql;

-- Now attempt to execute the insert/select

BEGIN TRY    
    EXEC(@sql)
	SELECT 'SUCCESS' as Status, @@ROWCOUNT as RowsInserted, '' as ErrorMessage, @sql as SQL
END TRY
BEGIN CATCH
    SELECT 
        'FAIL' as [Status],
		'0' as [RowsInserted],
        ERROR_MESSAGE() AS ErrorMessage,
		@sql as SQL;
END CATCH;

END
go

