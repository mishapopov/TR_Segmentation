
--
-- procedure to truncate a table and copy data from table_tmp into table
--
--#BEGIN#
Create Procedure [dbo].[epim_truncate_and_copy] ( @tableName varchar(512) )
As
    BEGIN

    declare @truncStmt varchar(255);
    declare @insertStmt varchar(255);

    SET NOCOUNT ON;
    
    SET @truncStmt = 'Truncate table ' + @tableName;                 			
    EXECUTE (@truncStmt);

    SET @insertStmt = 'Insert into ' + @tableName + ' Select * from ' + @tableName + '_TMP';
    EXECUTE (@insertStmt);

END
go

