--#BEGIN#
--
-- purpose: return items query result set 
-- parameters:
--    p_select_list - the projection list 
--                    eg. select GTIN "Global ID", NAME "First Name"
--    p_with_list   - projection list metadata definition
--                    eg. with (GTIN int, NAME nvarchar(30))
--    p_sort_list   - order by clause
--                    eg. order by NAME
--    p_item_data   - the item data xml blob
--                    eg.  <Item ItemId="100"><GTIN>100</GTIN><NAME>abc</NAME></Item>
CREATE PROCEDURE [dbo].[epim_get_items]
    @p_select_list nvarchar(2000) = null,
    @p_with_list nvarchar(2000)= null,
    @p_sort_list nvarchar(256) = null,
    @p_item_data ntext = null
AS
BEGIN

    declare @idoc int;
    declare @item_query nvarchar(4000);
    print 'begin b_get_items';
    exec sp_xml_preparedocument @idoc output, @p_item_data;
    
    if( @p_select_list is null )
        begin
            raiserror ('Item query projection list is empty.', 10, 1);
            return;
        end;
    if( @p_with_list is null )
        begin
            raiserror ('Item query metadata list is empty.', 10, 1);
            return;
        end;

    if( @p_item_data is null )
        begin
            raiserror ('Item xml data is empty.', 10, 1);
            return;
        end;
         
    if ( datalength(@p_select_list) + datalength(@p_with_list) + datalength(@p_sort_list) )> 4000
    begin
        raiserror ('Query string is too long.', 10, 1);
        return;
    end;

    set @item_query = @p_select_list + 
                     ' from OpenXml(@p_idoc,' + ''''+ '/eroot/Item'+ ''''+', 2) ' +
                     @p_with_list;

    if ( @p_sort_list is not null )
        set @item_query = @item_query + ' ' + @p_sort_list;
             
    print 'item query: '+@item_query;
    exec sp_executesql @item_query, N'@p_idoc int', @p_idoc=@idoc;
    exec sp_xml_removedocument @idoc;
    print 'end b_get_items';
    
END

--#END#
go

