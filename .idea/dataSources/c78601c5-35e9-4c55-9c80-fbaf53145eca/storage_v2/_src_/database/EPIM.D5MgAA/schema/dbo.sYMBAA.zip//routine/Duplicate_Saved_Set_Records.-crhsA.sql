
CREATE PROCEDURE [dbo].[Duplicate_Saved_Set_Records]
   @repositoryName VARCHAR(max),
   @savedSetName VARCHAR(max),
   @action VARCHAR(20)
AS
BEGIN
    DECLARE @createSql nvarchar(MAX);
    DECLARE @querySql VARCHAR(MAX) -- holds the SQL statement for creating the view
    DECLARE @attributeName VARCHAR(255)
    DECLARe @systemName VARCHAR(50)
    DECLARE @attributeId VARCHAR(10)
    DECLARE @repositoryId VARCHAR(10)
    DECLARE @key VARCHAR(255)
    DECLARE @value VARCHAR(max)

    IF @action = 'CLEANUP'
    BEGIN
    -- Remove the unwanted records
    --select * from B_SAVED_SET_ITEM
    delete from B_SAVED_SET_ITEM
    where SAVED_SET_ITEM_ID in (
    
    	-- Identify the records that should be removed
    	select ssi.SAVED_SET_ITEM_ID 
    	from B_SAVED_SET_ITEM ssi
    	join b_saved_set ss on ss.SAVED_SET_ID = ssi.SAVED_SET_ID
    	join B_MASTER_REPOSITORY mr on ss.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
    	left outer join (
    
    		-- Identify the records that should be kept
    		select ss.NAME as SavedSetName, ssi.ITEM_ID, min(ssi.SAVED_SET_ITEM_ID) as SAVED_SET_ITEM_ID from B_SAVED_SET_ITEM ssi
    		join b_saved_set ss on ss.SAVED_SET_ID = ssi.SAVED_SET_ID
    		join B_MASTER_REPOSITORY mr on ss.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
    		where ss.NAME  = @savedSetName
    		and mr.NAME = @repositoryName
    		group by ss.NAME, ssi.ITEM_ID
    
    	) v on ssi.SAVED_SET_ITEM_ID = v.SAVED_SET_ITEM_ID
    	where ss.NAME  = @savedSetName
    	and mr.NAME = @repositoryName
    	and v.SAVED_SET_ITEM_ID is null
    
    ) 
    select cast(@@ROWCOUNT as VARCHAR) + ' duplicate records deleted.' as CleanupResults
    END
    ELSE
    BEGIN
    
    -- List all records, identifying the duplicate ones
    select mr.NAME as RepositoryName, ss.NAME as SavedSetName,ssi.ITEM_ID,ssi.SAVED_SET_ITEM_ID, v.SAVED_SET_ITEM_ID as NullIfDuplicate
    from B_SAVED_SET_ITEM ssi
    join b_saved_set ss on ss.SAVED_SET_ID = ssi.SAVED_SET_ID
    join B_MASTER_REPOSITORY mr on ss.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
    left outer join (
    
    	-- Identify the records that should be kept
    	select ss.NAME as SavedSetName, ssi.ITEM_ID, min(ssi.SAVED_SET_ITEM_ID) as SAVED_SET_ITEM_ID from B_SAVED_SET_ITEM ssi
    	join b_saved_set ss on ss.SAVED_SET_ID = ssi.SAVED_SET_ID
    	join B_MASTER_REPOSITORY mr on ss.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
    	where ss.NAME  like @savedSetName
    	and mr.NAME like @repositoryName
    	group by ss.NAME, ssi.ITEM_ID
    
    ) v on ssi.SAVED_SET_ITEM_ID = v.SAVED_SET_ITEM_ID
    where ss.NAME like @savedSetName
    and mr.NAME like @repositoryName

    END
    
end
go

