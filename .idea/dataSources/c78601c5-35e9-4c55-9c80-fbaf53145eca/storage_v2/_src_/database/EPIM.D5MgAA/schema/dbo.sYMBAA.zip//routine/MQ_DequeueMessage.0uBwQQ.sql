

 
create procedure MQ_DequeueMessage
@streamName nvarchar(200),
@maxMessages bigint
as
  set nocount on;
  with cte as (
    select top(@maxMessages) 
      seqNumber, streamName, messageId, repositoryId, internalRecordId, savedSetId, messageTimestamp, message
      from MQ_MessageQueue with (rowlock, readpast)
      where streamName = @streamName
      order by seqNumber)
  delete from cte
    output deleted.seqNumber, deleted.streamName, deleted.messageId, deleted.repositoryId, deleted.internalRecordId, deleted.savedSetId, deleted.messageTimestamp, deleted.message;
go

