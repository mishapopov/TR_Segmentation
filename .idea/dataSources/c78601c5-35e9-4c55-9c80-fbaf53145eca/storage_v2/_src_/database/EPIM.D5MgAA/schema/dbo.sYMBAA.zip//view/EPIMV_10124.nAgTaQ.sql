create view EPIMV_10124 as select ID, PLT_10124."F_1" as F_1004364, PLT_10124."F_12354" as F_1004371 from PLT_10124
go

