
CREATE PROCEDURE [dbo].[TR_GetProductIdsForRequestForValidationByRequestId]
    @requestId VARCHAR(200),  -- Internal Record ID of the Request
    @source VARCHAR(10) -- Name of source (Build, Clone, Change, State)
AS BEGIN

    -- TR_GetProductIdsForRequestForValidationByRequestId - Retrieves the Product IDs of all linked records for the designated
    -- request record (by InternalRecordId) in the designated request pre-stage repository (Clone, Build, Change, or
    -- State).  Returns a commad-delimited list of all linked Product Variant Ids of each repository.  If a repository has no
    -- linked price records, return 'none' instead of the IDs.
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_GetProductVariantIdsForRequestForValidationByRequestId '5771435','Clone'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductVariantIdsForRequestForValidationByRequestId '%itemIds%','%source%'

    DECLARE @sql NVARCHAR(max)
    DECLARE @product VARCHAR(max)


    -----------------------------------------------------------------------------
    -- Get list of product variant records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @product = isnull(STUFF((select distinct '','' + cast(p.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Link_' + @source + ' rpl on r.Request_ID = rpl.Request_Id ' +
               'join PRODUCT_' + @source + ' p on rpl.Product_ID = p.Product_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'product - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@product varchar(max) out', @product out
    END TRY
    BEGIN CATCH
        set @product = 'none';
    END CATCH


    -----------------------------------------------------------------------------
    -- Return all ids
    -----------------------------------------------------------------------------

    select @product as product


END
go

