create view EPIM_REP_SV10174 as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1004550)') as nvarchar(MAX))  as F_1004550,  CAST(attr_data.query('data(Item/F_1004551)') as nvarchar(MAX))  as F_1004551,  CAST(attr_data.query('data(Item/F_1004552)') as nvarchar(MAX))  as F_1004552 from b_master_repository_item bmri where bmri.repository_id = 10174
go

