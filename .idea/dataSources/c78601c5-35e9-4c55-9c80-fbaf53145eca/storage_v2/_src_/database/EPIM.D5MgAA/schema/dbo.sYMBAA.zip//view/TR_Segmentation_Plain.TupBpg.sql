Create   view TR_Segmentation_Plain as
select code, DESCRIPTION, 1 as level
from TR_Hierarchy_metadata
where name = 'TR_Segments'
  and isnull(PARENT_CODE, '') = ''
union all
select code, DESCRIPTION, 2 as level
from TR_Hierarchy_metadata
where name = 'TR_Segments'
  and PARENT_CODE like 'L1_%'
union all
select code, DESCRIPTION, 3 as level
from TR_Hierarchy_metadata
where name = 'TR_Segments'
  and PARENT_CODE like 'L2_%'
go

