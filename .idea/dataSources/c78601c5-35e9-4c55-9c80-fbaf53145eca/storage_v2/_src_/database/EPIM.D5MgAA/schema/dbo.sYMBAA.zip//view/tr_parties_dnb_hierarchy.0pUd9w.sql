
CREATE   view [dbo].[tr_parties_dnb_hierarchy] as
select ps.Party_ID,
       ps.party_Full_Name,
       dnb.DUNS_Number                                                  party_duns,
       isnull(dnb.Legal_Parent_DUNS_Number, dnb.DUNS_Number)            legal_parent_duns,
       ps1.Party_ID                                                     legal_parent_party_id,
       isnull(dnb.Legal_Domestic_Ultimate_DUNS_Number, dnb.DUNS_Number) legal_domestic_duns,
       ps2.Party_ID                                                     legal_domestic_party_id,
       isnull(dnb.Legal_Global_Ultimate_DUNS_Number, dnb.DUNS_Number)   legal_global_duns,
       ps3.Party_ID                                                     legal_global_party_id,
       dnb.Operational_Parent_DUNS_Number                               operational_parent_duns,
       ps4.Party_ID                                                     operational_parent_party_id,
       dnb.Operational_Domestic_Ultimate_DUNS_Number                    operational_domestic_duns,
       ps5.Party_ID                                                     operational_domestic_party_id,
       dnb.Operational_Global_Ultimate_DUNS_Number                      operational_global_duns,
       ps6.Party_ID                                                     operational_global_party_id
from (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
--where pt.rownbr1=1
) ps
         left join (
		 select 
		 DUNS_Number,
isnull(dnb.Legal_Parent_DUNS_Number, dnb.DUNS_Number)  Legal_Parent_DUNS_Number,
isnull(dnb.Legal_Domestic_Ultimate_DUNS_Number, dnb.DUNS_Number) Legal_Domestic_Ultimate_DUNS_Number,
isnull(dnb.Legal_Global_Ultimate_DUNS_Number, dnb.DUNS_Number)  Legal_Global_Ultimate_DUNS_Number,
isnull(dnb.Operational_Parent_DUNS_Number, dnb.Legal_Parent_DUNS_Number)  Operational_Parent_DUNS_Number,
isnull(dnb.Operational_Domestic_Ultimate_DUNS_Number, dnb.Legal_Domestic_Ultimate_DUNS_Number)  Operational_Domestic_Ultimate_DUNS_Number,
isnull(dnb.Operational_Global_Ultimate_DUNS_Number, dnb.Legal_Global_Ultimate_DUNS_Number)  Operational_Global_Ultimate_DUNS_Number
		 from ecm_dnb  dnb	 
		 )dnb
                   on ps.DUNS_Number = dnb.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps1
                   on dnb.Legal_Parent_DUNS_Number = ps1.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps2
                   on dnb.Legal_Domestic_Ultimate_DUNS_Number = ps2.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps3
                   on dnb.Legal_Global_Ultimate_DUNS_Number = ps3.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps4
                   on dnb.Operational_Parent_DUNS_Number = ps4.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps5
                   on dnb.Operational_Domestic_Ultimate_DUNS_Number = ps5.DUNS_Number
         left join (select pt.party_id, pt.party_full_name, pt.duns_number from
(
select *,
row_number()over (partition by DUNS_Number order by Party_ID)  RowNbr1
  from  ECM_Party_Staging where   is_merged=1
  ) pt
where pt.rownbr1=1) ps6
                   on dnb.Operational_Global_Ultimate_DUNS_Number = ps6.DUNS_Number

go

