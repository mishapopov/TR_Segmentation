
--#BEGIN#

-- This stored procedure is used as a one-time upgrade to create STAGING_ITEM_ID values for all items
-- that are already promoted into a PRODUCTION repository.
--
-- The current epim data model does not have an easy way to locate corresponding items from Staging and 
-- Production partner repositories.  Currently, in order to locate a PRODUCTION version of an item a search 
-- must be made using the designated primary key values of the STAGING item.  This search can be costly.
-- 
-- To overcome this limitation a new column called STAGING_ITEM_ID will be added to B_MASTER_REPOSITORY_ITEM.  
-- This column will be populated by the epim_promote_bulk stored procedure, which is the standard method of 
-- promoting items from STAGING to PRODUCTION repository partners.  Because there are customer sites already 
-- using the epim_promote_bulk stored procedure that DOES NOT include this new STAGING_ITEM_ID for the PRODUCTION 
-- repository, this stored procedure must be executed to bring PRODUCTION repository records up to date.
-- 
-- This stored procedure executes these steps:
--    1.  verify the provided STAGING and PRODUCTION repository names
--    2.  create a savedSet with the provided name that contains all items from the STAGING repository
--    3.  execute the epim_populate_staging_itemId stored procedure, which will populate the PRODUCTION
--        repository with the STAGING_ITEM_ID of all matching items.
--
-- The following input parameters are expected:
--	stageRepoName       - name of the Staging repository
--	prodRepoName        - name of the Production repository where items will be "promoted" to
--	savedSetName	    - unique name of a savedSet that will be created to contain all STAGING items
--
--
--

CREATE procedure [dbo].[epim_populate_stage_prod_itemId ]
      @stageRepoName nvarchar(255),
      @prodRepoName nvarchar(255),
      @savedSetName nvarchar(255)
AS
begin
declare @lookupId bigint;
declare @startId bigint;
declare @endId bigint;
declare @savedSetId bigint;
declare @stagingRepoId bigint;
declare @prodRepoId bigint;
declare @stagingProfileId bigint;
declare @prodProfileId bigint;

declare @strSql nvarchar(max);
declare @strSqlTmp nvarchar(max);


      BEGIN TRY
            SELECT @stagingRepoId = master_repository_id, @stagingProfileId=PROFILE_ID from b_master_repository where name=@stageRepoName;
            if (@stagingRepoId is null)  RAISERROR('Staging Repository not found: %s', 16, 1, @stageRepoName);
            if (@stagingProfileId is null)  RAISERROR('Staging Profile not found: %s', 16, 1, @stageRepoName);
            PRINT ('Staging Repository ID: ' + cast(@stagingRepoId as nvarchar));

            SELECT @prodRepoId = master_repository_id, @prodProfileId=PROFILE_ID from b_master_repository where name=@prodRepoName;
            if (@prodRepoId is null)  RAISERROR('Production Repository not found: %s', 16, 1, @prodRepoName);
            if (@prodProfileId is null)  RAISERROR('Production Profile not found: %s', 16, 1, @prodRepoName);
            PRINT ('Production Repository ID: ' + cast(@stagingRepoId as nvarchar));
            
            if (@stagingProfileId <> @prodProfileId) RAISERROR('Staging and production Profile do not match: %s', 16, 1, @stageRepoName);
            
            SELECT @savedSetId = SAVED_SET_ID FROM B_SAVED_SET WHERE NAME=@savedSetName;
            PRINT ('saved set ID: ' + cast(@savedSetId as nvarchar));
            IF (@savedSetId is not null)  RAISERROR('Saved set exists, please enter unique saved set name: %s', 16, 1, @savedSetName);
            
            --Create Saved Set            
            INSERT INTO B_SAVED_SET(USER_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME, LAST_UPDATE_BY, LAST_UPDATE_DATETIME) 
		       VALUES (1, @savedSetName, 'system defined saved set', 0, GETDATE(),1,GETDATE());
			SELECT  @savedSetId=SCOPE_IDENTITY();	
		    PRINT ('SavedSet ID: ' + cast(@savedSetId as nvarchar));
            INSERT INTO B_SAVED_SET_REPO (saved_set_id, master_repository_id) values 
                                                       (@savedSetId, @stagingRepoId);

            CREATE TABLE #StagingItemIds
            (
               ID BIGINT IDENTITY(1,1) NOT NULL,
               STAGING_ITEM_ID BIGINT
               PRIMARY KEY (ID)
            )

            --populate temp table containing just staging item_ids
            SET @strSql = 'INSERT INTO #StagingItemIds (STAGING_ITEM_ID) SELECT ITEM_ID from ' +
                                'B_MASTER_REPOSITORY_ITEM where REPOSITORY_ID = ' + 
                                cast(@stagingRepoId as nvarchar) + ' order by item_id';
            PRINT @strSql;
            EXEC (@strSql);

            SET @strSql = 'INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) select ' + 
                   cast(@savedSetId as nvarchar) + ', t.item_id from B_MASTER_REPOSITORY_ITEM t where ' +
                  'REPOSITORY_ID = ' + cast(@stagingRepoId as nvarchar) + ' and t.item_id >= @startId ' +
                          'and t.item_id < @endId';

            SET @lookupId = (SELECT MIN(Id) FROM  #StagingItemIds );
            SET @strSqlTmp = @strSql;
            WHILE @lookupId is not null
            BEGIN
               SET @strSql = @strSqlTmp;
               SET @startId = (select STAGING_ITEM_ID from #StagingItemIds where Id = @lookupId);
               SET @endId = (select STAGING_ITEM_ID from #StagingItemIds where Id = (@lookupId+50000));
               if (@endId is null)
                  begin
                        print '@endId is null';
                        SET @endId = (select STAGING_ITEM_ID from #StagingItemIds where Id = 
                                                (select max(id) from #StagingItemIds)) + 1;
                  end
               PRINT ('startItemId = ' + cast(@startId as nvarchar(max)));
               PRINT ('endItemId = ' + cast(@endId as nvarchar(max)));
               SET @strSql = replace(@strSql, '@startId', cast(@startId as nvarchar));
               SET @strSql = replace(@strSql, '@endId', cast(@endId as nvarchar));
               PRINT @strSql;
               EXEC (@strSql);  
               SET @lookupId = (SELECT MIN(Id) FROM  #StagingItemIds WHERE  Id >= @lookupId+50000);
            END
            drop table #StagingItemIds
            
            --call populating procedure
            exec epim_populate_staging_itemId @stagingRepoId, @prodRepoId, @stagingProfileId, @savedSetId, 1
            
      END TRY
      BEGIN CATCH
            DECLARE @ErrorMessage NVARCHAR(4000);
            DECLARE @ErrorSeverity INT;
            DECLARE @ErrorState INT;


            SELECT  @ErrorMessage = ERROR_MESSAGE(),
                        @ErrorSeverity = ERROR_SEVERITY(),
                        @ErrorState = ERROR_STATE();

            RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);     
      END CATCH

end


go

