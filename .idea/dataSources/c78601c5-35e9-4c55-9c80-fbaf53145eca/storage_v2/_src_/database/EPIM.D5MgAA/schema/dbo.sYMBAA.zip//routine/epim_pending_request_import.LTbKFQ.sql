

CREATE procedure [dbo].[epim_pending_request_import] (
      @pitName nvarchar(255),
      @repositoryId int,
	  @approvalRequiredInd int,
      @numRequests int out,
      @numRequestDetails int out,
      @numRequestAttrs int out,
      @numRequestErrors int out,
      @numRequestItemErrors int out,
      @numRequestAttrErrors int out
       )
As
BEGIN
    DECLARE @sql          NVARCHAR(4000)
    DECLARE @profileId    bigint
    DECLARE @numRequests1 INT
    DECLARE @numRequests2 INT
    DECLARE @numPriKeys   INT
	DECLARE @debug   INT

	SET @debug=1;
	--SET @debug=0;

	if (@debug<>1) SET @debug=null; 
	if (@debug is null) SET NOCOUNT ON;	
    
    -- initialize the key columns in the pitName
    SET @sql = 'UPDATE ' + @pitName + ' SET ITEM_ID = NULL, FORMAT_ATTR_ID = NULL, REPOSITORY_ID = NULL, CREATED_BY = NULL, ERROR_IND = 0, RequestId = NULL,  ' +
    		'RequestDetailId = NULL,[USER_ERROR]=0,[REPO_ERROR]=0,[ATTR_ERROR]=0,[ITEM_ERROR]=0,[REQUEST_ERROR]=0,[DETAIL_ERROR]=0';
    if (@debug is not null) PRINT '--1: initialize the key columns in the pitName' + CHAR(13) + CHAR(10) + @sql
	EXECUTE (@sql);
    
    -- Get the profile ID
    SELECT @profileId = profile_id from b_master_repository where master_repository_id = @repositoryId;

    -- Get the number of primary keys
    SELECT @numPriKeys = count(*) from b_format_attr where profile_id=@profileId and pkey_seq_num > 0;

    -- Update the UserId    
    SET @sql = 'UPDATE ' + @pitName + ' SET CREATED_BY = B_USER.USER_ID FROM ' + @pitName + ' INNER JOIN ' +
    		'B_USER ON ' + @pitName + '.CREATED_BY_LOGIN = B_USER.LOGIN';
	if (@debug is not null) PRINT '--2:  Update the UserId ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
        
    -- Update the RepositoryId    
    SET @sql = 'UPDATE ' + @pitName + ' SET REPOSITORY_ID = B_MASTER_REPOSITORY.MASTER_REPOSITORY_ID FROM ' + 
    		@pitName + ' INNER JOIN B_MASTER_REPOSITORY ON ' + @pitName + '.REPOSITORY_NAME = ' +
    		'B_MASTER_REPOSITORY.NAME';
	if (@debug is not null) PRINT '--3: Update the RepositoryId ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Update the FormatAttrId    
    SET @sql = 'UPDATE ' + @pitName + ' SET FORMAT_ATTR_ID = B_FORMAT_ATTR.FORMAT_ATTR_ID FROM ' + @pitName + 
    		' INNER JOIN B_FORMAT_ATTR ON ' + @pitName + '.ATTR_NAME = B_FORMAT_ATTR.NAME AND B_FORMAT_ATTR.PROFILE_ID = ' +
    		CAST(@profileId as varchar(MAX));
    if (@debug is not null) PRINT '--4: Update the FormatAttrId' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Update the ItemId    
    SET @sql = 'UPDATE ' + @pitName + ' SET ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID FROM ' + @pitName + 
    		', B_MASTER_REPOSITORY_ITEM WHERE ' + @pitName + '.PKEY1 = B_MASTER_REPOSITORY_ITEM.PK_COL_1 AND ' +
    		'B_MASTER_REPOSITORY_ITEM.REPOSITORY_ID = ' + @pitName + '.REPOSITORY_ID ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + ' AND ' + @pitName + '.PKEY2 = B_MASTER_REPOSITORY_ITEM.PK_COL_2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + ' AND ' + @pitName + '.PKEY3 = B_MASTER_REPOSITORY_ITEM.PK_COL_3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + ' AND ' + @pitName + '.PKEY4 = B_MASTER_REPOSITORY_ITEM.PK_COL_4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + ' AND ' + @pitName + '.PKEY5 = B_MASTER_REPOSITORY_ITEM.PK_COL_5 ';
    if (@debug is not null) PRINT '--5: Update the ItemId ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set rows to error if No Create By Id
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[USER_ERROR]=1 WHERE (CREATED_BY IS NULL)';
    if (@debug is not null) PRINT '--6: Set rows to error if No Create By Id' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set rows to error if No Repository Id
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[REPO_ERROR]=1 WHERE (REPOSITORY_ID IS NULL)';
    if (@debug is not null) PRINT '--7: Set rows to error if No Repository Id' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set rows to error if No Format Attr Id
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[ATTR_ERROR]=1 WHERE (FORMAT_ATTR_ID IS NULL)';
    if (@debug is not null) PRINT '--8: Set rows to error if No Format Attr Id ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set rows to error if No Item Id
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[ITEM_ERROR]=1 WHERE (ITEM_ID IS NULL)';
    if (@debug is not null) PRINT '--9: Set rows to error if No Item Id ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- get count of existing pending requests
    SET @sql = 'SELECT @numRequests1=count(DISTINCT B_PENDING_REQUEST.PENDING_REQUEST_ID) from ' + @pitName + ' INNER JOIN B_PENDING_REQUEST ON ' +
			@pitName + '.CHANGE_REQUEST_NAME = B_PENDING_REQUEST.NAME AND ' +
    		@pitName + '.EFFECTIVE_DATE = B_PENDING_REQUEST.EFFECTIVE_DATE WHERE (' + @pitName + '.ERROR_IND = 0)';
	if (@debug is not null) PRINT '--10: get count of existing pending requests' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequests1 int OUTPUT', @numRequests1 = @numRequests1 OUTPUT;

    -- Set Pending Request Id if one exists already    
    SET @sql = 'UPDATE ' + @pitName + ' SET RequestId = B_PENDING_REQUEST.PENDING_REQUEST_ID FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST ON ' + @pitName + '.CHANGE_REQUEST_NAME = B_PENDING_REQUEST.NAME AND ' +
    		@pitName + '.EFFECTIVE_DATE = B_PENDING_REQUEST.EFFECTIVE_DATE WHERE (' + @pitName + '.ERROR_IND = 0)';
    if (@debug is not null) PRINT '--11:  Set Pending Request Id if one exists already ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- get count of new pending requests
    SET @sql = 'SELECT @numRequests2=count(*) from (select DISTINCT REPOSITORY_ID, CHANGE_REQUEST_NAME, EFFECTIVE_DATE, EXPIRATION_DATE ' +
    		' FROM ' + @pitName + ' WHERE (ERROR_IND = 0) AND (RequestId IS NULL)) t1';
	if (@debug is not null) PRINT '--12:  get count of new pending requests ' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequests2 int OUTPUT', @numRequests2 = @numRequests2 OUTPUT;

    SET @numRequests = (@numRequests1 + @numRequests2);

    -- Insert New Pending Requests    
    SET @sql = 'INSERT INTO B_PENDING_REQUEST (REPOSITORY_ID, NAME, EFFECTIVE_DATE, EXPIRATION_DATE, REQUEST_TYPE, CREATED_BY, CREATION_DATETIME, ' +
    		'APPROVAL_REQUIRED_IND, REQUEST_STATUS) SELECT DISTINCT REPOSITORY_ID, CHANGE_REQUEST_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, ' +
    		'1 AS REQUEST_TYPE, CREATED_BY, GETDATE() AS CREATION_DATETIME, '+CAST(@approvalRequiredInd as varchar(MAX)) +
			' AS APPROVAL_REQUIRED_IND, 0 AS REQUEST_STATUS FROM ' + @pitName + 
    		' WHERE (ERROR_IND = 0) AND (RequestId IS NULL)';
    if (@debug is not null) PRINT '--13:  Insert New Pending Requests ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set Pending Request Id for newly added Item ids    
    SET @sql = 'UPDATE ' + @pitName + ' SET RequestId = B_PENDING_REQUEST.PENDING_REQUEST_ID FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST ON ' + @pitName + '.CHANGE_REQUEST_NAME = B_PENDING_REQUEST.NAME AND ' +
    		@pitName + '.EFFECTIVE_DATE = B_PENDING_REQUEST.EFFECTIVE_DATE WHERE (ERROR_IND = 0) AND (RequestId IS NULL)';
    if (@debug is not null) PRINT '--14: Set Pending Request Id for newly added Item ids ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Insert New Pending Request Repos   
    SET @sql = 'INSERT INTO B_PENDING_REQUEST_REPO (PENDING_REQUEST_ID, MASTER_REPOSITORY_ID) SELECT DISTINCT RequestId, REPOSITORY_ID ' +
			' FROM ' + @pitName + ' WHERE (ERROR_IND = 0) AND (RequestId IS NOT NULL) AND ' +
			' NOT EXISTS (select * from B_PENDING_REQUEST_REPO where PENDING_REQUEST_ID=RequestId and MASTER_REPOSITORY_ID=REPOSITORY_ID)';
    if (@debug is not null) PRINT '--13:  Insert New Pending Request Repos ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set rows to error if request not created    
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[REQUEST_ERROR]=1 WHERE (ERROR_IND = 0) AND (RequestId IS NULL)';
    if (@debug is not null) PRINT '--15: Set rows to error if request not created' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
	/*
    -- Set Error if Pending Request Detail Id already exists
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[DETAIL_ERROR]=1 FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST_DETAIL ON ' + @pitName + '.RequestId = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID AND ' +
    		@pitName + '.ITEM_ID = B_PENDING_REQUEST_DETAIL.ITEM_ID WHERE (' + @pitName + '.ERROR_IND = 0) ';
    if (@debug is not null) PRINT '--16a: Set Error if Pending Request Detail Id already exists ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    */

    -- get count of pending request details
    SET @sql = 'SELECT @numRequestDetails=count(*) from (select DISTINCT RequestId, ITEM_ID ' +
    		' FROM ' + @pitName + ' WHERE (ERROR_IND = 0) ) t1';
    if (@debug is not null) PRINT '--16: get count of pending request details' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequestDetails int OUTPUT', @numRequestDetails = @numRequestDetails OUTPUT;

    -- get count of pending request details attrs
    SET @sql = 'SELECT @numRequestAttrs=count(*) from (select DISTINCT RequestId, ITEM_ID, FORMAT_ATTR_ID ' +
    		' FROM ' + @pitName + ' WHERE (ERROR_IND = 0) ) t1';
    if (@debug is not null) PRINT '--17:  get count of pending request details attrs' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequestAttrs int OUTPUT', @numRequestAttrs = @numRequestAttrs OUTPUT;

    -- Set Pending Request Detail Id for existing details  
    SET @sql = 'UPDATE ' + @pitName + ' SET RequestDetailId = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST_DETAIL ON ' + @pitName + '.RequestId = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID AND ' +
    		@pitName + '.ITEM_ID = B_PENDING_REQUEST_DETAIL.ITEM_ID WHERE (' + @pitName + '.ERROR_IND = 0) ';
    if (@debug is not null) PRINT '--18: Set Pending Request Detail Id for existing details' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);

    -- Insert New Pending Request Details    
    SET @sql = 'INSERT INTO B_PENDING_REQUEST_DETAIL (PENDING_REQUEST_ID, ITEM_ID, APPROVAL_IND, APPLIED_STATUS_CODE, HAS_ERROR_IND) ' +   
    		'SELECT DISTINCT RequestId, ITEM_ID, 0 AS APPROVAL_IND, 0 AS APPLIED_STATUS_CODE, 0 AS HAS_ERROR_IND ' +
    		'FROM ' + @pitName + ' WHERE (ERROR_IND = 0 AND RequestDetailId IS NULL)';
	if (@debug is not null) PRINT '--18:  Insert New Pending Request Details ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set Pending Request Detail Id for new added details  
    SET @sql = 'UPDATE ' + @pitName + ' SET RequestDetailId = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST_DETAIL ON ' + @pitName + '.RequestId = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID AND ' +
    		@pitName + '.ITEM_ID = B_PENDING_REQUEST_DETAIL.ITEM_ID WHERE (' + @pitName + '.ERROR_IND = 0) ';
    if (@debug is not null) PRINT '--19: Set Pending Request Detail Id for new added details ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Set Error if Pending Request Detail Id is not set 
    SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND =1,[DETAIL_ERROR]=1 FROM ' + @pitName + 
    		' WHERE (ERROR_IND = 0)  AND (RequestDetailId IS NULL) ';
    if (@debug is not null) PRINT '--20: Set Error if Pending Request Detail Id is not set ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);

    -- Set Error if any Pending Request Attr exists  
    --SET @sql = 'UPDATE ' + @pitName + ' SET ERROR_IND = 1,[DETAIL_ERROR]=1 FROM ' + @pitName + ' INNER JOIN ' +
    --		'B_PENDING_REQUEST_ATTR ON ' + @pitName + '.RequestDetailId = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID AND ' +
    --		@pitName + '.FORMAT_ATTR_ID = B_PENDING_REQUEST_ATTR.FORMAT_ATTR_ID WHERE (' + @pitName + '.ERROR_IND = 0) ';
    --if (@debug is not null) PRINT '--21a: Set Error if any Pending Request Attr exists  ' + CHAR(13) + CHAR(10) + @sql
    --EXECUTE (@sql);

	--Update any existing pendings;
	SET @sql = 'UPDATE B_PENDING_REQUEST_ATTR SET PENDING_VALUE=' + @pitName + '.ATTR_VALUE, REVERT_VALUE=' + @pitName + '.ATTR_REVERT_VALUE FROM ' + @pitName + ' INNER JOIN ' +
    		'B_PENDING_REQUEST_ATTR ON ' + @pitName + '.RequestDetailId = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID AND ' +
    		@pitName + '.FORMAT_ATTR_ID = B_PENDING_REQUEST_ATTR.FORMAT_ATTR_ID WHERE (' + @pitName + '.ERROR_IND = 0) ';
    if (@debug is not null) PRINT '--21: Update any existing pendings ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    
    -- Insert New Pending Request Attrs    
    SET @sql = 'INSERT INTO B_PENDING_REQUEST_ATTR (PENDING_REQUEST_DETAIL_ID, FORMAT_ATTR_ID, PENDING_VALUE, REVERT_VALUE) ' +   
    		'SELECT t.RequestDetailId, t.FORMAT_ATTR_ID, t.ATTR_VALUE, t.ATTR_REVERT_VALUE ' +
    		'FROM ' + @pitName + ' as t LEFT OUTER JOIN  B_PENDING_REQUEST_ATTR as a ' + 
			'ON t.RequestDetailId  = a.PENDING_REQUEST_DETAIL_ID AND t.FORMAT_ATTR_ID = a.FORMAT_ATTR_ID ' +
    		' WHERE (t.ERROR_IND = 0 AND a.PENDING_REQUEST_ATTR_ID is null)';
    if (@debug is not null) PRINT '--22: Insert New Pending Request Attrs ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);
    

	--update record state for all items
    SET @sql = 'UPDATE B_MASTER_REPOSITORY_ITEM SET RECORD_STATE = 2 FROM ' + @pitName + ' AS prt INNER JOIN ' +
			   'B_MASTER_REPOSITORY_ITEM ON prt.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID ' +
			   'WHERE (prt.ITEM_ID IS NOT NULL) AND (prt.ERROR_IND = 0) AND (B_MASTER_REPOSITORY_ITEM.RECORD_STATE = 0)	'
    if (@debug is not null) PRINT '--23: update record state for all items : ' + CHAR(13) + CHAR(10) + @sql
    EXECUTE (@sql);	    
    

     -- get count of pending request errors
    SET @sql = 'SELECT @numRequestErrors=count(*) from (select DISTINCT CHANGE_REQUEST_NAME  ' +
    		' FROM ' + @pitName + ' WHERE (ERROR_IND = 1) ) t1';
    if (@debug is not null) PRINT '--24: get count of pending request errors ' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequestErrors int OUTPUT', @numRequestErrors = @numRequestErrors OUTPUT;

     -- get count of pending request details errors
    SET @sql = 'SELECT @numRequestItemErrors=count(*) from (select DISTINCT CHANGE_REQUEST_NAME, PKEY1 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + ', PKEY2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + ', PKEY3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + ', PKEY4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + ', PKEY5 ';
    SET @sql = @sql + ' FROM ' + @pitName + ' WHERE (ERROR_IND = 1) ) t1';
    if (@debug is not null) PRINT '--25: get count of pending request details errors' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequestItemErrors int OUTPUT', @numRequestItemErrors = @numRequestItemErrors OUTPUT;

     -- get count of pending request details attr errors
    SET @sql = 'SELECT @numRequestAttrErrors=count(*) from (select CHANGE_REQUEST_NAME, PKEY1, ATTR_NAME ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + ', PKEY2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + ', PKEY3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + ', PKEY4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + ', PKEY5 ';
    SET @sql = @sql + ' FROM ' + @pitName + ' WHERE (ERROR_IND = 1) ) t1';
    if (@debug is not null) PRINT '--26: get count of pending request details attr errors' + CHAR(13) + CHAR(10) + @sql
    exec sp_executesql @sql, @params = N'@numRequestAttrErrors int OUTPUT', @numRequestAttrErrors = @numRequestAttrErrors OUTPUT;

END;
go

