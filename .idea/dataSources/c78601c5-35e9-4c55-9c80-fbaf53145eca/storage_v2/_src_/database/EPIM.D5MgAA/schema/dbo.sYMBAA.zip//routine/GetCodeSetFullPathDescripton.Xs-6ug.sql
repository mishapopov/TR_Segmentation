


CREATE PROCEDURE [dbo].[GetCodeSetFullPathDescripton]
	@codeSetName nvarchar(255),
	@nodeValue nvarchar(255)
AS

BEGIN
	DECLARE @fullPathDescription VARCHAR(MAX)
	DECLARE @fullPathUUID VARCHAR(MAX)
	
	DECLARE @description VARCHAR(512)
	DECLARE @uuid VARCHAR(50)
	DECLARE @parentCode VARCHAR(255)
	
	SELECT @description=csd.DESCRIPTION,@parentCode=csd.PARENT_CODE,@uuid=csd.UUID
	FROM B_CODE_SET_DETAIL csd
	JOIN B_CODE_SET cs on csd.CODE_SET_ID = cs.CODE_SET_ID
	WHERE cs.NAME = @codeSetName
	AND csd.CODE = @nodeValue
	
	SET @fullPathDescription = @description
	SET @fullPathUUID = @uuid
	
	WHILE (@parentCode IS NOT NULL AND @parentCode <> '')
	BEGIN
		SET @nodeValue = @parentCode
		SELECT @description=csd.DESCRIPTION,@parentCode=csd.PARENT_CODE,@uuid=csd.UUID
		FROM B_CODE_SET_DETAIL csd
		JOIN B_CODE_SET cs on csd.CODE_SET_ID = cs.CODE_SET_ID
		WHERE cs.NAME = @codeSetName
		AND csd.CODE = @nodeValue
		SET @fullPathDescription = @description + '.' + @fullPathDescription;
		SET @fullPathUUID = @UUID + '|' + @fullPathUUID;
	END


	select @fullPathDescription, @fullPathUUID
END
go

