
CREATE PROCEDURE [dbo].[CorrectEPXRepositoryIDs] 
   @epxDB VARCHAR(max),
   @command VARCHAR(10)

AS
BEGIN
-- Correct the Repository ID's in starting point activities after migration
-- Assumes the query is run from the EPIM database
-- Syntax:
--
-- CorrectEPXRepositoryIDs <epxDbName>,<command>
--
-- WHERE:
--
--	<epxDbName> - name of the EPX database (e.g., EPX, EPXDEV, etc.)
--	<command> - operation to be performed:
--		VIEW - display the activities that need to be updated
--		UPDATE - update the activities
--
-- Example calls:  
--		CorrectEPXRepositoryIDs N'EPX','VIEW'
--		CorrectEPXRepositoryIDs N'EPX','UPDATE'

	DECLARE @sql VARCHAR(max)
	
	set @sql='';
	
	if (@command = 'UPDATE')
	BEGIN
		set @sql=@sql+'update ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY set PROPERTY_VALUE = cast(d.MASTER_REPOSITORY_ID as VARCHAR) from ('
	END
	-- Highlight this portion to see a list of activities that need to be corrected
	
	set @sql=@sql + 'select p.NAME as ProcessName, a.NAME as ActivityName, ap1.PROPERTY_VALUE as ''RepoName'', ap2.PROPERTY_VALUE as ''RepoId'', mr.MASTER_REPOSITORY_ID, ap2.ACTIVITY_PROPERTY_ID as AP_ID ';
	set @sql=@sql + 'from ' + @epxDB + '.dbo.P_ACTIVITY a ';
	set @sql=@sql + 'join ' + @epxDB + '.dbo.P_PROCESS p on  p.PROCESS_ID = a.PROCESS_ID ';
	set @sql=@sql + 'join ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY ap1 on ap1.ACTIVITY_ID = a.ACTIVITY_ID and ap1.PROPERTY_KEY = ''P_WORKITEM_ENABLE_PIM_REPO_NAME'' ';
	set @sql=@sql + 'join ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY ap2 on ap2.ACTIVITY_ID = a.ACTIVITY_ID and ap2.PROPERTY_KEY = ''P_WORKITEM_ENABLE_PIM_REPO_ID'' ';
	set @sql=@sql + 'join B_MASTER_REPOSITORY mr on mr.name = ap1.PROPERTY_VALUE ';
	set @sql=@sql + 'where a.ACTIVITY_TYPE_CODE = 8 ';
	set @sql=@sql + 'and a.START_POINT_IND = 1 ';
	set @sql=@sql + 'and a.DELETED_IND = 0 ';
	set @sql=@sql + 'and isnull(ap2.PROPERTY_VALUE, '''') <> '''' ';
	set @sql=@sql + 'and ap2.PROPERTY_VALUE <> cast(mr.MASTER_REPOSITORY_ID as VARCHAR) ';
	-- Stop here if selecting to see the list of activities that need to be corrected

	if (@command = 'UPDATE')
	BEGIN
		set @sql=@sql+') d where ACTIVITY_PROPERTY_ID = d.AP_ID ';
	END
	
	print @sql
	EXEC (@sql)
END
go

