Create   view tr_hierarchy_mapping_plain as
select TR_Level_1_Code, TR_Level_1_Description, 1 as level
from tr_hierarchy_mapping
where TR_Level_1_Code like 'L1_%'
go

