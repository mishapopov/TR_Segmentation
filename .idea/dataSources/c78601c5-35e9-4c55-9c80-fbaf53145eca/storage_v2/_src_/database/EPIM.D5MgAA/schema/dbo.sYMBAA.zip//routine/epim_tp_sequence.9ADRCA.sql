--#BEGIN#

Create Procedure [dbo].[epim_tp_sequence] ( 
		@tp_id int,
		@starting_seq_num int,
		@old_seq_num int)
As
    BEGIN

    declare @seqCount int;
    declare @seqName varchar(100);
    declare @strCmd varchar(1000);

    SET NOCOUNT ON;
    -- can't use sequences in sqlServer, must use tables
    SET @seqName = 'EPIM_TPARTNER_SEQUENCE_' + cast(@tp_id as varchar);

    -- update a sequenceNumber if needed
    if @starting_seq_num is null
    begin
    --print('start sq num is null');
	SET @seqCount = (select count(*) from sysobjects where name = @seqName and type = 'U');
	if @seqCount > 0
	begin	
		SET @strCmd = 'drop TABLE ' + @seqName;
		execute (@strCmd);
	end;

	SET @strCmd = 'Create TABLE ' + @seqName + 
			'(sequence_id int IDENTITY(000001,1) , col1 int) ' ;
	execute (@strCmd);
    end;

    if @starting_seq_num is not null
    begin
    --print('start sq num is NOT null, seqName=' + @seqName);
	--if (@starting_seq_num <> @old_seq_num) 
	--begin
		SET @seqCount = (select count(*) from sysobjects where name = @seqName and type = 'U');
		if @seqCount > 0
		begin	
			SET @strCmd = 'drop TABLE ' + @seqName;
			execute (@strCmd);
		end;

		SET @strCmd = 'Create TABLE ' + @seqName + 
				'(sequence_id int IDENTITY(' + cast(@starting_seq_num as nvarchar) + ',1) , col1 int) ' ;
		execute (@strCmd);
	--end;
    end;
END
go

