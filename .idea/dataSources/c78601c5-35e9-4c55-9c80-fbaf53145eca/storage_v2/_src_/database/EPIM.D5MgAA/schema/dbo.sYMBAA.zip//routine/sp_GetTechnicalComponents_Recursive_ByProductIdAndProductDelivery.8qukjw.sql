


CREATE PROCEDURE [dbo].[sp_GetTechnicalComponents_Recursive_ByProductIdAndProductDelivery]  
 @ProductIDDeliveryList_Param NVARCHAR(max)  
AS

SET NOCOUNT ON;  
BEGIN TRY  
  
  
DECLARE @Product_Table TABLE  (ProductIdDelivery VARCHAR(500))   
DECLARE @Variant_Table TABLE  (VariantId INT)   
--DECLARE @paramLen INT = LEN(@ProductVariantIDList_Param)  
  
IF (LEN(@ProductIDDeliveryList_Param) = 0)  
    RAISERROR ('Provide atleast 1 Product Id with its delivery method', 11, 1)  
  
INSERT INTO @Product_Table  
  SELECT CAST(Item AS VARCHAR) FROM  dbo.SplitString(@ProductIDDeliveryList_Param, '|')   


IF (SELECT COUNT(1) from @Product_Table) = 0  
    RAISERROR ('Provide atleast 1 Product Id', 11, 1)  
  
  
INSERT INTO @Variant_Table  
	SELECT DISTINCT P.Product_Variant_ID FROM dbo.PRODUCT_VARIANT_Production AS P where cast(P.Product_ID AS VARCHAR)+'~'+ ISNULL(P.product_delivery,'') IN (SELECT ProductIdDelivery FROM @Product_Table);  

  
IF (SELECT COUNT(1) from @Variant_Table) = 0
		  RAISERROR ('No variant found for given Product Id and Delivery combination.', 11, 1);


DECLARE @VariantIdList NVARCHAR (MAX) = ''

SELECT @VariantIdList = @VariantIdList + convert(nvarchar(100), VariantId )  + ',' from @Variant_Table

exec sp_GetTechnicalComponents_Recursive_ByVariantId @ProductVariantIDList_Param = @VariantIdList 


RETURN  
END TRY  
BEGIN CATCH  
DECLARE @Message varchar(MAX) = ERROR_MESSAGE(),  
    @Severity int = ERROR_SEVERITY(),  
    @State smallint = ERROR_STATE(),  
    @Line int = ERROR_LINE()  
   
  RAISERROR (@Message, @Severity, @State, @Line)  
END CATCH

go

