CREATE VIEW dbo.[ECM_Op_Ult_Parent_ECC_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005744 AS [ECC_ID], F_1005747 AS [ECC_L1], F_1005748 AS [ECC_L2], F_1005749 AS [ECC_L3], F_1005751 AS [ECC_Update_Flag], F_1005745 AS [Op_Ult_Parent_Party_GUID], F_1005746 AS [Op_Ult_Parent_Party_ID], F_1005750 AS [Surviving_System] FROM dbo.B_SNAPSHOT_10336 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on ECM_Op_Ult_Parent_ECC_Staging to boomi
go

grant select on ECM_Op_Ult_Parent_ECC_Staging to informatica
go

grant select on ECM_Op_Ult_Parent_ECC_Staging to ecmxread
go

