
CREATE PROCEDURE [dbo].[TR_GetProductVariantHierarchyForClone]
    @itemIds VARCHAR(200),  -- Delimited list of source product variants
    @savedSetId int,	-- Saved set ID of source product variants
    @source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
    @target VARCHAR(10),	-- Name of target (Clone, Change, State)
    @cloneBatch int		-- Clone batch number (to associate all records from the same clone batch
AS BEGIN

    -- TR_GetProductVariantHierarchyForClone - Retrieves the source and target Product Variant Hierarchy Catalog
    -- records for the specified list of Product Variant Item IDs or the saved set from
    -- the designated source repository to be be cloned to the designated target repository.  Returns the internal
    -- record Id of each source Product Variant Hierarchy Catalog link record along with the Internal Record
    -- Id of the corresponding target Product Variant Hierarchy Catalog Staging link record (or null if it doesn't
    -- exist).
    --
    -- Relies on the target Product Variant Cloned From Product Variant ID and Clone Batch attributes
    -- to ensure the correct Product Variant records are used.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_GetProductVariantHierarchyForClone '5713323',null,'Staging','Clone',279283
    --
    --  EXEC TR_GetProductVariantHierarchyForClone null,10548,'Staging','Clone',279283
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductVariantHierarchyForClone '%itemIds%',%savedSetId%,'Staging','Clone',%sys.workitem.uid%

    DECLARE @sql VARCHAR(max)

    -- product_variant_hierarchy_catalog has Product_Id mapped to product_variant_id
    -- hardcoded to product_variant_hierarchy_catalog_staging since product variant clone is linked to staging
    -- there is no product variant hierarchy catalog %target% in any of the pre-staging repos
    --
    -- added in composite key join condition to find existing records
    -- but the target should be null always on clone

    -- Determine if saved set was specified
    IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds - Find the records in the source, match them to the parents
            -- in the target (by Cloned From IDs) to get their IDs and return the parent IDs
            SET @sql = 'select spvhc.InternalRecordId as source, tpvhc.InternalRecordId as target, tpv.Product_Variant_ID ' +
                       'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
                       'join PRODUCT_VARIANT_' + @target + ' tpv on spv.Product_Variant_ID = tpv.Cloned_From_Product_Variant_ID ' +
                       'and tpv.Clone_Batch = ' + cast(@cloneBatch as VARCHAR) + ' ' +
                       'join Product_Variant_Hierarchy_Catalog_' + @source + ' spvhc on spvhc.Product_Id = tpv.Cloned_From_Product_Variant_ID ' +
                       'and tpv.Clone_Batch = ' + cast(@cloneBatch as VARCHAR) + ' ' +
                       'LEFT OUTER JOIN Product_Variant_Hierarchy_Catalog_Staging tpvhc ON tpvhc.Product_Id = tpv.Product_Variant_ID ' +
                       'and tpvhc.Hierarchy_Name = spvhc.Hierarchy_Name ' +
                       'and tpvhc.NodeValue = spvhc.NodeValue ' +
                       'WHERE spv.InternalRecordId in (' + @itemIds + ')'
        END
    ELSE
        BEGIN
            -- Code set - use it - Find the records in the source, match them to the parents
            -- in the target (by Cloned From IDs) to get their IDs and return the parent IDs
            SET @sql = 'select spvhc.InternalRecordId as source, tpvhc.InternalRecordId as target, tpv.Product_Variant_ID ' +
                       'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
                       'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spv.InternalRecordId ' +
                       'join PRODUCT_VARIANT_' + @target + ' tpv on spv.Product_Variant_ID = tpv.Cloned_From_Product_Variant_ID ' +
                       'and tpv.Clone_Batch = ' + cast(@cloneBatch as VARCHAR) + ' ' +
                       'join Product_Variant_Hierarchy_Catalog_' + @source + ' spvhc on spvhc.Product_Id = tpv.Cloned_From_Product_Variant_ID ' +
                       'and tpv.Clone_Batch = ' + cast(@cloneBatch as VARCHAR) + ' ' +
                       'LEFT OUTER JOIN Product_Variant_Hierarchy_Catalog_Staging tpvhc ON tpvhc.Product_Id = tpv.Product_Variant_ID ' +
                       'and tpvhc.Hierarchy_Name = spvhc.Hierarchy_Name ' +
                       'and tpvhc.NodeValue = spvhc.NodeValue ' +
                       'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR)
        END

    print @sql
    EXECUTE (@sql)

END
go

