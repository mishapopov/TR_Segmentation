CREATE PROCEDURE [dbo].[GetTechnicalComponents_Recursive_ByVariantId_Staging]
	@ProductVariantIDList_Param NVARCHAR(max)
	      
AS   
SET NOCOUNT ON;
BEGIN TRY


DECLARE @Variant_Table TABLE  (VariantId INT) 
--DECLARE @paramLen INT = LEN(@ProductVariantIDList_Param)

IF (LEN(@ProductVariantIDList_Param) = 0)
		  RAISERROR ('Provide atleast 1 Product Variant Id', 11, 1)

INSERT INTO @Variant_Table
	SELECT CAST(Items AS INT) FROM  dbo.Split(@ProductVariantIDList_Param, ',')  

IF (SELECT COUNT(1) from @Variant_Table) = 0
		  RAISERROR ('Provide atleast 1 Product Variant Id', 11, 1)


IF (SELECT COUNT(*) FROM dbo.PRODUCT_VARIANT_Staging where dbo.PRODUCT_VARIANT_Staging.Product_Variant_ID in (SELECT VariantId FROM @Variant_Table)) = 0
		  RAISERROR ('No records', 11, 1)
;

WITH LinkedProductVariants_CTE AS (
	SELECT From_Product_Variant_ID, To_Product_Variant_ID, Product_Variant_to_Product_Variant_Relationship_Type
		FROM dbo.PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Staging as PvToPvLinkFrom
		WHERE PvToPvLinkFrom.From_Product_Variant_ID in (SELECT VariantId FROM @Variant_Table)
			UNION ALL
				SELECT PvToPvLinkTo.From_Product_Variant_ID, PvToPvLinkTo.To_Product_Variant_ID, PvToPvLinkTo.Product_Variant_to_Product_Variant_Relationship_Type
					FROM dbo.PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Staging as PvToPvLinkTo
						INNER JOIN LinkedProductVariants_CTE ecte ON ecte.To_Product_Variant_ID = PvToPvLinkTo.From_Product_Variant_ID
)


INSERT INTO @Variant_Table
	SELECT DISTINCT To_Product_Variant_ID FROM LinkedProductVariants_CTE OPTION (MAXRECURSION 1000)

SELECT
	--Variant fields
	pv.Product_Variant_ID AS PRODUCT_VARIANT_ProductVariantID, 
	pv.Product_Id AS PRODUCT_VARIANT_ProductID,
    pv.Product_Variant_GUID AS PRODUCT_VARIANT_ProductVariantGUID,
	pv.Source_System_Product_ID AS PRODUCT_VARIANT_SourceSystemProductID, 
	pv.Source_System AS PRODUCT_VARIANT_SourceSystem, 
	pv.Product_Delivery AS PRODUCT_VARIANT_ProductDelivery, 
	pv.Product_Language AS PRODUCT_VARIANT_ProductLanguage, 
	pv.Product_Version AS PRODUCT_VARIANT_ProductVersion, 
	pv.Customer_Segment AS PRODUCT_VARIANT_CustomerSegment, 
	pv.Target_Audience AS PRODUCT_VARIANT_TargetAudience, 
	pv.Customer_Sales_Restriction AS PRODUCT_VARIANT_CustomerSalesRestriction, 
	pv.Geographic_Sales_Restriction AS PRODUCT_VARIANT_GeographicSalesRestriction, 
	pv.Product_Name AS PRODUCT_VARIANT_ProductName, 
	pv.Internal_Product_Description AS PRODUCT_VARIANT_InternalProductDescription, 
	pv.External_Product_Description AS PRODUCT_VARIANT_ExternalProductDescription, 
	pv.Product_Sale_Status AS PRODUCT_VARIANT_ProductSaleStatus, 
	pv.Make_Royalty_Payments AS PRODUCT_VARIANT_MakeRoyaltyPayments, 
	pv.Strategic AS PRODUCT_VARIANT_Strategic, 
	pv.Launch_Date AS PRODUCT_VARIANT_LaunchDate, 
	pv.Proposed_Migration_Date AS PRODUCT_VARIANT_ProposedMigrationDate, 
	pv.Proposed_End_of_Life_Date AS PRODUCT_VARIANT_ProposedEndofLifeDate,

	--Variant to variant link fields
    PvToPvLink.From_Product_Variant_ID AS From_Product_Variant_ID,
    PvToPvLink.To_Product_Variant_ID AS To_Product_Variant_ID,
    PvToPvLink.Product_Variant_To_Product_Variant_Link_ID AS Product_Variant_To_Product_Variant_Link_ID,
    PvToPvLink.Product_Variant_to_Product_Variant_Relationship_Type AS Product_Variant_Relationship_Type,

	--Variant to component link fields
	pvToCompLink.Product_Variant_ID AS TECHNICAL_COMPONENT_ProductVariantID,
    pvToCompLink.Product_Variant_To_TECHNICAL_COMPONENT_Link_ID AS Product_Variant_To_TECHNICAL_COMPONENT_Link_ID,
	pvToCompLink.TECHNICAL_Product_Type AS TECHNICAL_COMPONENT_TechnicalComponentType, 

	--Component fields
	comp.TECHNICAL_COMPONENT_ID AS TECHNICAL_COMPONENT_TechnicalComponentID, 
	comp.TECHNICAL_COMPONENT_Name AS TECHNICAL_COMPONENT_TechnicalComponentName, 
	comp.TECHNICAL_COMPONENT_Description AS TECHNICAL_COMPONENT_Description, 
	comp.Customer_Type AS TECHNICAL_COMPONENT_CustomerType,

	--Component to specification link fields
	compToSpecLink.Technical_Component_To_Technical_Component_Specification_Link_ID as TECHNICAL_COMPONENT_TechnicalComponentToTechnicalComponentSpecificationLinkID,
--	compToSpecLink.Technical_Component_Specification_ID as TECHNICAL_COMPONENT_TechnicalComponentSpecificationID,
	compToSpecLink.Technical_Component_Specification_Link_Type as TECHNICAL_COMPONENT_TechnicalComponentSpecificationLinkType,
--	compToSpecLink.Technical_Product_ID as TECHNICAL_COMPONENT_TechnicalComponentID,

	--specification fields
	spec.Technical_Product_Specification_ID as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentSpecificationID,
	spec.Technical_Component_Name as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentName,
	spec.Technical_Component_Specification_Description as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentSpecificationDescription,
	spec.Technical_Component_Specification_Type as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentSpecificationType,
	spec.Technical_Component_Specification_Value as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentSpecificationValue,
	spec.Customer_Type as TECHNICAL_COMPONENT_SPECIFICATION_TechnicalComponentSpecificationValueType

	FROM dbo.PRODUCT_VARIANT_Staging as pv
			LEFT JOIN dbo.PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Staging as PvToPvLink 
				ON (PvToPvLink.From_Product_Variant_ID = pv.Product_Variant_ID) 
			LEFT JOIN dbo.PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Staging as pvToCompLink 
				ON (pvToCompLink.Product_Variant_ID = pv.Product_Variant_ID)
			LEFT JOIN dbo.TECHNICAL_COMPONENT_Staging as comp
				ON (pvToCompLink.TECHNICAL_Product_ID = comp.TECHNICAL_COMPONENT_ID)
            LEFT JOIN dbo.TECHNICAL_COMPONENT_TO_TECHNICAL_COMPONENT_SPECIFICATION_LINK_Staging as compToSpecLink
				ON (comp.Technical_Component_ID = compToSpecLink.TECHNICAL_Product_ID) 
            LEFT JOIN dbo.TECHNICAL_COMPONENT_SPECIFICATION_Staging as spec 
				ON (compToSpecLink.Technical_Component_Specification_ID = spec.Technical_Product_Specification_ID)
		
		WHERE pv.Product_Variant_ID in (SELECT VariantId FROM @Variant_Table)

	/*
		FROM dbo.PRODUCT_VARIANT_Staging as pv
			LEFT JOIN dbo.PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Staging as PvToPvLink ON (PvToPvLink.From_Product_Variant_ID = pv.Product_Variant_ID) 
			LEFT JOIN dbo.PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Staging as pvToCompLink
			LEFT JOIN dbo.TECHNICAL_COMPONENT_Staging as comp
            LEFT JOIN dbo.TECHNICAL_COMPONENT_TO_TECHNICAL_COMPONENT_SPECIFICATION_LINK_Staging as compToSpecLink
            LEFT JOIN dbo.TECHNICAL_COMPONENT_SPECIFICATION_Staging as spec
                                       ON (compToSpecLink.Technical_Component_Specification_ID = spec.Technical_Product_Specification_ID)
                                  ON (comp.Technical_Component_ID = compToSpecLink.TECHNICAL_Product_ID) 
							 ON (pvToCompLink.TECHNICAL_Product_ID = comp.TECHNICAL_COMPONENT_ID)
			ON (pvToCompLink.Product_Variant_ID = pv.Product_Variant_ID)
                 WHERE pv.Product_Variant_ID in (SELECT VariantId FROM @Variant_Table)
*/

RETURN
END TRY
BEGIN CATCH
DECLARE @Message varchar(MAX) = ERROR_MESSAGE(),
				@Severity int = ERROR_SEVERITY(),
				@State smallint = ERROR_STATE()
 
	 RAISERROR (@Message, @Severity, @State)
END CATCH
go

