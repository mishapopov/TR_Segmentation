create view EPIMV_10134 as select ID, PLT_10134."F_12348" as F_1004365, PLT_10134."F_1" as F_1004364 from PLT_10134
go

