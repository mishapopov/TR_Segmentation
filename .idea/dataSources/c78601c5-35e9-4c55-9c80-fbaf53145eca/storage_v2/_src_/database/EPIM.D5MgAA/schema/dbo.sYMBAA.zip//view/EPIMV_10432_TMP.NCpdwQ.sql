create view EPIMV_10432_TMP as select ID, PLT_10434_TMP."F_1" as F_1004364 from PLT_10434_TMP
go

