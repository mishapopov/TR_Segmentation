CREATE VIEW dbo.[REFERENCE_ROLE_OF_CONTACT] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004438 AS [EPM_Reference_Code], F_1004439 AS [System_Name], F_1004440 AS [Value] FROM dbo.B_SNAPSHOT_10175 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_ROLE_OF_CONTACT to dbadmin
go

grant select on REFERENCE_ROLE_OF_CONTACT to ewsys
go

grant select on REFERENCE_ROLE_OF_CONTACT to boomi
go

grant select on REFERENCE_ROLE_OF_CONTACT to informatica
go

grant select on REFERENCE_ROLE_OF_CONTACT to som
go

grant select on REFERENCE_ROLE_OF_CONTACT to apttus
go

grant select on REFERENCE_ROLE_OF_CONTACT to epmdev
go

grant select on REFERENCE_ROLE_OF_CONTACT to MDMAdmin
go

grant select on REFERENCE_ROLE_OF_CONTACT to produser1
go

grant select on REFERENCE_ROLE_OF_CONTACT to produser3
go

grant select on REFERENCE_ROLE_OF_CONTACT to produser2
go

grant select on REFERENCE_ROLE_OF_CONTACT to VIEW_ACCESS
go

grant select on REFERENCE_ROLE_OF_CONTACT to integration_team
go

grant select on REFERENCE_ROLE_OF_CONTACT to ecmxread
go

grant select on REFERENCE_ROLE_OF_CONTACT to MPOPOV_TEST
go

grant select on REFERENCE_ROLE_OF_CONTACT to digital
go

