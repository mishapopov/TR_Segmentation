CREATE VIEW dbo.[ECX_Contact_Exclusion] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005802 AS [Data_Load_Flag], F_1005499 AS [email_address], F_1005497 AS [first_name], F_1005498 AS [last_name], F_1005496 AS [rule_id] FROM dbo.B_SNAPSHOT_10313 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

