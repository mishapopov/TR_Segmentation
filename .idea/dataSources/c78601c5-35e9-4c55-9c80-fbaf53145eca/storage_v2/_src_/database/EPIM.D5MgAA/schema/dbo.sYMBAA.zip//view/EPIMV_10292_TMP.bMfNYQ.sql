create view EPIMV_10292_TMP as select ID, PLT_10294_TMP."F_1" as F_1004364 from PLT_10294_TMP
go

