create view EPIMV_10332 as select ID, PLT_10334."F_1" as F_1004364, PLT_10334."F_12667" as F_1004703 from PLT_10334
go

