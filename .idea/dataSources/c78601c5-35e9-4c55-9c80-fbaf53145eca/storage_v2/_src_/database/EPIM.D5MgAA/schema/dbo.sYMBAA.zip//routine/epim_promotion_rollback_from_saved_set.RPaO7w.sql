--#BEGIN#

-- This stored procedure is used to rollback a "promotion to Production" of items from a Staging savedSet. 
--
-- The following input parameters are expected:
--	savedSetName              - name of the savedSet from the Staging repository containing items to "promote" 
--	stagingRepositoryName     - name of the Staging repository 
--	productionRepositoryName  - name of the Production repository where items will be "promoted" to
--	otherStagAttrsToUpdateXml - XML string containing additional attributes to update for the items in the Staging repository
--	statusStagToUpdateXml     - XML string containing status values (i.e. RECORD_STATE) to update for the items in the Staging repository
--	saveStagAttrsXml          - XML string containing attributes that should be kept the same in Staging repository
--	resultLog                 - OUTPUT parameter that will contain log statements of all SQL executed
--
-- statusToUpdateXml structure: 
--     '<Status><keyValuePair><statusAttrName>RECORD_STATE</statusAttrName><statusValue>0</statusValue></keyValuePair>
--             <keyValuePair><statusAttrName>EXTERNAL_SESSION_INFO</statusAttrName><statusValue>debbie</statusValue></keyValuePair></Status>'
-- 
-- otherAttrsToUpdateXml structure: 
--     '<Attrs><keyValuePair><attrSystemName>F_100044</attrSystemName><attrValue>22</attrValue></keyValuePair>
--             <keyValuePair><attrSystemName>F_100045</attrSystemName><attrValue>50</attrValue></keyValuePair></Attrs>'
-- 
-- The procedure will perform the following steps:
--      1.  create a history item for the Staging item 
--      2.  UPDATE item attr_data in Staging with the Production attr_data - but keep any attributes in the saveStagAttrsXml the same
--      3.  update otherAttributes in the Staging repository requested by the caller 
--      4.  update status values in the Staging repository requested by the caller 
--
-- This is an example of how to call this stored procedure from the Sql Server Management Studio:
--
--    declare @rlog varchar(max)
--    begin
--    exec epim_promotion_rollback_from_saved_set 'debSS', 'DebTest1', 'DebTest2', 
--        '<Attrs><keyValuePair><attrSystemName>F_1000389</attrSystemName><attrValue>updated staging desc</attrValue></keyValuePair></Attrs>', 
--        '<Status><keyValuePair><statusAttrName>EXTERNAL_SESSION_INFO</statusAttrName><statusValue>new staging session value</statusValue></keyValuePair></Status>', 
--          '<SaveAttr><systemNames><sysName>F_1001116</sysName></systemNames></SaveAttr>', 
--        @resultLog=@rlog OUTPUT;
--    print @rlog
--    end

 

create procedure [dbo].[epim_promotion_rollback_from_saved_set] (
      @savedSetName nvarchar(255),
      @stagingRepositoryName nvarchar(255),
      @productionRepositoryName nvarchar(255),
      @otherStagAttrsToUpdateXml XML,
      @statusStagToUpdateXml XML,
      @saveStagAttrsXml XML,
      @resultLog varchar(max) OUTPUT )
As
BEGIN
    DECLARE @strSql NVARCHAR(max)
    DECLARE @itemId VARCHAR(10)
    DECLARE @stagingRepoId VARCHAR(10)
    DECLARE @productionRepoId VARCHAR(10)
    DECLARE @profileId INT
    DECLARE @numPriKeys INT
    DECLARE @index INT
    DECLARE @pkCol1Value VARCHAR(512)
    DECLARE @pkCol2Value VARCHAR(512)
    DECLARE @pkCol3Value VARCHAR(512)
    DECLARE @pkCol4Value VARCHAR(512)
    DECLARE @pkCol5Value VARCHAR(512)
    DECLARE @attrData XML
    DECLARE @epim592StatusCols VARCHAR(255)
    DECLARE @epim593StatusCols VARCHAR(255)
    DECLARE @epim592StatusVals VARCHAR(255)
    DECLARE @epim593StatusVals VARCHAR(255)    
    DECLARE @keyValuesStag TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, AttrSystemName VARCHAR(20), AttrValue VARCHAR(512)) ;
    DECLARE @statusValuesStag TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, StatusAttrName VARCHAR(50), StatusValue VARCHAR(512)) ;
    DECLARE @saveAttrs TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, SysName VARCHAR(50), AttrValue VARCHAR(512)) ;
    DECLARE @saveAttrsToUse TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, SysName VARCHAR(50), AttrValue VARCHAR(512)) ;
    DECLARE @attrSystemName VARCHAR(20)
    DECLARE @sysName VARCHAR(20)
    DECLARE @attrValue VARCHAR(512)
    DECLARE @statusAttrName VARCHAR(50)
    DECLARE @statusValue VARCHAR(512)
    DECLARE @priKeyWhereClause VARCHAR(512)
    DECLARE @quotedValue VARCHAR(max)
    DECLARE @newSavedSetName VARCHAR(max)
    DECLARE @newSavedSetId VARCHAR(50)
    DECLARE @profileIdProd int
    DECLARE @profileIdStag int
    DECLARE @epimVersion nvarchar(20)
    DECLARE @attrVal VARCHAR(max)
    DECLARE @itemSql nvarchar(4000)
    declare @saveAttrId bigint
    declare @savedSetId bigint
    declare @savedSetItemId bigint
    declare @prodItemId bigint
    DECLARE @ParmDefinition as NVARCHAR(MAX)
    Declare @find nvarchar(5);
    Declare @replace nvarchar(5);

    SET NOCOUNT ON;

    Set @find = ''+ char(39) +'';
    Set @replace = ''+char(39)+char(39)+'';


if @statusStagToUpdateXml IS NULL
   SET @statusStagToUpdateXml = '';
if @otherStagAttrsToUpdateXml IS NULL
   SET @otherStagAttrsToUpdateXml = '';
if @saveStagAttrsXml IS NULL
   SET @saveStagAttrsXml = '';

    INSERT INTO @saveAttrs (SysName, AttrValue) 
           SELECT ParamValues.systemNames.value('.','VARCHAR(20)') as SysName, '' as AttrValue
    FROM @saveStagAttrsXml.nodes('/SaveAttr/systemNames/sysName') as ParamValues(systemNames);

    INSERT INTO @keyValuesStag (AttrSystemName, AttrValue) 
           SELECT ParamValues.keyValuePair.value('attrSystemName[1]','VARCHAR(20)') as AttrSystemName,
                  ParamValues.keyValuePair.value('attrValue[1]','VARCHAR(512)') as AttrValue
    FROM @otherStagAttrsToUpdateXml.nodes('/Attrs/keyValuePair') as ParamValues(keyValuePair);
  
  
    INSERT INTO @statusValuesStag (StatusAttrName, StatusValue) 
           SELECT ParamValues.keyValuePair.value('statusAttrName[1]','VARCHAR(50)') as StatusAttrName,
                  ParamValues.keyValuePair.value('statusValue[1]','VARCHAR(512)') as StatusValue
    FROM @statusStagToUpdateXml.nodes('/Status/keyValuePair') as ParamValues(keyValuePair);
  

        
    SET @epimVersion = 'epim593';
    SET @epim592StatusCols = 'item_action_status, publication_status, subscriber_state, message_id, recipient_state1, transaction_id';
    SET @epim593StatusCols = 'record_state, production_state, workflow_state, message_id, transaction_id';
    SET @epim592StatusVals = '0,0,0,null,0,null';
    SET @epim593StatusVals = '1,0,0,null,null';
    SET @resultLog = '';
    
    -- Get the repository IDs
    SELECT @stagingRepoId = cast(master_repository_id as VARCHAR), @profileId = profile_id from b_master_repository where name = @stagingRepositoryName;
    SELECT @productionRepoId = cast(master_repository_id as VARCHAR) from b_master_repository where name = @productionRepositoryName;
    -- Get the savedSet ID - to make looping query faster
    SELECT @savedSetId = ss.saved_set_id from b_saved_set ss, b_saved_set_repo ssr where 
           ss.saved_set_id = ssr.saved_set_id and name=@savedSetName and ssr.MASTER_REPOSITORY_ID=@stagingRepoId;
    
    -- make sure both repositories use the same profile
    SELECT @profileIdProd = profile_id from b_master_repository where name = @productionRepositoryName;
    SELECT @profileIdStag = profile_id from b_master_repository where name = @stagingRepositoryName;
    if (@profileIdProd <> @profileIdStag)
    BEGIN
        SET @resultLog = 'ERROR:  profiles of these repositories do not match!';
        RAISERROR('ERROR:  profiles of these repositories do not match!', 16, 1);
    END
    else
    BEGIN TRY

        -- Get the number of primary keys in the profile
        SELECT @numPriKeys = count(*) from b_format_attr where profile_id=@profileId and pkey_seq_num>0;
        --print('@numPriKeys');
		 
        -- Loop through each item in the saved set

    	SET @savedSetItemId = (SELECT MIN(saved_set_item_id) FROM  b_saved_set_item WHERE saved_set_id = @savedSetId  );

	WHILE @savedSetItemId IS NOT NULL
        BEGIN
			--print('WHILE @savedSetItemId IS NOT NULL');
            Delete FROM @saveAttrsToUse
    	    SELECT  @itemId = item_id FROM  b_saved_set_item WHERE saved_set_item_id = @savedSetItemId;
    	    
            -- obtain the attrData, pkCol1, pkCol2, etc values for this item
            SELECT @pkCol1Value = PK_COL_1,  @pkCol2Value = PK_COL_2, @pkCol3Value = PK_COL_3, @pkCol4Value = PK_COL_4, @pkCol5Value = PK_COL_5  
				from b_master_repository_Item  with (nolock) where item_id = @itemId;
            
            -- check for null pk values
            if (@pkCol1Value is null)  RAISERROR('NULL pri key value #1 for itemID: %s', 16, 1, @itemId);
            if (@numPriKeys > 1 and @pkCol2Value is null) RAISERROR('NULL pri key value #2 for itemID: %s', 16, 1, @itemId);
            if (@numPriKeys > 2 and @pkCol3Value is null) RAISERROR('NULL pri key value #3 for itemID: %s', 16, 1, @itemId);
            if (@numPriKeys > 3 and @pkCol4Value is null) RAISERROR('NULL pri key value #4 for itemID: %s', 16, 1, @itemId);
            if (@numPriKeys > 4 and @pkCol5Value is null) RAISERROR('NULL pri key value #5 for itemID: %s', 16, 1, @itemId);

            exec @priKeyWhereClause = dbo.epim_compose_priKey_where_clause @numPriKeys, @pkCol1Value, @pkCol2Value, @pkCol3Value, @pkCol4Value, @pkCol5Value;
                           
            -- first make sure a production item exists
            SET @prodItemId = null;
            SET @itemSql = 'SELECT @prodItemId = item_id from b_master_repository_Item with (nolock) where repository_id = ' +  @productionRepoId + @priKeyWhereClause;
	    EXEC sp_executesql @itemSql, @params = N'@prodItemId INT OUTPUT', @prodItemId = @prodItemId OUTPUT;

	    if (@prodItemId is not null)
	    BEGIN
                          
		    --print('@prodItemId is not null');
			-- create a history item for the Staging item 
 
                SET @strSql = 'insert into b_repository_item_history (MASTER_REPOSITORY_ID,ATTR_DATA, ' +
                              'MODIFICATION_DATETIME, MODIFIED_BY, MODIFY_ACTION, ITEM_ID,RECLOCK,USER_LOGIN,';
	        IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
    	        IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
    	        SET @strSql = @strSql + ',STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO ) select ' + @stagingRepoId + ',ATTR_DATA, ' +
    	                     ' case when bmi.LAST_UPDATE_DATETIME is null then bmi.CREATION_DATETIME else bmi.LAST_UPDATE_DATETIME end, ' +
    	                  ' case when bmi.LAST_UPDATE_BY is null then bmi.CREATED_BY else bmi.LAST_UPDATE_BY end, MODIFY_ACTION, ' + @itemId +
    	                  ',bmi.RECLOCK,bu.LOGIN, ';
	        IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
    	        IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
    	        SET @strSql = @strSql + ', null,null,null  from b_master_repository_item bmi, ' +
    	                  'b_user bu where item_id = ' + @itemId + ' and bu.user_id=case when bmi.last_update_by is null then bmi.created_by else bmi.last_update_by end';
        
                EXECUTE (@strSql); 
               
                -- before UPDATE item attr_data in Staging, get any attr data to save             
    	        SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrs );

    	        WHILE @saveAttrId is not null
    	        BEGIN
    	            SELECT @sysName = SysName from @saveAttrs where SaveAttrId = @saveAttrId;
    	    
        	    SET @itemSql = 'select @attrVal=' + @sysName + ' from b_snapshot_' + @stagingRepoId + ' where item_id = ' + @itemId;        
	    	    EXEC sp_executesql @itemSql, @params = N'@attrVal varchar(max) OUTPUT', @attrVal = @attrVal OUTPUT;

	            INSERT INTO @saveAttrsToUse (SysName, AttrValue) values (@sysName, @attrVal); 
                    SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrs WHERE  SaveAttrId > @saveAttrId)
    	        END

                -- UPDATE item attr_data in Staging
                SET @itemSql = 'SELECT @attrData = attr_data from b_master_repository_Item where attr_data is not null and repository_id = ' + 
                		@productionRepoId + @priKeyWhereClause;
	        EXEC sp_executesql @itemSql, @params = N'@attrData XML OUTPUT', @attrData = @attrData OUTPUT;
	    
                --if (@attrData is not null) print('attrData from production: ' + cast(@attrData as VARCHAR(MAX)));
                --if (@attrData is null) print(' nothing in production');
	        if (@attrData is not null)
	        BEGIN
                   SET @strSql = 'update b_master_repository_item set attr_last_update_datetime = getDate(), last_update_datetime = getDate(), ' +
                          'modify_action=''update'', has_error_ind=null, attr_data = @my_attr_data where item_id = ' + @itemId + ' and repository_id = ' + @stagingRepoId;
        
		    SET @ParmDefinition = N'@my_attr_data xml' 
		    EXECUTE sp_executesql @strSql, @ParmDefinition,  @my_attr_data = @attrData
        	
                   -- replace the saved attr data             
    	           SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrsToUse );
  
    	           WHILE @saveAttrId is not null
    	           BEGIN
                    select @sysName = SysName, @attrValue = AttrValue from @saveAttrsToUse where SaveAttrId=@saveAttrId;
                    if @attrValue IS NOT NULL
                    begin

        	       SET @strSql = 'update b_master_repository_item set ' +
        	                  'attr_data.modify(''replace value of (/Item/' + @sysName + 
        	                  '/text())[1] with "' + @attrValue + '" '')  where attr_data is not null and repository_id = ' + @stagingRepoId  +
                                  ' and item_id = ' + @itemId;
        
        	       EXECUTE (@strSql); 
        	
        	       SET @strSql = 'update b_master_repository_item set ' +
        	              ' attr_data.modify(''insert <' + @sysName + '>' + @attrValue +
        	              '</' + @sysName + '>  into (/Item)[1]'') where attr_data is not null and attr_data.exist(''/Item/' + @sysName + 
        	              ''') !=1 and repository_id = ' + @stagingRepoId  +' and item_id = ' + @itemId;
        
        	       EXECUTE (@strSql); 
                    end
                    if @attrValue IS NULL
                    begin
                       --print('null attrValue')
        	       SET @strSql = 'update b_master_repository_item set ' +
        	                  ' attr_data.modify(''delete /Item/' + @sysName + '[1]'') where attr_data is not null and repository_id = ' + @stagingRepoId  +
                                  ' and item_id = ' + @itemId;
        
                       --print('@strSql: ' + @strSql)
        	       EXECUTE (@strSql); 
                    end

                    SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrsToUse WHERE  SaveAttrId > @saveAttrId)
    	           END
    	        END
            
                -- update otherAttributes in Staging requested by the caller
        
    	        SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesStag );

    	        WHILE @saveAttrId is not null
    	        BEGIN
                    select @attrSystemName = AttrSystemName, @attrValue = AttrValue from @keyValuesStag where SaveAttrId=@saveAttrId;
                    if @attrValue IS NOT NULL
                    begin
               
        	        SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
        	                  'attr_data.modify(''replace value of (/Item/' + @attrSystemName + 
        	                  '/text())[1] with "' + @attrValue + '" '')  where attr_data is not null and item_id = ' + @itemId + ' and repository_id = ' + @stagingRepoId;
        
        	        EXECUTE (@strSql); 
        	
        	        SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
        	              'attr_data.modify(''insert <' + @attrSystemName + '>' + @attrValue +
        	              '</' + @attrSystemName + '>  into (/Item)[1]'') where attr_data is not null and attr_data.exist(''/Item/' + @attrSystemName + 
        	              ''') !=1 and item_id = ' + @itemId + ' and repository_id = ' + @stagingRepoId;
        
        	        EXECUTE (@strSql); 
		    end
                    if @attrValue IS NULL
                    begin
                       --print('null attrValue')
        	       SET @strSql = 'update b_master_repository_item set ' +
        	              ' attr_data.modify(''delete /Item/' + @attrSystemName + '[1]'') where attr_data is not null and item_id = ' + @itemId + ' and repository_id = ' + @stagingRepoId;
        
                       --print('@strSql: ' + @strSql)
        	       EXECUTE (@strSql); 
                    end

                    SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesStag WHERE  SaveAttrId > @saveAttrId)
    	        END
    
                -- update status values in Staging requested by the caller
        
    	        SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesStag );

    	        WHILE @saveAttrId is not null
    	        BEGIN
                    select @statusAttrName = StatusAttrName, @statusValue = StatusValue from @statusValuesStag where SaveAttrId=@saveAttrId;
                    exec @quotedValue = dbo.epim_compose_quoted_value @statusAttrName, @statusValue;

        	    SET @strSql = 'update b_master_repository_item set ' + @statusAttrName + ' = ' + @quotedValue + 
        	                  ' where item_id = ' + @itemId + ' and repository_id = ' + @stagingRepoId;
        
        	    EXECUTE (@strSql);         	

                    SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesStag WHERE  SaveAttrId > @saveAttrId)
    	        END
    
	    END
    	    SET @savedSetItemId = (SELECT MIN(saved_set_item_id) FROM  b_saved_set_item WHERE saved_set_id = @savedSetId  
    	    		AND  saved_set_item_id > @savedSetItemId );
        END

    END TRY
    
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

	
        SELECT  @ErrorMessage = ERROR_MESSAGE(),
                @ErrorSeverity = ERROR_SEVERITY(),
                @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
    
   --SELECT @resultLog

END;
go

