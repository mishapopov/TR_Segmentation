create view EPIMV_10243 as select ID, PLT_10245."F_1" as F_1004364, PLT_10245."F_12691" as F_1004727 from PLT_10245
go

