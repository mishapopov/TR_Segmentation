CREATE VIEW dbo.[AUTHOR_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005218 AS [AuthorID], F_1005224 AS [Biography], F_1005223 AS [Credentials], F_1005228 AS [Email], F_1005219 AS [FirstName], F_1005221 AS [LastName], F_1005220 AS [MiddleName], F_1005222 AS [NameSuffix], F_1005226 AS [OfficeLocation], F_1005225 AS [PhotoLocation], F_1005227 AS [WebsiteURL] FROM dbo.B_SNAPSHOT_10285 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on AUTHOR_Staging to dbadmin
go

grant select on AUTHOR_Staging to boomi
go

grant select on AUTHOR_Staging to informatica
go

grant select on AUTHOR_Staging to som
go

grant select on AUTHOR_Staging to apttus
go

grant select on AUTHOR_Staging to epmdev
go

grant select on AUTHOR_Staging to MDMAdmin
go

grant select on AUTHOR_Staging to produser1
go

grant select on AUTHOR_Staging to produser3
go

grant select on AUTHOR_Staging to produser2
go

grant select on AUTHOR_Staging to digital
go

