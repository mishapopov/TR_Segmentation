create view EPIMV_10285_TMP as select ID, PLT_10287_TMP."F_1" as F_1004364 from PLT_10287_TMP
go

