
-- =============================================
-- Author:		Enterworks, Inc.:  Oscar Olivares
-- Create date: 3/22/2013
-- Description:	Retrieves table for given classification containing list of valid dynamic attribute
--				IDs and names.
-- =============================================
CREATE FUNCTION [dbo].[ValidDynamicAttributeList] 
(
@classification varchar(max)
)
RETURNS 
@DynamicAttributes table (DynAttID varchar(max),DynAttName varchar(max))

AS
BEGIN


--testing region
--declare @classification varchar(max)
--declare @DynamicAttributes table (DynAttID varchar(max),DynAttName varchar(max))
--set @classification = '10.101.10105.170.000.000'


declare @ProfileID as bigint
declare @DynamicAssocID as bigint

-- Resolve dynamic association and profile IDs
select @ProfileID = PROFILE_ID from B_PROFILE where NAME = 'Item'
select  @DynamicAssocID = DYN_ASSOC_ID from B_DYN_ASSOC where NAME = 'Dynamic Associations'


insert @DynamicAttributes
select 
DynAttID = fa.FORMAT_ATTR_ID
	,DynnAttName = fa.NAME
from B_DYN_ASSOC_ATTR_MAP da
	join [B_FORMAT_ATTR] fa on da.FORMAT_ATTR_ID  = fa.FORMAT_ATTR_ID
where fa.PROFILE_ID = @ProfileID and da.DYN_ASSOC_ID = @DynamicAssocID and da.CODE_SET_DETAIL_CODE = @classification
order by 1,2


RETURN 
END

go

