
CREATE PROCEDURE [dbo].[TR_ValidateNewProductsForSubmit]
    @itemIds VARCHAR(200),  -- Delimited list of source product variants
    @savedSetId int,	-- Saved set ID of source product variants
    @source VARCHAR(10),	-- Name of source (Build, Clone)
    @target VARCHAR(10)	-- Name of target (Build, Clone)
AS BEGIN

    -- TR_ValidateNewProductVariantsForSubmit - Verifies that none of the selected Product variants are in an existing
    -- New Product work item.  If they are, then the request fails due to items already in workflow.  Returns
    -- either 'none' or a delimited list of Product Variant IDs that were found to be in-process.  Can specify
    -- either a delimited list or saved set of Product Variant records in the source repository (referenced by
    -- Internal Record Ids).
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_ValidateNewProductsForSubmit '5707081, 5707083, 5707082, 5707127, 5707037, 5707043',null,'Build','Build'
    --
    --  EXEC TR_ValidateNewProductsForSubmit null,10548,'Build','Build'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_ValidateNewProductsForSubmit '%itemIds%',%savedSetId%,'Build','Build'

    DECLARE @sql VARCHAR(max)

    -- Determine if saved set was specified

    IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds and see if any of the same Product Variant IDs are in the target
            SET @sql = 'select isnull(STUFF((select '','' + cast(pv.Product_ID as VARCHAR) as [text()] ' +
                       'FROM PRODUCT_' + @source + ' pv  ' +
                       'join Request_To_Product_Link_' + @target + ' rpvl on rpvl.Product_ID = pv.Product_ID ' +
                       'where pv.InternalRecordId in (' + @itemIds + ') FOR XML PATH('''')), 1, 1, ''''), ''none'') as existingRecords'

        END
    ELSE
        BEGIN
            -- Code set - use it and see if any of the same Product Variant IDs are in the target
            SET @sql = 'select isnull(STUFF((select '','' + cast(pv.Product_ID as VARCHAR) as [text()] ' +
                       'from PRODUCT_' + @source + ' pv ' +
                       'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = pv.InternalRecordId ' +
                       'join Request_To_Product_Link_' + @target + ' rpvl on rpvl.Product_ID = pv.Product_ID ' +
                       'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  as existingRecords'
        END

    print @sql
    EXECUTE (@sql)

END
go

