create view EPIMV_10244 as select ID, PLT_10246."F_12498" as F_1004524, PLT_10246."F_1" as F_1004523 from PLT_10246
go

