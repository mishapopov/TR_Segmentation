create PROCEDURE [dbo].[epim_promote_uss_item_list]
	@stageItemList varchar(max),
	@stageRepository varchar(255)
	/*
	,
	@prodRepo varchar(255) output,
	@prodItemList varchar(max) output,
	@secondProdRepo varchar(255) output,
	@secondProdItemList varchar(max) output
	*/
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	DECLARE @debug int;
	DECLARE @execStmt  nvarchar(max);   
	DECLARE @stageRepoId bigint;
	DECLARE @prodRepoId bigint;
	DECLARE @secondStageRepo varchar(255);
	DECLARE @secondStageRepoId bigint;
	DECLARE @secondProdRepoId bigint;
	DECLARE @secondItemList varchar(max);
	DECLARE @find nvarchar(5);
    DECLARE @replace nvarchar(5);
    DECLARE @secondSQL nvarchar(max);
    DECLARE @ParmDefinition as NVARCHAR(MAX);
	DECLARE	@productionItemsList nvarchar(max);
	DECLARE @statusStagToUpdateXml XML;
	DECLARE	@prodSavedSet nvarchar(max);
	DECLARE @otherStagAttrsToUpdateXml XML;
	DECLARE @workflowStatusId bigint;
	DECLARE @sql nvarchar(max);
	DECLARE @firstSnapshotName NVARCHAR(255);
	DECLARE @secondSnapshotName NVARCHAR(255);
	
	DECLARE @prodRepo varchar(255);
	DECLARE @prodItemList varchar(max);
	DECLARE @secondProdRepo varchar(255);
	DECLARE @secondProdItemList varchar(max);
	
	SET @debug=null;
	if (@debug is null) SET NOCOUNT ON;
    Set @find = ''+ char(39) +'';
    Set @replace = ''+char(39)+char(39)+'';
    
	SET @prodRepo=NULL;
	SET @secondStageRepo=NULL;
	SET @secondItemList=NULL;
	SET @secondProdRepo=NULL;

	IF (@stageRepository = 'PIM_Brand_Staging')
		BEGIN
		SET @prodRepo='PIM_Brand_Production';
		SET @secondStageRepo='PIM_ManufacturerBrand_Staging';
		SET @secondProdRepo='PIM_ManufacturerBrand_Production';
		SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
		SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
		if (@debug is not null) PRINT  '55: @stageItemList=' + @stageItemList
		SET @sql = 'SELECT  @secondItemList = STUFF( (SELECT '','' + CAST(mb.InternalRecordId as varchar(max)) FROM [' + @firstSnapshotName + '] b with (nolock) INNER JOIN [' + @secondSnapshotName + '] mb with (nolock) ON b.[Brand Id] = mb.[Brand Id] WHERE (b.InternalRecordId IN (' + @stageItemList + ')) FOR XML PATH('''')), 1, 1, '''')';
		EXEC sp_executesql @sql, @params = N'@secondItemList varchar(max) OUTPUT', @secondItemList = @secondItemList OUTPUT;
		if (@debug is not null) PRINT  '58: @secondItemList=' + @secondItemList				
		END
	ELSE
		BEGIN
		IF (@stageRepository = 'PIM_Manufacturer_Staging')
			BEGIN
			SET @prodRepo='PIM_Manufacturer_Production';
			SET @secondStageRepo='PIM_ManufacturerBrand_Staging';
			SET @secondProdRepo='PIM_ManufacturerBrand_Production';
			SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
			SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
			if (@debug is not null) PRINT  '67: @stageItemList=' + @stageItemList
			SET @sql = 'SELECT  @secondItemList = STUFF( (SELECT '','' + CAST(mb.InternalRecordId as varchar(max)) FROM [' + @firstSnapshotName + '] m with (nolock) INNER JOIN [' + @secondSnapshotName + '] mb with (nolock) ON m.[Manufacturer Id] = mb.[Manufacturer Id] WHERE (m.InternalRecordId IN (' + @stageItemList + ')) FOR XML PATH('''')), 1, 1, '''')';
			EXEC sp_executesql @sql, @params = N'@secondItemList varchar(max) OUTPUT', @secondItemList = @secondItemList OUTPUT;
			if (@debug is not null) PRINT  '70: @secondItemList=' + @secondItemList	
			END
		ELSE
			BEGIN
			IF (@stageRepository = 'PIM_ManufacturerBrand_Staging')
				BEGIN
				SET @prodRepo='PIM_ManufacturerBrand_Production';
			SET @secondStageRepo=NULL;
			SET @secondProdRepo=NULL;
			SET @secondItemList = NULL;
			END
		ELSE
			BEGIN
			IF (@stageRepository = 'PIM_Vendor_Staging')
				BEGIN
				SET @prodRepo='PIM_Vendor_Production';
				SET @secondStageRepo=NULL;
				SET @secondProdRepo=NULL;
				SET @secondItemList = NULL;
				END
			ELSE
				BEGIN
				IF (@stageRepository = 'PIM_ProductLine_Staging')
					BEGIN
					SET @prodRepo='PIM_ProductLine_Production';
					SET @secondStageRepo=NULL;
					SET @secondProdRepo=NULL;
					SET @secondItemList = NULL;
					END
				ELSE
					BEGIN
					IF (@stageRepository = 'PIM_Product_Staging')
						BEGIN
						SET @prodRepo='PIM_Product_Production';
						SET @secondStageRepo='PIM_TaxonomyCatalog_Staging';
						SET @secondProdRepo='PIM_TaxonomyCatalog_Production';
						SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
						SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
							if (@debug is not null) PRINT  '106: @stageItemList=' + @stageItemList
							SET @sql = 'SELECT  @secondItemList = STUFF( (SELECT '','' + CAST(h.InternalRecordId as varchar(max)) FROM [' + @firstSnapshotName + '] s with (nolock) INNER JOIN [' + @secondSnapshotName + '] h with (nolock) ON s.[SKU Group Auto-Id] = h.[Product ID] WHERE (s.InternalRecordId IN (' + @stageItemList + ')) FOR XML PATH('''')), 1, 1, '''')';
						EXEC sp_executesql @sql, @params = N'@secondItemList varchar(max) OUTPUT', @secondItemList = @secondItemList OUTPUT;
							if (@debug is not null) PRINT  '109: @secondItemList=' + @secondItemList	
						END
					ELSE
						BEGIN
						IF (@stageRepository = 'PIM_Item_Staging')
							BEGIN
							SET @prodRepo='PIM_Item_Production';
							SET @secondStageRepo='PIM_Extended_Staging';
							SET @secondProdRepo='PIM_Extended_Production';
							SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
							SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
								if (@debug is not null) PRINT  '121: @stageItemList=' + @stageItemList
								SET @sql = 'SELECT  @secondItemList = STUFF( (SELECT '','' + CAST(e.InternalRecordId as varchar(max)) FROM [' + @secondSnapshotName + '] e with (nolock) INNER JOIN [' + @firstSnapshotName + '] i with (nolock) ON e.[Master Item Id] = i.[Master Item Id] WHERE (i.InternalRecordId IN (' + @stageItemList + ')) FOR XML PATH('''')), 1, 1, '''')';
								if (@debug is not null) PRINT  '124: @@sql=' + @sql	
							EXEC sp_executesql @sql, @params = N'@secondItemList varchar(max) OUTPUT', @secondItemList = @secondItemList OUTPUT;
								if (@debug is not null) PRINT  '124: @secondItemList=' + @secondItemList	
							END
						ELSE
							BEGIN
							IF (@stageRepository = 'PIM_Extended_Staging')
								BEGIN
								SET @prodRepo='PIM_Extended_Production';
								SET @secondStageRepo=NULL;
								SET @secondProdRepo=NULL;
								SET @secondItemList = NULL;
								END
							ELSE
								BEGIN
									IF (@stageRepository = 'PIM_TaxonomyCatalog_Staging')
									BEGIN
										SET @prodRepo='PIM_TaxonomyCatalog_Production';
										SET @secondStageRepo=NULL;
										SET @secondProdRepo=NULL;
										SET @secondItemList = NULL;
									END
									ELSE
									BEGIN
										RAISERROR('Reopo not found: %s', 16, 1, @stageRepository);
									END
								END
							END
						END
					END
				END
			END
		END
		END
		

    
    
    SELECT @stageRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @stageRepository;
    if (@stageRepoId is not null)
    BEGIN
		SELECT @workflowStatusId=f.FORMAT_ATTR_ID FROM B_FORMAT_ATTR f with (nolock) INNER JOIN B_MASTER_REPOSITORY m with (nolock) ON f.PROFILE_ID=m.PROFILE_ID WHERE m.MASTER_REPOSITORY_ID=@stageRepoId AND f.NAME = N'WorkFlow Status';
		if (@debug is not null) PRINT  '152: @secondStageRepo=' + @secondStageRepo    
		SET @statusStagToUpdateXml='<Status><keyValuePair><statusAttrName>RECORD_STATE</statusAttrName><statusValue>0</statusValue></keyValuePair></Status>';
		SET @otherStagAttrsToUpdateXml='<Attrs><keyValuePair><attrSystemName>F_' + CAST(@workflowStatusId as varchar) + '</attrSystemName><attrValue>0</attrValue></keyValuePair></Attrs>';
		if (@debug is not null) PRINT  '155: @statusStagToUpdateXml=' + cast(@statusStagToUpdateXml as varchar(max))
		if (@debug is not null) PRINT  '156: @otherStagAttrsToUpdateXml=' + cast(@otherStagAttrsToUpdateXml as varchar(max))
		if (@debug is not null) PRINT  '157: Promote Main'
		create table #tmpPromote(tmpResultLog nvarchar(max))
		if (@debug is not null) PRINT  '159: @stageRepository=' + @stageRepository
		if (@debug is not null) PRINT  '160: @prodRepo=' + @prodRepo
		insert into #tmpPromote EXEC epim_promote_bulk @stageRepository, @prodRepo, null, @stageItemList, 1, @otherStagAttrsToUpdateXml,@otherStagAttrsToUpdateXml,@statusStagToUpdateXml,@statusStagToUpdateXml,0,@prodSavedSet output, @prodItemList output
		SELECT @prodRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @prodRepo;
		IF (@secondStageRepo is not null AND @secondItemList is not null)
			BEGIN
				if (@debug is not null) PRINT  '185: Promote Second'
				if (@debug is not null) PRINT  '186: @secondItemList=' + @secondItemList
				if (@debug is not null) PRINT  '187: @secondStageRepo=' + @secondStageRepo
				if (@debug is not null) PRINT  '188: @secondProdRepo=' + @secondProdRepo
				SELECT @secondProdRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @secondProdRepo;
				if (@debug is not null) PRINT  '190: @secondProdRepoId=' + CAST(@secondProdRepoId as varchar)
				SELECT @workflowStatusId=f.FORMAT_ATTR_ID FROM B_FORMAT_ATTR f with (nolock) INNER JOIN B_MASTER_REPOSITORY m with (nolock) ON f.PROFILE_ID=m.PROFILE_ID WHERE m.MASTER_REPOSITORY_ID=@secondProdRepoId AND f.NAME = N'WorkFlow Status'; 
				SET @otherStagAttrsToUpdateXml='<Attrs><keyValuePair><attrSystemName>F_' + CAST(@workflowStatusId as varchar) + '</attrSystemName><attrValue>0</attrValue></keyValuePair></Attrs>';
				if (@debug is not null) PRINT  '193: @otherStagAttrsToUpdateXml=' + cast(@otherStagAttrsToUpdateXml as varchar(max))
				insert into #tmpPromote EXEC epim_promote_bulk @secondStageRepo, @secondProdRepo, null, @secondItemList, 0, @otherStagAttrsToUpdateXml,@otherStagAttrsToUpdateXml,@statusStagToUpdateXml,@statusStagToUpdateXml,0,@prodSavedSet output, @secondProdItemList output
			END
		drop table #tmpPromote;
	END
    if (@debug is not null) PRINT  '217: done'
	SELECT @prodRepo as ProdRepo, @prodRepoId as ProdRepoId, @prodItemList as ProdItemList, @secondProdRepo as SecondProdRepo, @secondProdRepoId as SecondProdRepoId, @secondProdItemList as SecondProdItemList
END


go

