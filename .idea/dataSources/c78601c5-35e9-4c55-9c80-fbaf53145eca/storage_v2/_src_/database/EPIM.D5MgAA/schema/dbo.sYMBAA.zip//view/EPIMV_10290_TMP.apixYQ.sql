create view EPIMV_10290_TMP as select ID, PLT_10292_TMP."F_1" as F_1004364 from PLT_10292_TMP
go

