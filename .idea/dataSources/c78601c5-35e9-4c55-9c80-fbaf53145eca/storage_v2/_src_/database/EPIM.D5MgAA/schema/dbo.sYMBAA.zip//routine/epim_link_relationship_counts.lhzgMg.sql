

CREATE PROCEDURE [dbo].[epim_link_relationship_counts] 
	@repoId bigint,
        @linkRelationshipId bigint,
	@maxCount bigint,
	@savedSetId bigint
AS
BEGIN
	DECLARE @debug int;
	DECLARE @linkrepoId bigint;
	DECLARE @links_key_table TABLE (idx smallint Primary Key IDENTITY(1,1), parentLinkKey bigint, childLinkKey bigint)
	DECLARE @i int;
	DECLARE @numrows int;
	DECLARE @parentLinkKey bigint;
	DECLARE @childLinkKey bigint;
	DECLARE @strSql nvarchar(MAX);
	DECLARE @strSelectSql nvarchar(MAX);
	DECLARE @strJoin1Sql nvarchar(MAX);
	DECLARE @strJoin2Sql nvarchar(MAX);
	DECLARE @repositoryName NVARCHAR(255);
	DECLARE @totalRecordCount BIGINT;
	DECLARE @parentDataType nvarchar(MAX);
	DECLARE @childDataType nvarchar(MAX);
	DECLARE @parentCol nvarchar(MAX);
	DECLARE @childCol nvarchar(MAX);
	DECLARE @varcharIdx int;


	SET @debug=1;
	if (@debug is null) SET NOCOUNT ON;	
	
	--get repo name
	SELECT @repositoryName=NAME FROM B_MASTER_REPOSITORY with (nolock) WHERE MASTER_REPOSITORY_ID = @repoId;
	if (@repoId is null)  RAISERROR('Repository not found: %d', 16, 1, @repoId);
	if (@debug is not null) PRINT 'repoName=' + @repositoryName;
	
	--get linkrepo ID
	SELECT @linkrepoId=CHILD_REPOSITORY_ID FROM B_LINK_CHILD_REPOSITORY with (nolock) WHERE LINK_RELATIONSHIP_ID = @linkRelationshipId;
	if (@linkrepoId is null)  RAISERROR('Specified Link reltionship not found for : %s', 16, 1, @repositoryName);
	if (@debug is not null) PRINT 'linkrepoId=' + CAST(@linkrepoId AS VARCHAR);
	if (@debug is not null) PRINT 'linkRelationshipId=' + CAST(@linkRelationshipId AS VARCHAR);
	
		
	--get link attributes
	INSERT @links_key_table SELECT PARENT_FORMAT_ATTR_ID, CHILD_FORMAT_ATTR_ID  FROM B_LINK_JOIN_CONDITION WHERE (LINK_RELATIONSHIP_ID = @linkRelationshipId);
	SET @i = 1;
	
	SET @numrows = (SELECT COUNT(*) FROM @links_key_table)
	IF @numrows > 0
		BEGIN
			WHILE (@i <= (SELECT MAX(idx) FROM @links_key_table))
			BEGIN
				SELECT @parentLinkKey=parentLinkKey, @childLinkKey=childLinkKey FROM @links_key_table WHERE idx = @i
				SELECT @parentDataType = data_type FROM B_FORMAT_ATTR WHERE FORMAT_ATTR_ID = @parentLinkKey;
				SELECT @childDataType = data_type FROM B_FORMAT_ATTR WHERE FORMAT_ATTR_ID = @childLinkKey;
				SET @parentCol = 'i.F_' + CAST(@parentLinkKey as varchar);
				SET @childCol = 'F_' + CAST(@childLinkKey as varchar);
				if (@parentDataType <> @childDataType)
				BEGIN
					SET @varcharIdx = CHARINDEX('VARCHAR', @childDataType);
					print 'varcharIdx = ' + cast(@varcharIdx as nvarchar);
					if (@varcharIdx > -1)
						SET @parentCol = 'cast(' + @parentCol + ' as NVARCHAR)';
					else
						SET @childCol = 'cast(' + @childCol + ' as NVARCHAR)';
				END
				if (@i>1)
				BEGIN
					SET @strSelectSql = @strSelectSql + ', ';
					SET @strJoin1Sql = @strJoin1Sql + ' AND ';
					SET @strJoin2Sql = @strJoin2Sql + ' AND ';
				END
				SET @strSelectSql = @childCol;
				SET @strJoin1Sql = @parentCol + ' = ' + @childCol;
				SET @strJoin2Sql = @parentCol + ' = ' + 'd.' + @childCol;
				SET @i = @i + 1
			END
		END
	ELSE
		BEGIN
			RAISERROR('Join Link attributes not found for reltionship : %s', 16, 1, @repositoryName);
		END

	CREATE TABLE #LinksCountTbl 
	( 
		ID BIGINT IDENTITY(1,1) NOT NULL,
		LinkCount BIGINT,
		ItemCount BIGINT
		PRIMARY KEY (ID)
	)
	CREATE TABLE #LinksCountOrderTbl 
	( 
		ID BIGINT NOT NULL,
		PRIMARY KEY (ID)
	)
	SET @i=0;
	WHILE (@i <= @maxCount-1)
	BEGIN
		INSERT INTO #LinksCountOrderTbl values (@i);
		SET @i = @i + 1;
	END
	
	

	if (@savedSetId>0)
	   SET @strSql = 'INSERT INTO #LinksCountTbl (LinkCount,ItemCount) 
			(
			SELECT distinct a.LinkCount, COUNT(*) over(partition by a.LinkCount) as ItemCount
			FROM
    			(SELECT distinct i.ITEM_ID, 0 as LinkCount
			FROM B_SNAPSHOT_' + CAST(@repoId as varchar) + ' AS i, B_SAVED_SET_ITEM ssi where
			i.item_id=ssi.item_id AND ssi.saved_set_id=' + CAST(@savedSetId as varchar) + ' AND not exists
				(
					SELECT   ITEM_ID, ' + @strSelectSql + '
					FROM     B_SNAPSHOT_' + CAST(@linkrepoId as varchar) + '
					WHERE    ' + @strJoin1Sql + '
				) 
		       union all
			SELECT	i.ITEM_ID, COUNT(*) AS LinkCount
			FROM	B_SNAPSHOT_' + CAST(@repoId as varchar) + ' AS i INNER JOIN
				(
					SELECT     ITEM_ID, ' + @strSelectSql + '
					FROM       B_SNAPSHOT_' + CAST(@linkrepoId as varchar) + '
				) AS d ON ' + @strJoin2Sql + ', B_SAVED_SET_ITEM ssi where
             i.item_id=ssi.item_id AND ssi.saved_set_id=' + CAST(@savedSetId as varchar) + '
			GROUP BY i.ITEM_ID    ) as a)';
	else
	   SET @strSql = 'INSERT INTO #LinksCountTbl (LinkCount,ItemCount) 
			(
			SELECT distinct a.LinkCount, COUNT(*) over(partition by a.LinkCount) as ItemCount
			FROM
    			(SELECT  distinct i.ITEM_ID, 0 as LinkCount
			FROM B_SNAPSHOT_' + CAST(@repoId as varchar) + ' AS i where not exists
				(
					SELECT   ITEM_ID, ' + @strSelectSql + '
					FROM     B_SNAPSHOT_' + CAST(@linkrepoId as varchar) + '
					WHERE    ' + @strJoin1Sql + '
				) 
		      union all
			SELECT	i.ITEM_ID, COUNT(*) AS LinkCount
			FROM	B_SNAPSHOT_' + CAST(@repoId as varchar) + ' AS i INNER JOIN
				(
					SELECT     ITEM_ID, ' + @strSelectSql + '
					FROM          B_SNAPSHOT_' + CAST(@linkrepoId as varchar) + '
				) AS d ON ' + @strJoin2Sql + '
			GROUP BY i.ITEM_ID    ) as a)';
	
	if (@debug is not null) PRINT @strSql;
	EXEC (@strSql);
	
	SELECT @totalRecordCount= COUNT(*) FROM	B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId;

	--select * from #LinkCountOrderTbl;
	
	SELECT     
		CAST(c.ID as varchar) as LinksCount, 
		c.ID as LinkCount,
		ISNULL(i.ItemCount,0) as ItemCount,
		CAST(CAST(ISNULL(i.ItemCount,0) as FLOAT)/@totalRecordCount as DECIMAL(10,5)) as pct,
		@totalRecordCount as totalCount
		
	FROM         
		#LinksCountOrderTbl as c LEFT OUTER JOIN #LinksCountTbl as i ON c.ID = i.LinkCount
	UNION ALL	
	SELECT 
		' >= ' + CAST(@maxCount as varchar)  as LinksCount, 
		@maxCount as LinkCount, 
		ISNULL(SUM(ItemCount),0),
		CAST(CAST(ISNULL(SUM(ItemCount),0) as FLOAT)/@totalRecordCount as DECIMAL(10,5)) as pct,
		@totalRecordCount as totalCount
	FROM #LinksCountTbl 
	WHERE LinkCount>=@maxCount
	ORDER BY LinkCount;	

END
go

