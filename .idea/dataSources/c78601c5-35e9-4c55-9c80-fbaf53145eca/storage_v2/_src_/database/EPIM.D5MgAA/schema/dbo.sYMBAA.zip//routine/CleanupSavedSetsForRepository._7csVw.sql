
CREATE PROCEDURE [dbo].[CleanupSavedSetsForRepository]
   @repositoryName VARCHAR(max),
   @savedSetName VARCHAR(max),
   @numberOfMinutes bigint
AS
BEGIN
      DECLARE @repositoryId as int
      CREATE TABLE #Messages(
      		id bigint IDENTITY(1,1) NOT NULL,
      		Message varchar(max))
      CREATE TABLE #SavedSetIds (id bigint)
      
      DECLARE @cutoffDate as datetime;
      DECLARE @minusMinutes as bigint;
      
      if (@repositoryName is not null)
      begin
      		
      		-- Repository found - now obtain cutoff date
      		set @minusMinutes = -1440;
      		if (@numberOfMinutes is not null)
      		begin
      			set @minusMinutes = -1 * @numberOfMinutes;
      		end
      		set @cutOffDate = DATEADD(minute,@minusMinutes,GETDATE())
      		insert into #Messages(Message) values('Cleanup of repository ' + @repositoryName + '  of saved sets named: "' + @savedSetName + '" older than ' + cast(@numberOfMinutes as varchar) + '  minutes.')
      		
      		-- Find qualifying saved set IDs
      		
      		INSERT INTO #SavedSetIds select DISTINCT ss.SAVED_SET_ID
			from B_SAVED_SET ss
			join B_SAVED_SET_REPO ssr on ss.SAVED_SET_ID = ssr.SAVED_SET_ID
			join B_MASTER_REPOSITORY mr on ssr.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
			where mr.name LIKE @repositoryName
			and ss.NAME like @savedSetName
			and ss.CREATION_DATETIME < @cutoffDate
      		
      		insert into #Messages(Message) values('Found ' + cast(@@ROWCOUNT as VARCHAR) + ' saved sets to be deleted.');
      		
      		-- Delete Saved Set Item Records
      		
      		DELETE FROM B_SAVED_SET_ITEM WHERE SAVED_SET_ID IN (SELECT ID FROM #SavedSetIds);
      		
      		insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from B_SAVED_SET_ITEM table.');
      		
      		-- Delete Saved Set Repo records
      		
      		DELETE FROM B_SAVED_SET_REPO WHERE SAVED_SET_ID IN (SELECT ID FROM #SavedSetIds);
      		
      		insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from B_SAVED_SET_REPO table.');
      		
      		-- Delete Saved Set Records
      		
      		DELETE FROM B_SAVED_SET WHERE SAVED_SET_ID IN (SELECT ID FROM #SavedSetIds);

      		insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from B_SAVED_SET table.');
      end	
      else
      begin
      	insert into #Messages(Message) values('Repository Name not specified');
      end

	-- Return message
	
	select Message from #Messages order by id
	

	DROP TABLE #Messages;
	DROP TABLE #SavedSetIds
END

go

