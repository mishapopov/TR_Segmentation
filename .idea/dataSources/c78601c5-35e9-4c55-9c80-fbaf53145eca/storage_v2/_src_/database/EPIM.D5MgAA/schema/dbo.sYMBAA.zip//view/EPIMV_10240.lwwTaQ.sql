create view EPIMV_10240 as select ID, PLT_10242."F_12498" as F_1004524, PLT_10242."F_1" as F_1004523 from PLT_10242
go

