CREATE VIEW dbo.[REFERENCE_TARGET_AUDIENCE] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004544 AS [EPM_Reference_Code], F_1004545 AS [System_Name], F_1004546 AS [Value] FROM dbo.B_SNAPSHOT_10169 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_TARGET_AUDIENCE to dbadmin
go

grant select on REFERENCE_TARGET_AUDIENCE to ewsys
go

grant select on REFERENCE_TARGET_AUDIENCE to boomi
go

grant select on REFERENCE_TARGET_AUDIENCE to informatica
go

grant select on REFERENCE_TARGET_AUDIENCE to som
go

grant select on REFERENCE_TARGET_AUDIENCE to apttus
go

grant select on REFERENCE_TARGET_AUDIENCE to epmdev
go

grant select on REFERENCE_TARGET_AUDIENCE to MDMAdmin
go

grant select on REFERENCE_TARGET_AUDIENCE to produser1
go

grant select on REFERENCE_TARGET_AUDIENCE to produser3
go

grant select on REFERENCE_TARGET_AUDIENCE to produser2
go

grant select on REFERENCE_TARGET_AUDIENCE to VIEW_ACCESS
go

grant select on REFERENCE_TARGET_AUDIENCE to integration_team
go

grant select on REFERENCE_TARGET_AUDIENCE to ecmxread
go

grant select on REFERENCE_TARGET_AUDIENCE to MPOPOV_TEST
go

grant select on REFERENCE_TARGET_AUDIENCE to digital
go

