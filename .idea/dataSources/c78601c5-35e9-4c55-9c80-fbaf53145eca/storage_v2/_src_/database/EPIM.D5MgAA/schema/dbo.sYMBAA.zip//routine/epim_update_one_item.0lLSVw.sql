
create procedure epim_update_one_item 
    (@itemIdP int, @attrSysNameP nvarchar(50), @attrValueP nvarchar(400), @optionsP int, 
	 @doUpdateOrInsertP int, @repositoryIdP nvarchar(50), @doAttrDataP int, @doSnapshotP int)
as  
begin

  declare @attrSql nvarchar(max);
  declare @shouldCreateHistory int;
  declare @dateStr nvarchar(200);
  declare @itemIdStr nvarchar(50);
  DECLARE @includeKV bigint;
  DECLARE @kvName nvarchar(max);
  declare @fmtAttrIdFromSysName integer;
  declare @attrRealName nvarchar(max);
  declare @attrRestrictedName nvarchar(max);
  
  	   
	set @shouldCreateHistory = 0;
	set @dateStr = '';
	set @itemIdStr = cast(@itemIdP as varchar);
      
	if (@optionsP is null or @optionsP=0)
		set @shouldCreateHistory = 0;
	else
	begin
		print ('createHistoryValue = ' + cast(@optionsP as varchar));
		-- look for CreateHistory option value of 1
		if (@optionsP = 1)
		begin
			set @shouldCreateHistory = 1;
			set @dateStr = 'attr_last_update_datetime = getDate(), last_update_datetime = getDate(), ';
		end
	end
	print ('shouldCreateHistory = ' + cast(@shouldCreateHistory as nvarchar));
	print ('dateStr = ' + @dateStr);   
	print 'attrSysNameP = ' + @attrSysNameP;
   
    if (@shouldCreateHistory = 1) 
    begin
       set @attrSql = 'declare @history table(item_history_id bigint, item_id bigint) insert into b_repository_item_history( MASTER_REPOSITORY_ID,ATTR_DATA, MODIFICATION_DATETIME, MODIFIED_BY, MODIFY_ACTION, ITEM_ID,RECLOCK,USER_LOGIN,RECORD_STATE,PRODUCTION_STATE,WORKFLOW_STATE, MESSAGE_ID,TRANSACTION_ID,STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO) ' +
	'output INSERTED.repository_item_history_id, INSERTED.item_id into @history select REPOSITORY_ID,ATTR_DATA, case when bmi.LAST_UPDATE_DATETIME is null then bmi.CREATION_DATETIME else bmi.LAST_UPDATE_DATETIME end, case when bmi.LAST_UPDATE_BY is null then bmi.CREATED_BY else bmi.LAST_UPDATE_BY end, MODIFY_ACTION, ITEM_ID,bmi.RECLOCK,bu.LOGIN,RECORD_STATE,PRODUCTION_STATE,WORKFLOW_STATE, MESSAGE_ID,TRANSACTION_ID,STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO ' +
	'from b_master_repository_item bmi, b_user bu where item_id = '+ @itemIdStr + 
	' and (bu.user_id = bmi.LAST_UPDATE_BY or bu.user_id = bmi.CREATED_BY) select * from @history';
       print @attrSql;
 
       exec (@attrSql);
    end

	-- update epim xml
	if (@doAttrDataP = 1)
	begin
		if (@doUpdateOrInsertP = 0)
		begin
			set @attrSql = 'update b_master_repository_item set ' + @dateStr +
							'attr_data.modify(''replace value of (/Item/' + @attrSysNameP + 
							'/text())[1] with "'+@attrValueP+'" '')  where attr_data is not null and item_id = '+ @itemIdStr;
			print @attrSql;
			exec (@attrSql);
		end;
	  
		else
		begin
		-- do insert if needed
		  set @attrSql = 'update b_master_repository_item set ' + @dateStr +
						' attr_data.modify(''insert <' + @attrSysNameP + '>' +@attrValueP+
						'</' + @attrSysNameP + '>  into (/Item)[1]'') where attr_data is not null and item_id = '+ @itemIdStr + ' and attr_data.exist(''/Item/' + @attrSysNameP + 
						''') !=1  ';
		  print @attrSql;
		  exec (@attrSql);
		end;
    end;
  
	if (@doSnapshotP = 1)
	begin
		-- update snapshot table column 
		if exists(select * from INFORMATION_SCHEMA.columns where TABLE_NAME='B_SNAPSHOT_'+@repositoryIdP and COLUMN_NAME=@attrSysNameP)
		begin
			set @attrSql = 'update B_SNAPSHOT_'+@repositoryIdP+' set '+@attrSysNameP+'='''+@attrValueP+''''+
			 ', DATA_LAST_UPDATE_DATETIME=getDate() where item_id ='+@itemIdStr;
			print @attrSql;
			exec (@attrSql);
		end
		else
		begin
			SELECT @includeKV = INCLUDE_SNAPSHOT_KV_IND from B_MASTER_REPOSITORY where master_repository_id = cast(@repositoryIdP as integer);
			if (@includeKV is null)
				SET @includeKV = 0;
			if (@includeKV = 1)
			BEGIN
			    SET @kvName = 'B_SNAPSHOT_' + CAST(@repositoryIdP as varchar) + '_KV';
			    SELECT @includeKV = id from sysobjects where name = @kvName;
			    if (@includeKV is null)
				    SET @includeKV = 0;
			    if (@includeKV > 0)
			    BEGIN
				    SET @fmtAttrIdFromSysName = cast(substring(@attrSysNameP, 3, len(@attrSysNameP)) as integer);
				    SELECT @attrRealName = name, @attrRestrictedName = restricted_name from B_FORMAT_ATTR where format_attr_id=@fmtAttrIdFromSysName;
			        if (@attrRestrictedName is null)
			            set @attrRestrictedName = '';
				    set @attrSql = 'delete from B_SNAPSHOT_'+@repositoryIdP+'_KV where KeyName=''' +
					    replace(@attrRealName,'''','''''') + ''' and item_id ='+@itemIdStr;
				    print ' delete from snapshot_KV: ' + @attrSql;
				    exec (@attrSql);
			
				    set @attrSql = 'insert into B_SNAPSHOT_'+@repositoryIdP+'_KV (ITEM_ID, KeyName,KeyRestrictedName,KeyValue) values (' +
					    @itemIdStr + ', ''' + replace(@attrRealName,'''','''''') + ''',''' + @attrRestrictedName + ''', '''+@attrValueP+''')';
				    print ' insert into snapshot_KV: ' + @attrSql;
				    exec (@attrSql);
				END
			END
		end
	end
 
 end
go

