create view EPIMV_10290 as select ID, PLT_10292."F_1" as F_1004364 from PLT_10292
go

