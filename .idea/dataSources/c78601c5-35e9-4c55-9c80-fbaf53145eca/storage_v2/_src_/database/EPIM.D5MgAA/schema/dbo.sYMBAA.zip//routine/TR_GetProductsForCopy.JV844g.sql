


CREATE PROCEDURE [dbo].[TR_GetProductsForCopy]
    @itemIds VARCHAR(200),  -- Delimited list of source product variants
    @savedSetId varchar(max), -- Saved set ID of source product variants
    @source VARCHAR(10), -- Name of source (Staging, Clone, Change)
    @target VARCHAR(10) -- Name of target (Clone, Change, State)
AS BEGIN

    -- TR_GetProductsForCopy - Retrieves the source and target Product Variant records
    -- for the specified list of Item IDs or the saved set from the designated source repository
    -- to be copied to the designated target repository.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_GetProductsForCopy '5707032,5707033,5707034',null,'Staging','Clone'
    --
    --  EXEC TR_GetProductsForCopy '5785511',0,'Clone','Staging'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductsForCopy '%itemIds%',%savedSetId%,'Staging','State'

    DECLARE @sql VARCHAR(max)

    -- Determine if saved set was specified

    IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds
            SET @sql = 'select s.InternalRecordId as source, t.InternalRecordId as target, ' +
                       's.Product_ID ' +
                       'FROM PRODUCT_' + @source + ' s ' +
                       'LEFT OUTER JOIN PRODUCT_' + @target + ' t ' +
                       'ON s.Product_ID = t.Product_ID ' +
                       'WHERE s.InternalRecordId in (' + @itemIds + ')'
        END
    ELSE
        BEGIN
            -- Code set - use it
            SET @sql = 'select s.InternalRecordId as source, t.InternalRecordId as target, ' +
                       's.Product_ID ' +
                       'FROM PRODUCT_' + @source + ' s ' +
                       'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = s.InternalRecordId ' +
                       'LEFT OUTER JOIN PRODUCT_' + @target + ' t ' +
                       'ON s.Product_ID = t.Product_ID ' +
                       'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR)
        END

    print @sql
    EXECUTE (@sql)

END
go

