
CREATE PROCEDURE dbo.ClearWorkflowLock 
	@activityName NVARCHAR(100)
AS
BEGIN
	UPDATE WorkflowLocks SET lockStatus = 'FREE' WHERE activityName = @activityName
	SELECT * FROM WorkflowLocks
END
go

