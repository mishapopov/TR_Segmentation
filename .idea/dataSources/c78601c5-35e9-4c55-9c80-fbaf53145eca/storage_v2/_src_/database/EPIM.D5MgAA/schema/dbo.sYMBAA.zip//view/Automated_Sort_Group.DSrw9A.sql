CREATE VIEW dbo.[Automated Sort Group] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1000504 AS [Attribute_ID], F_1000505 AS [Field_Type], F_1000506 AS [Field_Value], F_1000507 AS [Group_ID], F_1000508 AS [Group_Name], F_1000509 AS [SequenceNum], F_1000510 AS [Sort_Direction], F_1000511 AS [Sort_Sequence] FROM dbo.B_SNAPSHOT_10027 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

