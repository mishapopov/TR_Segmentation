
CREATE TRIGGER epim_au_buser ON B_USER FOR UPDATE
AS 

BEGIN
	declare @startId bigint;
	
	if @@ROWCOUNT = 0
		return
	SET NOCOUNT ON

	IF EXISTS ( SELECT * FROM INSERTED I JOIN DELETED D
                ON D.USER_ID = I.USER_ID AND D.login <> I.login )
    BEGIN
	    update b_obj_security set obj_display_name = i.login 
		from b_obj_security bos inner join Inserted i on
		bos.obj_name='Buser' and bos.obj_id = i.user_id 
		where bos.obj_display_name <> i.login;
		
		update b_job_history set user_login = i.login 
		from b_job_history bos inner join Inserted i on
		bos.user_id = i.user_id 
		where bos.user_login <> i.login;
		
		update b_obj_history set user_login = i.login 
		from b_obj_history bos inner join Inserted i on
		bos.modified_by = i.user_id 
		where bos.user_login <> i.login;
				
		SET @startId = (select min(repository_item_history_ID) from b_repository_item_history);
		WHILE @startId is not null
		begin
				BEGIN TRANSACTION
				update b_repository_item_history set user_login = i.login
				from b_repository_item_history bos inner join Inserted i on bos.modified_by = i.user_id
				where repository_item_history_ID >= @startId and repository_item_history_ID < (@startId+20000)
				COMMIT;
				SET @startId = (SELECT MIN(repository_item_history_ID) FROM  b_repository_item_history 
				                WHERE repository_item_history_id >= (@startId + 20000));
		end

	END
END
go

