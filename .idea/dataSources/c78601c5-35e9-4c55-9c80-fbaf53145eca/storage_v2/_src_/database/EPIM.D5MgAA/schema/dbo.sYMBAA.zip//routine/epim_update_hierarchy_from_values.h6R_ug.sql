--#BEGIN#
create procedure [dbo].[epim_update_hierarchy_from_values] 
    (@tableName nvarchar(max), @columnName nvarchar(max), @hierarchyName nvarchar(max), @debug int)
as  
begin
-- @distinctValuesSql is a query that returns all distinct values of hierarchy codeSetDetail.code values
-- @hierarchyName the name of the EPIM codeSet. 
--
  declare @qrySql nvarchar(max);
  declare @codeSetId bigint;
  declare @Id bigint;
  declare @missingCode nvarchar(max);
  declare @subCode nvarchar(max);
  declare @thisCode nvarchar(max);
  declare @parentCode nvarchar(max);
  declare @delimiter nvarchar(20);
  declare @delimiterIndex bigint;
  declare @ownerName nvarchar(50);
  declare @ownerUseInd bigint;
  declare @maxSeqNum bigint;
  
		SET @ownerName = null;
		SELECT @codeSetId = code_set_id, @delimiter = delimiter, @ownerUseInd = owner_use_ind from b_code_set 
		where name = @hierarchyName;
		
		if (@codeSetId is null)  RAISERROR('Hierarchy not found: %s', 16, 1, @hierarchyName);
		if (@debug is not null) PRINT 'Code Set id=' + CAST(@codeSetId AS VARCHAR);
		
		SELECT @maxSeqNum = max(sequence_num) from b_code_set_detail where code_set_id = @codeSetId;
		SET @maxSeqNum = @maxSeqNum+1;
		if (@debug is not null) PRINT 'MaxSeqNum=' + CAST(@maxSeqNum AS VARCHAR);
  
		if (@ownerUseInd is not null)
		BEGIN
		    if (@ownerUseInd = 1)
			    SET @ownerName = 'system';
		END
		   
		if (@debug is not null) PRINT 'Create temp table';
		CREATE TABLE #MissingValues
		(
			ID BIGINT IDENTITY(1,1) NOT NULL,
			CODE NVARCHAR(max)
			PRIMARY KEY (ID)
		)

		SET @qrySql = 'INSERT INTO #MissingValues (CODE) select distinct [' + @columnName + '] from ' +
					  @tableName + ' WHERE [' + @columnName + '] NOT IN ' +
					  '(select code from b_code_set_detail where code_set_id=' + cast(@codeSetId as varchar) + ')';
		if (@debug is not null) PRINT 'SQL: ' + @qrySql;
		EXEC (@qrySql);

		SET @Id = (SELECT MIN(id) FROM  #MissingValues );
		WHILE @Id is not null
		BEGIN
				SELECT @missingCode = CODE from #MissingValues where ID=@Id;
				if (@debug is not null) PRINT 'missing code: ' + @missingCode;
				SET @parentCode = null;
				
				DECLARE db_cursor CURSOR FOR SELECT ParsedString as thisCode FROM dbo.epim_parse_delimited_string (@missingCode, @delimiter); 
				OPEN db_cursor;
				FETCH NEXT FROM db_cursor INTO @subCode;
				WHILE @@FETCH_STATUS = 0  
				BEGIN  
					IF (@parentCode is null)
					BEGIN
						IF not exists (select code from b_code_set_detail where code_set_id = @codeSetId and 
					                   code = @subCode and (parent_code is null or len(parent_code) = 0))
						begin
							INSERT INTO B_CODE_SET_DETAIL (code_Set_id,parent_code,code,owner,navigation_element_ind,description,sequence_num)
									values (@codeSetId,@parentCode,@subCode,@ownerName,0,@subCode,@maxSeqNum);
							PRINT 'null parentCode;  inserting code: ' + @subCode;
							SET @maxSeqNum = @maxSeqNum+1;
						end
						ELSE
						    PRINT 'no need to insert ' + @subCode + ', already exists'
						SET @parentCode = @subCode;
					END
					ELSE
					BEGIN
						SET @thisCode = @parentCode + @delimiter + @subCode;
						IF not exists (select code from b_code_set_detail where code_set_id = @codeSetId and 
					                   code = @thisCode and parent_code = @parentCode)
						begin
							INSERT INTO B_CODE_SET_DETAIL (code_Set_id,parent_code,code,owner,navigation_element_ind,description,sequence_num)
							values (@codeSetId,@parentCode,@thisCode,@ownerName,0,@subCode,@maxSeqNum);
							PRINT 'inserting code: ' + @thisCode + ' with parentCode: ' + @parentCode;
							SET @maxSeqNum = @maxSeqNum+1;
						end
						else
							PRINT 'NO NEED TO insert code: ' + @thisCode + ' with parentCode: ' + @parentCode;
						SET @parentCode = @parentCode + @delimiter + @subCode;

					END
					
					FETCH NEXT FROM db_cursor INTO @subCode;
				END;
				CLOSE db_cursor;
				DEALLOCATE db_cursor;

			SET @Id = (SELECT MIN(id) FROM  #MissingValues WHERE  ID >= @Id+1);
		END

  end


go

