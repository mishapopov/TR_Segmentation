create view EPIM_REP_SV10173 as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1004547)') as nvarchar(MAX))  as F_1004547,  CAST(attr_data.query('data(Item/F_1004548)') as nvarchar(MAX))  as F_1004548,  CAST(attr_data.query('data(Item/F_1004549)') as nvarchar(MAX))  as F_1004549 from b_master_repository_item bmri where bmri.repository_id = 10173
go

