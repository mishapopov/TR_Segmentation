
-- The following stored procedure is used to extract historical data from a repository
-- for specified records and the specified "as of" date.
-- The following input parameters are expected:
--	repositoryName - name of the repository
--    	projectionList - comma-delimited list of attributes for which the data is to be extracted
--	searchKey - comma-delimited list of attributes and values that are used for the search parameters
--                 Each search parameter has the format <attribute>=<value> where <attribute> is the name of
--                 the attribute exactly as it is spelled in the specified repository, and <value> is the
--                 value to be found (the percent sign can be used as a wildcard).
-- 	searchSource - h to search against history, m to search against master repository (current values)
--	asOfDate - date and time in the format 'mm/dd/yyyy hh:mm:ss.mmm' specifying the date/time from which
--                 to obtain the values

--
-- For example, to extract the Customer Specific Price And Status for Active (at the time) records
-- Home Depot from the Archbrook_CustomerItemSpecific_Staging repository as it was defined on 9/25/2009 at 12:00 noon, 
-- for the purposes of submitting an import file to restore those prices, execute the following command:
--
--	ExtractHistoricalData N'PIM_Item_Staging','Product,User Desc,Memo Expires,Status', 
--            'Status=a','m','12/12/2010 20:00:00.000'
--
-- 
-- The procedure will perform a query against the Item History table and extract the specified data for the
-- specified fields
--
-- The results of executing this procedure can be copied/pasted to an Excel spreadsheet and saved to 
-- be used as an import file.  This effectively "rolls back" the specified non-primary key fields to their
-- values at the specified date and time.
 

create procedure ExtractHistoricalData

      @repositoryName nvarchar(255),
      @projectionList nvarchar(1000),
      @searchKey nvarchar(1000),
      @source nvarchar(1),
      @asOfDate nvarchar(50)
as

begin


    DECLARE @querySql VARCHAR(MAX) -- holds the SQL statement for creating the view
    DECLARE @attributeName VARCHAR(255)
    DECLARe @systemName VARCHAR(50)
    DECLARE @attributeId VARCHAR(10)
    DECLARE @repositoryId VARCHAR(10)
    DECLARE @key VARCHAR(255)
    DECLARE @value VARCHAR(2000)

    -- Get the repository ID
    SELECT @repositoryId = cast(master_repository_id as VARCHAR) from b_master_repository where name = @repositoryName

    -- Create the SQL perform the extraction query
    
    SET @querySql = 'select m.item_id';
            
    DECLARE @position int
    DECLARE @keyPosition int
    SET @position = 1
    SET @projectionList = @projectionList + ',';
    WHILE charindex(',',@projectionList,@position) <> 0
       BEGIN
          SET @attributeName = substring(@projectionList, @position, charindex(',',@projectionList,@position) - @position);
          
          -- Get the system name for the attribute
   
          SET @systemName = '****ATTRIBUTE ' + @attributeName + ' not found****';
          select @systemName = 'F_' + cast(f.format_attr_id as varchar) from b_format_attr f, b_master_repository m
	      WHERE f.profile_id = m.profile_id
	      AND m.name = @repositoryName
	      AND f.name = @attributeName
	  
	  SELECT attributeName=@attributeName,systemName=@systemName
	  
	  -- add to SQL
	  SET @querySql = @querySql + ', replace(replace(replace(replace(replace(h.attr_data.value(''(/Item/' + @systemName + 
	      ')[1]'', ''varchar(255)''),''&apos;'',''''''''),''&amp;'',''&''),''&quot;'',''"''),''&lt;'',''<''),''&gt;'',''>'') as [' +  @attributeName + ']';
	      
          -- Next attribute
          SET @position = charindex(',',@projectionList,@position) + 1
       END

    -- Add FROM clause
    
    SET @querySql = @querySql + ' from b_repository_item_history h, b_master_repository_item m ';
    
    -- Add search conditions

    DECLARE @whereClause varchar(2000)
    SET @whereClause = 'WHERE ';
    SET @position = 1
    SET @searchKey = @searchKey + ',';
    WHILE charindex(',',@searchKey,@position) <> 0
       BEGIN
          SET @key = substring(@searchKey, @position, charindex(',',@searchKey,@position) - @position);
          
          -- Split key into attribute/value
          SET @keyPosition = 1
          SET @key = @key + '=';

          SET @attributeName = substring(@key, @keyPosition, charindex('=',@key,@keyPosition) - @keyPosition);
          SET @keyPosition = charindex('=',@key,@keyPosition) + 1
          SET @value = substring(@key,@keyPosition, charindex('=',@key,@keyPosition) - @keyPosition);
          
          -- Get the system name for the attribute
   
          SET @systemName = '****ATTRIBUTE ' + @attributeName + ' not found****';
          select @systemName = 'F_' + cast(f.format_attr_id as varchar) from b_format_attr f, b_master_repository m
	  WHERE f.profile_id = m.profile_id
	  AND m.name = @repositoryName
	  AND f.name = @attributeName

          -- add condition to WHERE clause
          if @whereClause <> 'WHERE '
          BEGIN
              SET @whereClause = @whereClause + ' AND ';
          END
	  SET @whereClause = @whereClause + @source + '.attr_data.value(''(/Item/' + @systemName + 
	      ')[1]'', ''varchar(255)'') LIKE ''' +  @value + '''';
          
          -- Next key
          SET @position = charindex(',',@searchKey,@position) + 1
       END

    SET @querySql = @querySql + @whereClause
    
    -- Add condition to filter the item history

    SET @querySql = @querySql + ' AND h.repository_item_history_id = (select top 1 th.repository_item_history_id ' +
        'from b_repository_item_history th ' +
        'where th.item_id = m.item_id AND th.modification_datetime < ''' + @asOfDate + ''' order by th.modification_datetime desc)';
        
    -- Add condition to ensure historical item still exists

    SET @querySql = @querySql + ' AND h.item_id = m.item_id';
    
    -- Add condition to restrict to the specified repository
    
    SET @querySql = @querySql + ' AND h.master_repository_id = ''' + @repositoryId + '''';
    
        
    SELECT sql = @querySql
    
    EXECUTE (@querySql)     

end

go

