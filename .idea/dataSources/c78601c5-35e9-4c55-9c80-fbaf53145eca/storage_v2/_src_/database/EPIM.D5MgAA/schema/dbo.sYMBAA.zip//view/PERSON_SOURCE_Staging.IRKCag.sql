CREATE VIEW dbo.[PERSON_SOURCE_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004844 AS [Action], F_1004888 AS [Employee_ID], F_1004929 AS [Person_Source_ID], F_1004936 AS [Source_Record_ID], F_1004937 AS [Source_Type_Code] FROM dbo.B_SNAPSHOT_10254 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PERSON_SOURCE_Staging to dbadmin
go

grant select on PERSON_SOURCE_Staging to ewsys
go

grant select on PERSON_SOURCE_Staging to boomi
go

grant select on PERSON_SOURCE_Staging to informatica
go

grant select on PERSON_SOURCE_Staging to som
go

grant select on PERSON_SOURCE_Staging to apttus
go

grant select on PERSON_SOURCE_Staging to epmdev
go

grant select on PERSON_SOURCE_Staging to MDMAdmin
go

grant select on PERSON_SOURCE_Staging to produser1
go

grant select on PERSON_SOURCE_Staging to produser3
go

grant select on PERSON_SOURCE_Staging to produser2
go

grant select on PERSON_SOURCE_Staging to integration_team
go

grant select on PERSON_SOURCE_Staging to digital
go

