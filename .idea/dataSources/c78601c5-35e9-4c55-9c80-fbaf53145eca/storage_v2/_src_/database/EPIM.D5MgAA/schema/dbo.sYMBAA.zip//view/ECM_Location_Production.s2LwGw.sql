CREATE VIEW dbo.[ECM_Location_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005443 AS [Address_Line_1], F_1005444 AS [Address_Line_2], F_1005445 AS [Address_Line_3], F_1005446 AS [Address_Line_4], F_1005911 AS [Address_Trust_Score], F_1005720 AS [Address_Type], F_1005453 AS [Building_Number], F_1005447 AS [City_Name], F_1005632 AS [Continent], F_1005450 AS [Country_Code], F_1005451 AS [County_Name], F_1005456 AS [District_or_Neighborhood_Name], F_1005457 AS [Language_Code], F_1005458 AS [Latitude], F_1005659 AS [Local_Address_Line_1], F_1005651 AS [Local_Address_Line_2], F_1005652 AS [Local_Address_Line_3], F_1005653 AS [Local_Address_Line_4], F_1005654 AS [Local_City_Name], F_1005658 AS [Local_Country_Code], F_1005655 AS [Local_County_Name], F_1005656 AS [Local_State_Province_Code], F_1005657 AS [Local_Zip_Postal_Code], F_1005442 AS [Location_GUID], F_1005461 AS [Location_ID], F_1005479 AS [Location_Type], F_1005459 AS [Longitude], F_1005460 AS [Party_ID], F_1005452 AS [Post_Box_Number], F_1005462 AS [Standardized_Address_Line_1], F_1005463 AS [Standardized_Address_Line_2], F_1005464 AS [Standardized_Address_Line_3], F_1005465 AS [Standardized_Address_Line_4], F_1005466 AS [Standardized_Building_Number], F_1005467 AS [Standardized_City_Name], F_1005468 AS [Standardized_Country_Code], F_1005469 AS [Standardized_County_Name], F_1005470 AS [Standardized_District_or_Neighborhood_Name], F_1005471 AS [Standardized_Latitude], F_1005472 AS [Standardized_Longitude], F_1005473 AS [Standardized_Post_Box_Number], F_1005474 AS [Standardized_State_Province_Code], F_1005475 AS [Standardized_Street_Name], F_1005476 AS [Standardized_Suite_or_Floor_Number], F_1005477 AS [Standardized_Zip_Postal_Code], F_1005912 AS [Standardized_Zip_Postal_Code_st], F_1005448 AS [State_Province_Code], F_1005454 AS [Street_Name], F_1005455 AS [Suite_or_Floor_Number], F_1005449 AS [Zip_Postal_Code] FROM dbo.B_SNAPSHOT_10307 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on ECM_Location_Production to boomi
go

grant select on ECM_Location_Production to informatica
go

grant select on ECM_Location_Production to ecmxread
go

