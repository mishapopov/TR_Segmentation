CREATE VIEW dbo.[Request_Change] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004614 AS [Approval_Status_Other], F_1004613 AS [Approval_Status_Price], F_1004611 AS [Approval_Status_Tax], F_1004588 AS [Change_Product_Variant_Request_Type], F_1004587 AS [Request_ID], F_1004589 AS [Request_Status], F_1004590 AS [Requested_By] FROM dbo.B_SNAPSHOT_10214 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on Request_Change to informatica
go

