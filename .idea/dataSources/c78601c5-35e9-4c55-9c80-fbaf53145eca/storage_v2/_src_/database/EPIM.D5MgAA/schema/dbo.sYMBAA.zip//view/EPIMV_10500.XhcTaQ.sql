create view EPIMV_10500 as select ID, PLT_10502."F_13193" as F_1005207, PLT_10502."F_1" as F_1005201 from PLT_10502
go

