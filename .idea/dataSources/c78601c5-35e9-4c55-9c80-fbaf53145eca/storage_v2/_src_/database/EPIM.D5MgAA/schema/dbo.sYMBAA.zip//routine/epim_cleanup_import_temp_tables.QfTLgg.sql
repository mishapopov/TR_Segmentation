

create procedure epim_cleanup_import_temp_tables 
As
BEGIN
   declare @jobNumStr varchar(20);
   declare @tableName varchar(50); 
   declare @underscorePos int;
   declare @jobStatus int;
   declare @sql varchar(max);
   
   -- remove old UPDATES% tables
   DECLARE db_cursor CURSOR FOR  SELECT name FROM sysobjects WHERE name like 'UPDATES_%' AND type = 'U';
    
   OPEN db_cursor  
   FETCH NEXT FROM db_cursor INTO @tableName  

   WHILE @@FETCH_STATUS = 0  
   BEGIN  
	   -- find jobId that created this table
       SET @jobNumStr = SUBSTRING(@tableName, 9, LEN(@tableName));  
       SET @underscorePos = CHARINDEX('_',@jobNumStr);
       if (@underscorePos > 0) SET @jobNumStr = SUBSTRING(@jobNumStr, 1, @underscorePos-1);
       -- find status of the job
       SELECT @jobStatus = status from B_JOB where JOB_ID = CAST(@jobNumStr as INT);
       if (@jobStatus is null) SET @jobStatus = 1;
       print('jobNumStr = ' + @jobNumStr + ', status = ' + cast(@jobStatus as varchar)); 
       -- drop the table if the job is done
       if (@jobStatus = 1 or @jobStatus < 0)
       begin
			SET @sql = 'DROP TABLE ' + @tableName;
			--print('sql = ' + @sql);
			EXECUTE (@sql);
       end 

       FETCH NEXT FROM db_cursor INTO @tableName  
   END  
   CLOSE db_cursor;  
   DEALLOCATE db_cursor; 

   -- remove old PLT_CONFIG% tables
   DECLARE db_cursor2 CURSOR FOR  SELECT name FROM sysobjects WHERE name like 'PLT_CONFIG_%' AND type = 'U'

   OPEN db_cursor2  
   FETCH NEXT FROM db_cursor2 INTO @tableName  

   WHILE @@FETCH_STATUS = 0  
   BEGIN  
	   -- find jobId that created this table
       SET @jobNumStr = SUBSTRING(@tableName, 12, LEN(@tableName));  
       SET @underscorePos = CHARINDEX('_',@jobNumStr);
       SET @jobNumStr = SUBSTRING(@jobNumStr,@underscorePos+1, LEN(@jobNumStr));
       -- find status of the job
       SELECT @jobStatus = status from B_JOB where JOB_ID = CAST(@jobNumStr as INT);
       if (@jobStatus is null) SET @jobStatus = 1;
       print('jobNumStr = ' + @jobNumStr + ', status = ' + cast(@jobStatus as varchar)); 
       -- drop the table if the job is done
       if (@jobStatus = 1 or @jobStatus < 0)
       begin
			SET @sql = 'DROP TABLE ' + @tableName;
			--print('sql = ' + @sql);
			EXECUTE (@sql);
       end 

       FETCH NEXT FROM db_cursor2 INTO @tableName  
   END  
   CLOSE db_cursor2;  
   DEALLOCATE db_cursor2; 

      -- remove old PLT_CODESET% tables
   DECLARE db_cursor2 CURSOR FOR  SELECT name FROM sysobjects WHERE name like 'PLT_CODESET_%' AND type = 'U'

   OPEN db_cursor2  
   FETCH NEXT FROM db_cursor2 INTO @tableName  

   WHILE @@FETCH_STATUS = 0  
   BEGIN  
	   -- find jobId that created this table
       SET @jobNumStr = SUBSTRING(@tableName, 13, LEN(@tableName));  
       SET @underscorePos = CHARINDEX('_',@jobNumStr);
       SET @jobNumStr = SUBSTRING(@jobNumStr,@underscorePos+1, LEN(@jobNumStr));
       -- find status of the job
       SELECT @jobStatus = status from B_JOB where JOB_ID = CAST(@jobNumStr as INT);
       if (@jobStatus is null) SET @jobStatus = 1;
       print('jobNumStr = ' + @jobNumStr + ', status = ' + cast(@jobStatus as varchar)); 
       -- drop the table if the job is done
       if (@jobStatus = 1 or @jobStatus < 0)
       begin
			SET @sql = 'DROP TABLE ' + @tableName;
			--print('sql = ' + @sql);
			EXECUTE (@sql);
       end 

       FETCH NEXT FROM db_cursor2 INTO @tableName  
   END  
   CLOSE db_cursor2;  
   DEALLOCATE db_cursor2; 

END;

go

