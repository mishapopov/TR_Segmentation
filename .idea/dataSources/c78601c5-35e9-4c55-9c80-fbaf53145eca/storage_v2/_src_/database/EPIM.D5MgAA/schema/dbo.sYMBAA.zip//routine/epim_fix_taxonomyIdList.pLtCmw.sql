--#BEGIN#

create procedure [dbo].[epim_fix_taxonomyIdList]
	@repoName nvarchar(255)
AS
BEGIN

	DECLARE @repoId bigint;
	DECLARE @profileId bigint;
	DECLARE @fmtAttrId bigint;
	DECLARE @codeSetId bigint;
	DECLARE @id bigint;
	DECLARE @csValue NVARCHAR(max);
	DECLARE @classificationList NVARCHAR(MAX)
	DECLARE @RowsDeleted INTEGER;
        DECLARE @codeSetList TABLE (cslId BIGINT IDENTITY(1,1)  PRIMARY KEY, codeSetId nvarchar(50)) ;
	
	BEGIN TRY

		SELECT @repoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY WHERE NAME = @repoName;
		if (@repoId is null)  RAISERROR('Repository not found: %s', 16, 1, @repoName);
		print 'Repository: "' + @repoName + '"	= ' + cast(@repoId as varchar);
		
		SELECT @profileId=PROFILE_ID FROM B_MASTER_REPOSITORY WHERE MASTER_REPOSITORY_ID = @repoId;
		
		SELECT @classificationList=repository_taxonomy_id_list FROM B_PROFILE WHERE PROFILE_ID = @profileId;
		if (@classificationList is not null)  
		BEGIN
		    print('classificationList = ' + @classificationList);
    		    INSERT INTO @codeSetList (codeSetId) SELECT * FROM DebSplit(',', @classificationList);
    		    
    	            SET @id = (SELECT MIN(cslId) FROM  @codeSetList );

    	            WHILE @id is not null
    	            BEGIN
    	           	SELECT @csValue = codeSetId from @codeSetList where cslId = @id;
    	           	print ('csValue = ' + @csValue);
    	           	SET @codeSetId = CAST(@csValue as INTEGER);
    	           	-- find fmtAttr with this codeSetId
    	           	SELECT @fmtAttrId = format_attr_id from B_FORMAT_ATTR where profile_id = @profileId and code_set_id = @codeSetId;
    	           	print ('fmtAttrId = ' + cast(@fmtAttrId as nvarchar));
			if (@fmtAttrId is not null)  
			BEGIN
				UPDATE B_FORMAT_ATTR set SPECIAL_FUNCTION_IND=31 where format_attr_id = @fmtAttrId;
			END
                        SET @id = (SELECT MIN(cslId) FROM  @codeSetList WHERE  cslId > @id)
		    END		        	            	            		    
		END
		
		SELECT @classificationList=taxonomy_id_list FROM B_PROFILE WHERE PROFILE_ID = @profileId;
		if (@classificationList is not null)  
		BEGIN
		    print('hierarchy List = ' + @classificationList);
		    UPDATE B_PROFILE SET repository_taxonomy_id_list = @classificationList, taxonomy_id_list = '' where PROFILE_ID = @profileId;
		END
		
		
		
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;	

END
go

