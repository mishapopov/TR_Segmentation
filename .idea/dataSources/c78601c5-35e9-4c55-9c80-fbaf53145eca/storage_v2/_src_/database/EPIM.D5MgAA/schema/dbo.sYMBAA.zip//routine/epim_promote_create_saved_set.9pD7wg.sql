
create PROCEDURE epim_promote_create_saved_set
	@savedSetName varchar(255),
	@masterRepository varchar(255),
	@validationTypeInd int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @execStmt  varchar(2000);   
	declare @masterRepoId bigint;
	declare @savedSetId bigint;
	declare @savedSetCount integer;
	declare @blocksize integer;
	declare @minItemId bigint;
	
	declare @find nvarchar(5);
        declare @replace nvarchar(5);

        Set @find = ''+ char(39) +'';
        Set @replace = ''+char(39)+char(39)+'';
        Set @blocksize=10000;
	BEGIN TRY
		SELECT @masterRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with(nolock) WHERE NAME = @masterRepository;
		--print '31: Master repository id for ' + @masterRepository + ' is ' + CAST(@masterRepoId as varchar(50));
		if (@masterRepoId is null)  RAISERROR('MASTER_REPOSITORY_ID not found for masterRepository: %s', 16, 1, @masterRepository);

		IF NOT EXISTS (SELECT ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr WHERE 
		               ss.saved_set_id = ssr.saved_set_id and NAME = @savedsetName AND ssr.MASTER_REPOSITORY_ID=@masterRepoId) 
		BEGIN
		   INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME, LAST_UPDATE_BY, LAST_UPDATE_DATETIME,TEMPORARY_IND) 
		       VALUES (1, @masterRepoId, @savedsetName, 'system defined saved set', 0, GETDATE(),1,GETDATE(),1);
		   SELECT  @savedSetId=SCOPE_IDENTITY();	
		   INSERT INTO B_SAVED_SET_REPO(MASTER_REPOSITORY_ID, SAVED_SET_ID) VALUES (@masterRepoId, @savedSetId);
		END
		    
		if (@savedSetId is null)  RAISERROR('saved_Set_id not found for saved set: %s', 16, 1, @savedSetName);

		DELETE FROM B_SAVED_SET_ITEM WHERE saved_Set_id=@savedSetId;
		SET @minItemId = (SELECT MIN(ITEM_ID) FROM  B_MASTER_REPOSITORY_ITEM with(nolock) WHERE (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2) );
		--print '44: minItemId= ' + CAST(@minItemId as varchar);
			
        WHILE @minItemId IS NOT NULL
		BEGIN
			BEGIN TRANSACTION
			if (@validationTypeInd=1)
			begin
			    PRINT '@validationTypeInd=1, check error status only valid';

			    INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			    SELECT @savedSetId AS SAVED_SET_ID, ITEM_ID FROM B_MASTER_REPOSITORY_ITEM with(nolock)
				WHERE (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2) AND 
				(HAS_ERROR_IND is NULL OR HAS_ERROR_IND=0 or HAS_ERROR_IND=2) AND 
				(ITEM_ID >= @minItemId and ITEM_ID < (@minItemId + @blocksize));
                	    SET @minItemId = (SELECT MIN(ITEM_ID) FROM  B_MASTER_REPOSITORY_ITEM with(nolock) WHERE 
                	        (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2) AND 
				(HAS_ERROR_IND is NULL OR HAS_ERROR_IND=0 or HAS_ERROR_IND=2)  AND  
                	        (ITEM_ID >= (@minItemId + @blocksize) ));
                	end
                	else
                	begin
			    if (@validationTypeInd=2)
			    begin
			        PRINT '@validationTypeInd=2, check error status for warning';

			        INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			        SELECT @savedSetId AS SAVED_SET_ID, ITEM_ID FROM B_MASTER_REPOSITORY_ITEM with(nolock)
				    WHERE (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2) AND 
				    (HAS_ERROR_IND is NULL OR HAS_ERROR_IND=0 or HAS_ERROR_IND=1 or HAS_ERROR_IND=2) AND 
				    (ITEM_ID >= @minItemId and ITEM_ID < (@minItemId + @blocksize));
                	        SET @minItemId = (SELECT MIN(ITEM_ID) FROM  B_MASTER_REPOSITORY_ITEM with(nolock) WHERE 
                	            (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2) AND 
				    (HAS_ERROR_IND is NULL OR HAS_ERROR_IND=0 or HAS_ERROR_IND=1 or HAS_ERROR_IND=2)  AND  
                	            (ITEM_ID >= (@minItemId + @blocksize) ));
                	    end
                	    else
                	    begin
			        PRINT '@validationTypeInd=0, do not check error status';

			        INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			        SELECT @savedSetId AS SAVED_SET_ID, ITEM_ID FROM B_MASTER_REPOSITORY_ITEM with(nolock)
				    WHERE (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2)  AND 
				    (ITEM_ID >= @minItemId and ITEM_ID < (@minItemId + @blocksize));
                	        SET @minItemId = (SELECT MIN(ITEM_ID) FROM  B_MASTER_REPOSITORY_ITEM with(nolock) WHERE 
                	            (REPOSITORY_ID = @masterRepoId) AND (RECORD_STATE =1 OR RECORD_STATE=2)   AND  
                	            (ITEM_ID >= (@minItemId + @blocksize) ));
                	    end
                	end
			--print '52: minItemId= ' + CAST(@minItemId as varchar);
			COMMIT;
		END
		SELECT @savedSetCount = COUNT(*) FROM B_SAVED_SET_ITEM  with(nolock) WHERE SAVED_SET_ID = @savedSetId
		SELECT @savedSetName as SavedSetName, @savedSetId as SavedSetId, @savedSetCount as SavedSetCount, @masterRepository as StagingRepository, @masterRepoId as StagingRepositoryId
	 END TRY
    
    BEGIN CATCH
		ROLLBACK TRANSACTION;
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;


        SELECT  @ErrorMessage = ERROR_MESSAGE(),
                @ErrorSeverity = ERROR_SEVERITY(),
                @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END
go

