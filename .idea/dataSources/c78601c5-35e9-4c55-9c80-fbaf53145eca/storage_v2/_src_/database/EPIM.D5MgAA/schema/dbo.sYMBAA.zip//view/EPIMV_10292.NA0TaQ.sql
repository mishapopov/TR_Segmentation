create view EPIMV_10292 as select ID, PLT_10294."F_1" as F_1004364 from PLT_10294
go

