CREATE TRIGGER epim_ad_bstyleMapGroup ON B_STYLE_MAP_GROUP
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = style_map_group_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BstyleMapGroup', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BstyleMapGroup', @obj_id;
    END
go

