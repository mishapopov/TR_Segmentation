--#BEGIN#
create procedure [dbo].[epim_update_bulk_from_sql] 
    (@repositoryNameP nvarchar(200), @attrNameP nvarchar(200), @attrValueP nvarchar(400), @sqlqueryP nvarchar(max), @optionsP nvarchar(max))
as  
begin
-- this procedure is to set value to one of the EPIM XML attributes
-- @repositoryNameP the name of the EPIM repository name. 
--    e.g. Item_Staging
-- @attrNameP is the display name for the attribute, e.g. 'Part #'
-- @attrValueP is the value to be set
-- @sqlqueryP is used to produce item_id list. This can be any query as long as it
--        will produce a list of epim item_id
--      e.g. select i.item_id from b_master_repository_item i
--           select i.myid from mytemptable i 
-- ********* always use table alias in this parameter 
-- @optionsP is currently not supported, could extend to support 
--       creating history record or not
--       modify the last modify time or not
-- The default is 1. not create history record 2. not modify last modify time
--
--
-- ******** 3/22/2012 @optionsP modified to support XML string specifying:
--                     1)  should create history record
--                     2)  should modify the last modify time
-- @optionsP structure: 
--     <Options><CreateHistory>Yes</CreateHistory><ModifyDate>Yes</ModifyDate></Options>
--
  declare @attrSql nvarchar(max);
  declare @attrSysName nvarchar(20);
  declare @repositoryId bigint;
  declare @isDelete int;
  declare @shouldCreateHistory int;
  declare @optionsIndex1 int;
  declare @optionsIndex2 int;
  declare @optionsValue nvarchar(200);
  declare @dateStr nvarchar(200);
  declare @Resource int;
  declare @lockTimeout int;
  
  set @lockTimeout = 3600000;
  exec epim_update_bulk_from_sql_timeout @repositoryNameP, @attrNameP, @attrValueP, @sqlqueryP, @optionsP, @lockTimeout;
  print 'done from caller';
  end


go

