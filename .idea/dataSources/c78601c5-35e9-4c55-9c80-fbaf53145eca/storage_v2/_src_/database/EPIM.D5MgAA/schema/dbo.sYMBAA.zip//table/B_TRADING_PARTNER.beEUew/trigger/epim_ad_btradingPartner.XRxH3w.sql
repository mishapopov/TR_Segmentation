CREATE TRIGGER epim_ad_btradingPartner ON B_TRADING_PARTNER
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = trading_partner_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BtradingPartner', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BtradingPartner', @obj_id;
    END
go

