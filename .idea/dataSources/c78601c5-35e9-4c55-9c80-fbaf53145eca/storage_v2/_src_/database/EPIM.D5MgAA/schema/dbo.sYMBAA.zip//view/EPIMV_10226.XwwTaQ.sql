create view EPIMV_10226 as select ID, PLT_10228."F_1" as F_1004364, PLT_10228."F_12676" as F_1004712 from PLT_10228
go

