--#BEGIN#
CREATE PROCEDURE [dbo].[epim_promotion_retire]
	@masterRepository VARCHAR(255),
	@retireDateColumn VARCHAR(255),
	@retireStatusColumn VARCHAR(255),
	@retireStatusValue VARCHAR(255),
	@deleteFromProd INTEGER,
	@linkRelationshipList VARCHAR(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- Interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @debug INTEGER;
	DECLARE @execStmt  VARCHAR(2000);   
	DECLARE @masterRepoId BIGINT;
	DECLARE @profileId BIGINT;
	DECLARE @productionRepoId BIGINT;
	DECLARE @retireDateId BIGINT;
	DECLARE @retireStatusId BIGINT;
	DECLARE @savedsetName VARCHAR(255);
	DECLARE @savedSetId BIGINT;
	DECLARE @prodRepoName VARCHAR(255);
	DECLARE @prodsavedSetId BIGINT;
	DECLARE @savedSetCount INTEGER;
	DECLARE @blocksize INTEGER;
	DECLARE @minItemId BIGINT;
	
	DECLARE @find nVARCHAR(5);
    DECLARE @replace nVARCHAR(5);
	DECLARE @RowsDeleted INTEGER;
	declare @linkRelStr nvarchar(max);
	declare @linkRelNameStr nvarchar(max);
	declare @linkRelId INTEGER;
	declare @childRepoId INTEGER;
	declare @parentRepoId INTEGER;
	declare @stagingLinkRelationshipIdList VARCHAR(max);
	declare @productionLinkRelationshipIdList VARCHAR(max);
	declare @thisLinkRelName nvarchar(255);
	declare @linkedSavedSetName nvarchar(max);
	declare @resultSavedSetName nvarchar(max);
	declare @resultSavedSetId INTEGER;
	declare @childRepoName nvarchar(max);
	declare @itemSql nvarchar(max);


    Set @find = ''+ CHAR(39) +'';
    Set @replace = ''+CHAR(39)+CHAR(39)+'';
    Set @blocksize=10000;
    SET @debug=1;
	BEGIN TRY
		SET @stagingLinkRelationshipIdList = '';
		SET @productionLinkRelationshipIdList = '';
		
		if (@retireStatusColumn='') SET @retireStatusColumn=NULL;
		if (@retireDateColumn IS NULL OR @retireDateColumn='') RAISERROR('Retire Date must be defined: %s', 16, 1, @retireDateColumn);
		if (@retireStatusValue='') SET @retireStatusValue=NULL;		
		SELECT @masterRepoId=MASTER_REPOSITORY_ID, @profileId=PROFILE_ID FROM B_MASTER_REPOSITORY with(nolock) WHERE NAME = @masterRepository;
		if (@debug=1) PRINT '44: Master repository id for ' + @masterRepository + ' is ' + CAST(@masterRepoId as VARCHAR);
		if (@masterRepoId is null)  RAISERROR('MASTER_REPOSITORY_ID not found for masterRepository: %s', 16, 1, @masterRepository);

		SELECT @productionRepoId = STAGING_PROD_PARTNER_REPO_ID from b_master_repository  with (nolock) where MASTER_REPOSITORY_ID = @masterRepoId;
		if (@debug=1) PRINT '48: Production Repository  id=' + CAST(@productionRepoId AS VARCHAR);		

		SELECT @retireDateId=FORMAT_ATTR_ID FROM B_FORMAT_ATTR WHERE PROFILE_ID=@profileId AND NAME=@retireDateColumn;
		if (@debug=1) PRINT '51: retireDateId for ' + @retireDateColumn + ' is ' + CAST(@retireDateId as VARCHAR);
		if (@retireDateId is null)  RAISERROR('Retire Date Attribute Id not found for : %s', 16, 1, @retireDateColumn);

		SELECT @retireStatusId=FORMAT_ATTR_ID FROM B_FORMAT_ATTR WHERE PROFILE_ID=@profileId AND NAME=@retireStatusColumn;
		if (@debug=1) PRINT '55: retireStatusId for ' + @retireStatusColumn + ' is ' + CAST(@retireStatusId as VARCHAR);

		--create temp working saved set
		SET @savedsetName='RetireSS_' + CONVERT(VARCHAR(50),CURRENT_TIMESTAMP,126);
		if (@debug=1) PRINT '59: Temp saved set is ' + @savedsetName;
		
		IF NOT EXISTS (SELECT ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr WHERE 
		               ss.saved_set_id = ssr.saved_set_id and NAME = @savedsetName AND ssr.MASTER_REPOSITORY_ID=@masterRepoId) 
		BEGIN
		   INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME, LAST_UPDATE_BY, LAST_UPDATE_DATETIME,TEMPORARY_IND) 
		       VALUES (1, @masterRepoId, @savedsetName, 'system defined saved set', 0, GETDATE(),1,GETDATE(),1);
		   SELECT  @savedSetId=SCOPE_IDENTITY();	
		   INSERT INTO B_SAVED_SET_REPO(MASTER_REPOSITORY_ID, SAVED_SET_ID) VALUES (@masterRepoId, @savedSetId);
		END
		if (@debug=1) PRINT '69: Saved Set Id for ' + @masterRepository + ' is ' + CAST(@masterRepoId as VARCHAR);
		if (@savedSetId is null)  RAISERROR('saved_Set_id not created for saved set: %s', 16, 1, @savedSetName);

		--Delete all from temp Saved set 
		if (@debug=1) PRINT '73: Delete from saved set';
		SET @RowsDeleted = 1
		WHILE (@RowsDeleted > 0)
		BEGIN
			  DELETE TOP (10000)
				FROM B_SAVED_SET_ITEM
				FROM  B_SAVED_SET_ITEM
				WHERE     (SAVED_SET_ID = @savedSetId)

			SET @RowsDeleted = @@ROWCOUNT
		END
		
		-- if linkRelationshipIdList is not null and productionRepoId is not null, split into staging and production lists
		if (@debug=1) PRINT '      linkRelationshipList: ' + @linkRelationshipList;
		if (@linkRelationshipList is not null AND @linkRelationshipList <> '')
		BEGIN
			DECLARE db_cursor1 CURSOR FOR SELECT * FROM dbo.epim_parse_delimited_string (@linkRelationshipList, '~'); 
			OPEN db_cursor1;
			FETCH NEXT FROM db_cursor1 INTO @linkRelNameStr;
			WHILE @@FETCH_STATUS = 0  
				BEGIN  
					if (@debug=1) PRINT 'linkRelNameStr = ' + @linkRelNameStr;
					SELECT @parentRepoId=PARENT_REPOSITORY_ID, @linkRelId=LINK_RELATIONSHIP_ID FROM B_LINK_RELATIONSHIP 
					with(nolock) WHERE NAME = @linkRelNameStr;
					if (@debug=1) PRINT 'linkRelId = ' + cast(@linkRelId as varchar);
					SET @linkRelStr = cast(@linkRelId as varchar);
					if (@debug=1) PRINT 'linkRelId = ' + @linkRelStr + ' for linkRelName: ' + @linkRelNameStr;
					if (@parentRepoId = @masterRepoId)
					begin
						if (len(@stagingLinkRelationshipIdList) > 1)
							SET @stagingLinkRelationshipIdList = @stagingLinkRelationshipIdList + ',' + @linkRelStr;
						else
							SET @stagingLinkRelationshipIdList = @linkRelStr;
					end
					else
					begin
						if (len(@productionLinkRelationshipIdList) > 1)
							SET @productionLinkRelationshipIdList = @productionLinkRelationshipIdList + ',' + @linkRelStr;
						else
							SET @productionLinkRelationshipIdList = @linkRelStr;
					end
					FETCH NEXT FROM db_cursor1 INTO @linkRelNameStr;
				END;
			CLOSE db_cursor1;
			DEALLOCATE db_cursor1;
		END
		else
			SET @stagingLinkRelationshipIdList = null;
		if (@debug=1) PRINT '      stagingLinkRelationshipIdList: ' + @stagingLinkRelationshipIdList;
		if (@debug=1) PRINT '      productionLinkRelationshipIdList: ' + @productionLinkRelationshipIdList;

		--find all records to retire
		SET @execStmt = '
			INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			SELECT ' + cast(@savedSetId as VARCHAR) + ' as SAVED_SET_ID,  mri.ITEM_ID 
			FROM B_SNAPSHOT_' + cast(@masterRepoId as VARCHAR) + ' AS s INNER JOIN B_MASTER_REPOSITORY_ITEM AS mri ON s.ITEM_ID = mri.ITEM_ID 
			WHERE  (s.F_' + cast(@retireDateId as VARCHAR) + ' <= GETDATE()) AND  (mri.RECORD_STATE <> 3 ';
		if (@retireStatusId IS NOT NULL) SET @execStmt = @execStmt + 'OR s.F_' + cast(@retireStatusId as VARCHAR) + ' <> ''' + replace(@retireStatusValue,@find,@replace) + ''' ';
		SET @execStmt = @execStmt + ') ';
		if (@debug=1) PRINT '93: query to find records to retire is ' + @execStmt;
		EXEC (@execStmt);
		
		if (@debug=1) PRINT '96: UPDATE to set record state to delisted for staging';
		UPDATE bmi SET RECORD_STATE = 3 
		FROM  B_MASTER_REPOSITORY_ITEM AS bmi INNER JOIN B_SAVED_SET_ITEM AS ssi ON bmi.ITEM_ID = ssi.ITEM_ID
		WHERE (ssi.SAVED_SET_ID = @savedSetId)
		if (@retireStatusId IS NOT NULL)
		BEGIN
			SET @execStmt = '
				UPDATE s SET F_' + cast(@retireStatusId as VARCHAR) + ' = ''' + replace(@retireStatusValue,@find,@replace) + '''
				FROM  B_SNAPSHOT_' + cast(@masterRepoId as VARCHAR) + ' AS s INNER JOIN B_SAVED_SET_ITEM AS ssi ON s.ITEM_ID = ssi.ITEM_ID
				WHERE (ssi.SAVED_SET_ID = ' + cast(@savedSetId as VARCHAR) + ')';
			if (@debug=1) PRINT '106: update query for snapshots is ' + @execStmt;
			EXEC (@execStmt);

			if (@debug=1) PRINT '109: Updating staging attribute [' + @retireStatusColumn +'] to value of [' + @retireStatusValue +']';
			SET @execStmt = 'UPDATE B_MASTER_REPOSITORY_ITEM set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						'attr_data.modify(''replace value of (/Item/F_' + cast(@retireStatusId as VARCHAR) +
						'/text())[1] with "' + replace(@retireStatusValue,@find,@replace) + '" '')  FROM B_SAVED_SET_ITEM AS ssi INNER JOIN B_MASTER_REPOSITORY_ITEM ON ' +
						' ssi.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID where B_MASTER_REPOSITORY_ITEM.attr_data is not null and ' +
						' B_MASTER_REPOSITORY_ITEM.repository_id = ' + cast(@masterRepoId as VARCHAR) +
						' AND (ssi.SAVED_SET_ID= ' + cast(@savedSetId as VARCHAR) + ' )';

			if (@debug=1) PRINT '117: update query for stage master repo is ' + @execStmt;
			EXEC (@execStmt);	

			if (@debug=1) PRINT '120: Updating staging insert attribute [' + @retireStatusColumn +'] to value of [' + @retireStatusValue +']';
			SET @execStmt = 'UPDATE B_MASTER_REPOSITORY_ITEM set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						' attr_data.modify(''insert <F_' + cast(@retireStatusId as VARCHAR) + '>' + replace(@retireStatusValue,@find,@replace) +
						'</F_' + cast(@retireStatusId as VARCHAR) + '>  into (/Item)[1]'')  FROM  B_SAVED_SET_ITEM AS ssi INNER JOIN B_MASTER_REPOSITORY_ITEM ON ' +
						' ssi.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID where B_MASTER_REPOSITORY_ITEM.attr_data is not null AND ' +
						' B_MASTER_REPOSITORY_ITEM.attr_data.exist(''/Item/F_' + cast(@retireStatusId as VARCHAR) +
						''') !=1 and B_MASTER_REPOSITORY_ITEM.repository_id =  ' + cast(@masterRepoId as VARCHAR)  +
						' AND (ssi.SAVED_SET_ID=' + cast(@savedSetId as VARCHAR) + ' )';
			if (@debug=1) PRINT '128: insert query for staging master repo is ' + @execStmt;
			EXEC (@execStmt);

		END
		

		--delete corresponding from production
		if (@productionRepoId is not null)
		BEGIN
			SELECT @prodRepoName = NAME from b_master_repository  with (nolock) where MASTER_REPOSITORY_ID = @productionRepoId;
			if (@debug=1) PRINT '137: Production Repository =' + @prodRepoName;		
		
			--create production saved set
			EXEC epim_move_saved_set_to_prod @savedSetId, @masterRepoId, @prodsavedSetId OUTPUT;
			if (@debug=1) PRINT '141: Prod saved set id is ' + CAST(@prodsavedSetId as VARCHAR);
			if (@prodsavedSetId is null)  RAISERROR('Production saved set not found for masterRepository: %s', 16, 1, @prodRepoName);

			SELECT @savedSetName = NAME from b_saved_set where SAVED_SET_ID=@prodsavedSetId;
			if (@debug=1) PRINT '   Prod SavedSet Name = ' + @savedSetName;

			if (@deleteFromProd=1)
			BEGIN
				-- first delete any items from production linkRelationships before deleting the production item
				if (@debug=1) PRINT '   Delete items from production linkRelationships';
				if (@productionLinkRelationshipIdList is null OR @productionLinkRelationshipIdList = '')
				begin
					if (@debug=1) PRINT 'productionLinkRelationshipIdList is empty'
				end
				else
				BEGIN
					if (@debug=1) PRINT '   productionLinkRelationshipIdList IS NOT EMPTY ';
					DECLARE db_cursor3 CURSOR FOR SELECT * FROM dbo.epim_parse_delimited_string (@productionLinkRelationshipIdList, ','); 
					OPEN db_cursor3;
					FETCH NEXT FROM db_cursor3 INTO @linkRelStr;
					if (@debug=1) PRINT '   linkRelStr  = ' + @linkRelStr;
					WHILE @@FETCH_STATUS = 0  
					BEGIN  
						SELECT @thisLinkRelName = NAME from B_LINK_RELATIONSHIP where LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER);
						if (@debug=1) PRINT '   thisLinkRelName  = ' + @thisLinkRelName;
						SELECT @childRepoName = mr.NAME from B_MASTER_REPOSITORY mr, B_LINK_CHILD_REPOSITORY lcr where 
								lcr.LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER) and mr.MASTER_REPOSITORY_ID = lcr.CHILD_REPOSITORY_ID;
						if (@debug=1) PRINT '44: child repository name is ' + @childRepoName;
						exec epim_create_saved_set_for_linked_items @savedsetName , @prodRepoName, @thisLinkRelName, @debug, @resultSavedSetName = @resultSavedSetName OUTPUT;				
						if (@resultSavedSetName is null) print '@resultSavedSetName is null';
						if (@debug=1) PRINT '44: resultSavedSetName is ' + @resultSavedSetName;
						EXEC epim_delete_data_for_saved_set @childRepoName, @resultSavedSetName;
							
						FETCH NEXT FROM db_cursor3 INTO @linkRelStr;
					END
					CLOSE db_cursor3;
					DEALLOCATE db_cursor3;
				END;

				if (@debug=1) PRINT '146: Deleting from production';
				EXEC epim_delete_data_for_saved_set @prodRepoName, @savedsetName;
			END
			ELSE
			BEGIN
				if (@debug=1) PRINT '151: UPDATE to set record state to delisted for production';
				--upate record status to delist
				UPDATE bmi SET RECORD_STATE = 3 
				FROM  B_MASTER_REPOSITORY_ITEM AS bmi INNER JOIN B_SAVED_SET_ITEM AS ssi ON bmi.ITEM_ID = ssi.ITEM_ID
				WHERE (ssi.SAVED_SET_ID = @prodsavedSetId)
				if (@retireStatusId IS NOT NULL)
				BEGIN
					SET @execStmt = '
						UPDATE s SET F_' + cast(@retireStatusId as VARCHAR) + ' = ''' + replace(@retireStatusValue,@find,@replace) + '''
						FROM  B_SNAPSHOT_' + cast(@productionRepoId as VARCHAR) + ' AS s INNER JOIN B_SAVED_SET_ITEM AS ssi ON s.ITEM_ID = ssi.ITEM_ID
						WHERE (ssi.SAVED_SET_ID = ' + cast(@prodsavedSetId as VARCHAR) + ')';
					if (@debug=1) PRINT '162: update query for production snapshots is ' + @execStmt;
					EXEC (@execStmt);

					if (@debug=1) PRINT '165: Updating production attribute [' + @retireStatusColumn +'] to value of [' + @retireStatusValue +']';
					SET @execStmt = 'UPDATE B_MASTER_REPOSITORY_ITEM set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
								'attr_data.modify(''replace value of (/Item/F_' + cast(@retireStatusId as VARCHAR) +
								'/text())[1] with "' + replace(@retireStatusValue,@find,@replace) + '" '')  FROM B_SAVED_SET_ITEM AS ssi INNER JOIN B_MASTER_REPOSITORY_ITEM ON ' +
								' ssi.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID where B_MASTER_REPOSITORY_ITEM.attr_data is not null and ' +
								' B_MASTER_REPOSITORY_ITEM.repository_id = ' + cast(@productionRepoId as VARCHAR) +
								' AND (ssi.SAVED_SET_ID= ' + cast(@prodsavedSetId as VARCHAR) + ' )';

					if (@debug=1) PRINT '173: update query for production master repo  is ' + @execStmt;
					EXEC (@execStmt);	

					if (@debug=1) PRINT '176: Updating production insert attribute [' + @retireStatusColumn +'] to value of [' + @retireStatusValue +']';
					SET @execStmt = 'UPDATE B_MASTER_REPOSITORY_ITEM set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
								' attr_data.modify(''insert <F_' + cast(@retireStatusId as VARCHAR) + '>' + replace(@retireStatusValue,@find,@replace) +
								'</F_' + cast(@retireStatusId as VARCHAR) + '>  into (/Item)[1]'')  FROM  B_SAVED_SET_ITEM AS ssi INNER JOIN B_MASTER_REPOSITORY_ITEM ON ' +
								' ssi.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID where B_MASTER_REPOSITORY_ITEM.attr_data is not null AND ' +
								' B_MASTER_REPOSITORY_ITEM.attr_data.exist(''/Item/F_' + cast(@retireStatusId as VARCHAR) +
								''') !=1 and B_MASTER_REPOSITORY_ITEM.repository_id =  ' + cast(@productionRepoId as VARCHAR)  +
								' AND (ssi.SAVED_SET_ID=' + cast(@prodsavedSetId as VARCHAR) + ' )';
					if (@debug=1) PRINT '184: insert query for production master repo is ' + @execStmt;
					EXEC (@execStmt);
				END		
			END
		END		

		if (@debug=1) PRINT '189: Delete temp production saved set';
		SET @RowsDeleted = 1
		WHILE (@RowsDeleted > 0)
		BEGIN
			  DELETE TOP (10000)
				FROM B_SAVED_SET_ITEM
				FROM  B_SAVED_SET_ITEM
				WHERE     (SAVED_SET_ID = @prodsavedSetId)

			SET @RowsDeleted = @@ROWCOUNT
		END
		-- do not delete the production savedSet altogether until process all retired items
		--DELETE FROM B_SAVED_SET_REPO WHERE SAVED_SET_ID=@prodsavedSetId;
		--DELETE FROM B_SAVED_SET WHERE SAVED_SET_ID=@prodsavedSetId;

		if (@debug=1) PRINT '204: Delete temp staging saved set';
		SET @RowsDeleted = 1
		WHILE (@RowsDeleted > 0)
		BEGIN
			  DELETE TOP (10000)
				FROM B_SAVED_SET_ITEM
				FROM  B_SAVED_SET_ITEM
				WHERE     (SAVED_SET_ID = @savedSetId)

			SET @RowsDeleted = @@ROWCOUNT
		END
		
		-- before deleting staging savedSet altogether, find any retired items
		SET @execStmt = '
			INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			SELECT ' + cast(@savedSetId as VARCHAR) + ' as SAVED_SET_ID,  mri.ITEM_ID 
			FROM B_SNAPSHOT_' + cast(@masterRepoId as VARCHAR) + ' AS s INNER JOIN B_MASTER_REPOSITORY_ITEM AS mri ON s.ITEM_ID = mri.ITEM_ID 
			WHERE  mri.RECORD_STATE = 3';
		if (@debug=1) PRINT '93: query to find records all retired is ' + @execStmt;
		EXEC (@execStmt);
		
		if (@debug=1) PRINT '   Delete items from staging linkRelationships for already-retired items';
		if (@stagingLinkRelationshipIdList is null OR @stagingLinkRelationshipIdList = '')
		BEGIN
			if (@debug=1) PRINT 'stagingLinkRelationshipIdList is empty'
		END
		else
		BEGIN
			DECLARE db_cursor2 CURSOR FOR SELECT * FROM dbo.epim_parse_delimited_string (@stagingLinkRelationshipIdList, ','); 
			OPEN db_cursor2;
			FETCH NEXT FROM db_cursor2 INTO @linkRelStr;
			WHILE @@FETCH_STATUS = 0  
			BEGIN  
				SELECT @thisLinkRelName = NAME from B_LINK_RELATIONSHIP where LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER);
				SELECT @childRepoName = mr.NAME from B_MASTER_REPOSITORY mr, B_LINK_CHILD_REPOSITORY lcr where 
						lcr.LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER) and mr.MASTER_REPOSITORY_ID = lcr.CHILD_REPOSITORY_ID;
				if (@debug=1) PRINT '44: child repository name is ' + @childRepoName;

				exec epim_create_saved_set_for_linked_items @savedsetName , @masterRepository, @thisLinkRelName, @debug, @resultSavedSetName = @resultSavedSetName OUTPUT;				
				if (@resultSavedSetName is null) print '@resultSavedSetName is null';
				if (@debug=1) PRINT '44: resultSavedSetName is ' + @resultSavedSetName;
				EXEC epim_delete_data_for_saved_set @childRepoName, @resultSavedSetName;
					
				FETCH NEXT FROM db_cursor2 INTO @linkRelStr;
			END
			CLOSE db_cursor2;
			DEALLOCATE db_cursor2;
			
		END;
		
		SET @RowsDeleted = 1
		WHILE (@RowsDeleted > 0)
		BEGIN
			DELETE TOP (10000)
				FROM B_SAVED_SET_ITEM
				FROM  B_SAVED_SET_ITEM
				WHERE     (SAVED_SET_ID = @savedSetId)

			SET @RowsDeleted = @@ROWCOUNT
		END
		
		if (@productionRepoId is not null)
		BEGIN
			-- find any retired items for production repo
			SET @execStmt = '
			INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) 
			SELECT ' + cast(@prodsavedSetId as VARCHAR) + ' as SAVED_SET_ID,  mri.ITEM_ID 
			FROM B_SNAPSHOT_' + cast(@productionRepoId as VARCHAR) + ' AS s INNER JOIN B_MASTER_REPOSITORY_ITEM AS mri ON s.ITEM_ID = mri.ITEM_ID 
			WHERE  mri.RECORD_STATE = 3 ';
			if (@debug=1) PRINT '93: query to find prod records already retired is ' + @execStmt;
			EXEC (@execStmt);
			SELECT @savedSetName = NAME from b_saved_set where SAVED_SET_ID=@prodsavedSetId;
			if (@debug=1) PRINT '   Prod SavedSet Name = ' + @savedSetName;
			if (@debug=1) PRINT '   Delete items from production linkRelationships';
			if (@productionLinkRelationshipIdList is null OR @productionLinkRelationshipIdList = '')
			begin
				if (@debug=1) PRINT 'productionLinkRelationshipIdList is empty'
			end
			else
			BEGIN
				DECLARE db_cursor3 CURSOR FOR SELECT * FROM dbo.epim_parse_delimited_string (@productionLinkRelationshipIdList, ','); 
				OPEN db_cursor3;
				FETCH NEXT FROM db_cursor3 INTO @linkRelStr;
				WHILE @@FETCH_STATUS = 0  
				BEGIN  
					SELECT @thisLinkRelName = NAME from B_LINK_RELATIONSHIP where LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER);
					SELECT @childRepoName = mr.NAME from B_MASTER_REPOSITORY mr, B_LINK_CHILD_REPOSITORY lcr where 
							lcr.LINK_RELATIONSHIP_ID = cast(@linkRelStr as INTEGER) and mr.MASTER_REPOSITORY_ID = lcr.CHILD_REPOSITORY_ID;
					if (@debug=1) PRINT '44: child repository name is ' + @childRepoName;
					exec epim_create_saved_set_for_linked_items @savedsetName , @prodRepoName, @thisLinkRelName, @debug, @resultSavedSetName = @resultSavedSetName OUTPUT;				
					if (@resultSavedSetName is null) print '@resultSavedSetName is null';
					if (@debug=1) PRINT '44: resultSavedSetName is ' + @resultSavedSetName;
					EXEC epim_delete_data_for_saved_set @childRepoName, @resultSavedSetName;
						
					FETCH NEXT FROM db_cursor3 INTO @linkRelStr;
				END
				CLOSE db_cursor3;
				DEALLOCATE db_cursor3;
			END;
			
			if (@debug=1) PRINT '189: Delete temp production saved set';
			SET @RowsDeleted = 1
			WHILE (@RowsDeleted > 0)
			BEGIN
				DELETE TOP (10000)
					FROM B_SAVED_SET_ITEM
					FROM  B_SAVED_SET_ITEM
					WHERE     (SAVED_SET_ID = @prodsavedSetId)

				SET @RowsDeleted = @@ROWCOUNT
			END
		END
		
		
		DELETE FROM B_SAVED_SET_REPO WHERE SAVED_SET_ID=@prodsavedSetId;
		DELETE FROM B_SAVED_SET WHERE SAVED_SET_ID=@prodsavedSetId;
		
		DELETE FROM B_SAVED_SET_REPO WHERE SAVED_SET_ID=@savedSetId;
		DELETE FROM B_SAVED_SET WHERE SAVED_SET_ID=@savedSetId;

		END TRY
    
    BEGIN CATCH
		--ROLLBACK TRANSACTION;
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INTEGER;
        DECLARE @ErrorState INTEGER;


        SELECT  @ErrorMessage = ERROR_MESSAGE(),
                @ErrorSeverity = ERROR_SEVERITY(),
                @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END
go

