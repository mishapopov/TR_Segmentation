create view EPIMV_10294_TMP as select ID, PLT_10296_TMP."F_1" as F_1004364 from PLT_10296_TMP
go

