create view EPIMV_10251 as select ID, PLT_10253."F_1" as F_1004364, PLT_10253."F_12691" as F_1004727 from PLT_10253
go

