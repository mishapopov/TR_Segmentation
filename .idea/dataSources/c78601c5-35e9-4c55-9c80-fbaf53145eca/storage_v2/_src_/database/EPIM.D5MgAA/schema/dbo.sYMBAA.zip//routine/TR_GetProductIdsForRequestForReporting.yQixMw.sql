

CREATE PROCEDURE [dbo].[TR_GetProductIdsForRequestForReporting]
    @requestId VARCHAR(200),  -- Internal Record ID for the Request
    @source VARCHAR(30) -- Name of source (Build, Clone, Change, State)
AS BEGIN

    -- TR_GetProductVariantIdsForRequestForReporting - Retrieves a delimited list of Product Variant IDs that
    -- are in the request for reporting purposes.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_GetProductVariantIdsForRequestForReporting '5713512','State'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductVariantIdsForRequestForReporting '%itemIds%','%source%'

    DECLARE @sql NVARCHAR(max)
    DECLARE @product VARCHAR(max)
    DECLARE @productIds VARCHAR(max)
	DECLARE @repository VARCHAR(max)

	-----------------------------------------------------------------------------
	-- Set the repository name
	-----------------------------------------------------------------------------

	IF @source = 'Build'
		set @repository = 'Request_'
	ELSE
		set @repository = 'Request_Product_'
	--END

    -----------------------------------------------------------------------------
    -- Get list of product records by Product Variant ID
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @product = isnull(STUFF((select '','' + cast(pv.Product_ID as VARCHAR) as [text()] ' +
               'from ' + @repository + @source + ' r ' +
               'join Request_To_Product_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_' + @source + ' pv on rpvl.Product_ID = pv.Product_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'products - ' + @sql;
    exec sp_executesql @sql, N'@product varchar(max) out', @product out

    -----------------------------------------------------------------------------
    -- Get list of product variant records by Internal Record ID
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productIds = isnull(STUFF((select '','' + cast(pv.InternalRecordId as VARCHAR) as [text()] ' +
               'from ' + @repository  + @source + ' r ' +
               'join Request_To_Product_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_' + @source + ' pv on rpvl.Product_ID = pv.Product_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productIds - ' + @sql;
    exec sp_executesql @sql, N'@productIds varchar(max) out', @productIds out


    -----------------------------------------------------------------------------
    -- Return all ids
    -----------------------------------------------------------------------------

    select  @product as product,
            @productIds as productIds

END
go

