
  CREATE PROCEDURE [dbo].[TR_GetProductVariantNoteForCopy]
  	@itemIds VARCHAR(200),  -- Delimited list of source product variants
  	@savedSetId int,	-- Saved set ID of source product variants
  	@source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
  	@target VARCHAR(10)	-- Name of target (Clone, Change, State)
    AS BEGIN
    
        -- TR_GetProductVariantNoteForCopy - Retrieves the source and target Product Variant Note records 
        -- for the specified list of Product Variant Item IDs or the saved set from the designated source repository
        -- to be copied to the designated target repository.  Returns the internal record Id of each 
        -- source Product Variant Note record along with the Internal Record Id of the corresponding 
        -- target Product Variant Note record (or null if it doesn't exist).  Not to be used for cloning
        -- as cloning will need new IDs for all cloned records.
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_GetProductVariantNoteForCopy '5707059,5707061,5707054,5707055,5707056',null,'Staging','Change'
        --
        --  EXEC TR_GetProductVariantNoteForCopy null,10548,'Staging','Change'
		--
        -- Workflow Activity:
        --
        -- EXEC TR_GetProductVariantNoteForCopy '%itemIds%',%savedSetId%,'Staging','Change'
        
        DECLARE @sql VARCHAR(max)
        
        -- Determine if saved set was specified
        
        IF @savedSetId IS NULL
        BEGIN
        	-- No code set - use itemIds
        	SET @sql = 'select spvn.InternalRecordId as source, tpvn.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'join PRODUCT_VARIANT_NOTE_' + @source + ' spvn on spvn.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN PRODUCT_VARIANT_NOTE_' + @target + ' tpvn ON tpvn.Product_Note_ID = spvn.Product_Note_ID ' +
        		'WHERE spv.InternalRecordId in (' + @itemIds + ')'
        END
        ELSE
        BEGIN
        	-- Code set - use it
        	SET @sql = 'select spvn.InternalRecordId as source, tpvn.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spv.InternalRecordId ' +
        		'join PRODUCT_VARIANT_NOTE_' + @source + ' spvn on spvn.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN PRODUCT_VARIANT_NOTE_' + @target + ' tpvn ON tpvn.Product_Note_ID = spvn.Product_Note_ID ' +
        		'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) 
        END

       	print @sql
       	EXECUTE (@sql)
 		
    END
  go

