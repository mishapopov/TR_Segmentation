create view [dbo].[EPIM_REP_SV10034] as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1000574)') as nvarchar(MAX))  as F_1000574,  CAST(attr_data.query('data(Item/F_1000575)') as nvarchar(MAX))  as F_1000575,  CAST(attr_data.query('data(Item/F_1000576)') as nvarchar(MAX))  as F_1000576,  CAST(attr_data.query('data(Item/F_1000577)') as nvarchar(MAX))  as F_1000577,  CAST(attr_data.query('data(Item/F_1000578)') as nvarchar(MAX))  as F_1000578,  CAST(attr_data.query('data(Item/F_1000579)') as varchar(MAX))  as F_1000579,  CAST(attr_data.query('data(Item/F_1000580)') as nvarchar(MAX))  as F_1000580,  CAST(attr_data.query('data(Item/F_1000581)') as nvarchar(MAX))  as F_1000581,  CAST(attr_data.query('data(Item/F_1000582)') as nvarchar(MAX))  as F_1000582,  CAST(attr_data.query('data(Item/F_1003532)') as nvarchar(MAX))  as F_1003532 from b_master_repository_item bmri where bmri.repository_id = 10034

go

grant select on EPIM_REP_SV10034 to boomi
go

