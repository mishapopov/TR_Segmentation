
CREATE PROCEDURE [dbo].[Generate_Null_Value_Report]
   @repositoryName VARCHAR(max)
AS
BEGIN
    DECLARE @repositoryId as int
    CREATE TABLE #AttributeNullCounts(
		attributeName varchar(255),
		nullCount int)
    DECLARE @attributeName VARCHAR(255)
    DECLARe @systemName VARCHAR(50)
    DECLARE @attributeId VARCHAR(10)
    DECLARE @sql VARCHAR(max)

     SELECT @repositoryId = master_repository_id from b_master_repository where name = @repositoryName

    -- Create the SQL perform the extraction query
    
            
    DECLARE @position int
    DECLARE @keyPosition int
    SET @position = 1
    DECLARE db_cursor CURSOR FOR  
	select fa.NAME as AttributeName,'F_' + cast(fa.FORMAT_ATTR_ID as VARCHAR) as SystemName
	from B_FORMAT_ATTR fa 
	join B_MASTER_REPOSITORY mr on fa.PROFILE_ID = mr.PROFILE_ID
	join B_REPOSITORY_FMT_ATTR_MAPPING rfam on rfam.FORMAT_ATTR_ID = fa.FORMAT_ATTR_ID and rfam.MASTER_REPOSITORY_ID = mr.MASTER_REPOSITORY_ID
	where mr.MASTER_REPOSITORY_ID = @repositoryId
	AND rfam.SEARCHABLE_IND = 1
    
    OPEN db_cursor  
    FETCH NEXT FROM db_cursor INTO @attributeName,@systemName
    
    WHILE @@FETCH_STATUS = 0  
    BEGIN  
	  SET @sql = 'insert into #AttributeNullCounts SELECT ''' + @attributeName + ''', (select COUNT(*) FROM B_SNAPSHOT_' + cast(@repositoryId as VARCHAR) + ' s' +
	  	' JOIN B_MASTER_REPOSITORY_ITEM mri on mri.ITEM_ID = s.ITEM_ID ' +
	  	' WHERE (' + @systemName + ' IS NULL OR CAST(' + @systemName + ' as VARCHAR) = '''' )' +
	  	' AND mri.REPOSITORY_ID = ' + cast(@repositoryId as VARCHAR) + ')';
	  print (@sql);
    	  EXEC (@sql);

          FETCH NEXT FROM db_cursor INTO @attributeName,@systemName 
    END  
    
    CLOSE db_cursor  
    DEALLOCATE db_cursor 
    
    select * from #AttributeNullCounts order by attributeName
	

    DROP TABLE #AttributeNullCounts;
END

go

