--#BEGIN#
-- stored procedure to list the SYSTEM_NAME and NAME of all attributes belonging to a repository
Create Procedure [dbo].[epim_list_attr_names] ( @repoName varchar(100) ) 
As
    BEGIN

    declare @tblCol1Values table(RowID INT IDENTITY(1, 1), attrName varchar(100), systemName varchar(100),PRIMARY KEY (RowID));
    declare @tbl1Count int;
    declare @iRow int;
    declare @name varchar(100);
    declare @sysName varchar(100);
    SET NOCOUNT ON;

    -- get all of the attr name values    
    INSERT into @tblCol1Values  select name, 'F_' + cast(format_attr_id as VARCHAR(MAX)) from b_format_attr where profile_id = 
    			(select profile_id from b_master_repository where name = @repoName) order by name;
    SET @tbl1Count = (select count(*) from @tblCol1Values);

    if  @tbl1Count > 0
	BEGIN
		-- for each name value:
	   	SET @iRow = 1;
        	WHILE @iRow <= @tbl1Count
		    begin
             		SELECT @name = attrName, @sysName = systemName FROM @tblCol1Values WHERE RowID = @iRow;
			print 'SYSTEM_NAME: ' + @sysName + ' ... NAME: ' + @name;
		        SET @iRow = @iRow + 1;
         	end;
	END
   END
go

