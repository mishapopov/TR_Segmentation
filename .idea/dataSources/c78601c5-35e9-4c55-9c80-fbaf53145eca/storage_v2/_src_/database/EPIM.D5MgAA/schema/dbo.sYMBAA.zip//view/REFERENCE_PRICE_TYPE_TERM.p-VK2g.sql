CREATE VIEW dbo.[REFERENCE_PRICE_TYPE_TERM] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004520 AS [EPM_Reference_Code], F_1004521 AS [System_Name], F_1004522 AS [Value] FROM dbo.B_SNAPSHOT_10160 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_PRICE_TYPE_TERM to dbadmin
go

grant select on REFERENCE_PRICE_TYPE_TERM to ewsys
go

grant select on REFERENCE_PRICE_TYPE_TERM to boomi
go

grant select on REFERENCE_PRICE_TYPE_TERM to informatica
go

grant select on REFERENCE_PRICE_TYPE_TERM to som
go

grant select on REFERENCE_PRICE_TYPE_TERM to apttus
go

grant select on REFERENCE_PRICE_TYPE_TERM to epmdev
go

grant select on REFERENCE_PRICE_TYPE_TERM to MDMAdmin
go

grant select on REFERENCE_PRICE_TYPE_TERM to produser1
go

grant select on REFERENCE_PRICE_TYPE_TERM to produser3
go

grant select on REFERENCE_PRICE_TYPE_TERM to produser2
go

grant select on REFERENCE_PRICE_TYPE_TERM to VIEW_ACCESS
go

grant select on REFERENCE_PRICE_TYPE_TERM to integration_team
go

grant select on REFERENCE_PRICE_TYPE_TERM to ecmxread
go

grant select on REFERENCE_PRICE_TYPE_TERM to MPOPOV_TEST
go

grant select on REFERENCE_PRICE_TYPE_TERM to digital
go

