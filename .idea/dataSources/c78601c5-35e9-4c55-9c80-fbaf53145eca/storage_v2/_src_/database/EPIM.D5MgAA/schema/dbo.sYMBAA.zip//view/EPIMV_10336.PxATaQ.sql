create view EPIMV_10336 as select ID, PLT_10338."F_1" as F_1004364, PLT_10338."F_12348" as F_1004365 from PLT_10338
go

