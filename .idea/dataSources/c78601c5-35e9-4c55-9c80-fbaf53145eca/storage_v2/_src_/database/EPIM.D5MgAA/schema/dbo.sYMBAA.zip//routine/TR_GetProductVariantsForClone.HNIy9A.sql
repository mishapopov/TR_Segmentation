
  CREATE PROCEDURE [dbo].[TR_GetProductVariantsForClone]
  	@itemIds VARCHAR(200),  -- Delimited list of source product variants
  	@savedSetId int,	-- Saved set ID of source product variants
  	@source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
  	@target VARCHAR(10),	-- Name of target (Clone, Change, State)
  	@numberOfClones int,	-- Number of clones to be created
  	@cloneBatch int		-- Clone batch number (to associate all records from the same clone batch
    AS BEGIN
    
        -- TR_GetProductVariantsForClone - Retrieves the source and null target Product Variant records
        -- along with the Product Variant ID from the source records (to be saved as the Cloned From
        -- Product Variant ID attribute)
        -- for the specified list of Item IDs or the saved set from the designated source repository
        -- to be copied to the designated target repository.
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_GetProductVariantsForClone '5707032,5707033,5707034',null,'Staging','Clone',10,1
        --
        --  EXEC TR_GetProductVariantsForClone null,10548,'Clone','Clone',10,
		--
        -- Workflow Activity:
        --
        -- EXEC TR_GetProductVariantsForClone '%itemIds%',%savedSetId%,'Staging','Clone',%numberOfClones%,%sys.workitem.uid%
        
        DECLARE @sql VARCHAR(max)
        
        -- Determine if saved set was specified
        
        IF @savedSetId IS NULL
        BEGIN
        	-- No code set - use itemIds
        	SET @sql = 'select s.InternalRecordId as source, null as target, s.Product_Variant_ID, ' + 
        		cast(@cloneBatch as VARCHAR) + ' as cloneBatch ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' s ' +
        		'JOIN (select top ' + cast(@numberOfClones as varchar) + ' 1 as col from sys.all_objects) a on col=1 ' +
        		'WHERE s.InternalRecordId in (' + @itemIds + ')'
        END
        ELSE
        BEGIN
        	-- Code set - use it
        	SET @sql = 'select s.InternalRecordId as source, null as target, s.Product_Variant_ID, ' + 
        		cast(@cloneBatch as VARCHAR) + ' as cloneBatch ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' s ' +
        		'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = s.InternalRecordId ' +
        		'JOIN (select top ' + cast(@numberOfClones as varchar) + ' 1 as col from sys.all_objects) a on col=1 ' +
        		'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) 
        END

       	print @sql
       	EXECUTE (@sql)
 		
    END
  go

