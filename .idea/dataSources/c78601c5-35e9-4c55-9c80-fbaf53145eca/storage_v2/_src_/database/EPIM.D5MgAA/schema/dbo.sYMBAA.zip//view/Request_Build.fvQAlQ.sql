CREATE VIEW dbo.[Request_Build] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004582 AS [Request_ID], F_1004583 AS [Request_Status], F_1004584 AS [Requested_By], F_1004620 AS [Workflow_Name] FROM dbo.B_SNAPSHOT_10210 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on Request_Build to informatica
go

