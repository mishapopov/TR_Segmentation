
  CREATE PROCEDURE [dbo].[TR_GetProductVariantPriceForCopy]
  	@itemIds VARCHAR(200),  -- Delimited list of source product variants
  	@savedSetId int,	-- Saved set ID of source product variants
  	@source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
  	@target VARCHAR(10)	-- Name of target (Clone, Change, State)
    AS BEGIN
    
        -- TR_GetProductVariantPriceForCopy - Retrieves the source and target Product Variant Price records 
        -- for the specified list of Product Variant Item IDs or the saved set from the designated source repository
        -- to be copied to the designated target repository.  Returns the internal record Id of each 
        -- source Product Variant Price record along with the Internal Record Id of the corresponding 
        -- target Product Variant Price record (or null if it doesn't exist).  Not to be used for cloning
        -- as cloning will need new IDs for all cloned records.
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_GetProductVariantPriceForCopy '5707059,5707061,5707054,5707055,5707056',null,'Staging','Change'
        --
        --  EXEC TR_GetProductVariantPriceForCopy null,10548,'Staging','Change'
		--
        -- Workflow Activity:
        --
        -- EXEC TR_GetProductVariantPriceForCopy '%itemIds%',%savedSetId%,'Staging','Change'
        
        DECLARE @sql VARCHAR(max)
        
        -- Determine if saved set was specified
        
        IF @savedSetId IS NULL
        BEGIN
        	-- No code set - use itemIds
        	SET @sql = 'select spvp.InternalRecordId as source, tpvp.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'join PRODUCT_VARIANT_PRICE_' + @source + ' spvp on spvp.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_' + @target + ' tpvp ON tpvp.Product_Price_ID = spvp.Product_Price_ID ' +
        		'WHERE spv.InternalRecordId in (' + @itemIds + ')'
        END
        ELSE
        BEGIN
        	-- Code set - use it
        	SET @sql = 'select spvp.InternalRecordId as source, tpvp.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spv.InternalRecordId ' +
        		'join PRODUCT_VARIANT_PRICE_' + @source + ' spvp on spvp.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_' + @target + ' tpvp ON tpvp.Product_Price_ID = spvp.Product_Price_ID ' +
        		'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) 
        END

       	print @sql
       	EXECUTE (@sql)
 		
    END
  go

