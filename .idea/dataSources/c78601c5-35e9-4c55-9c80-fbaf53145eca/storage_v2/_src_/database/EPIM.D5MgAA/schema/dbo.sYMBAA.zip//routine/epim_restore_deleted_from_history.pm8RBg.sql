
create procedure epim_restore_deleted_from_history
	@repoName nvarchar(255),
	@fromDate datetime,
	@toDate datetime
AS
BEGIN
	DECLARE @repoId bigint;
	DECLARE @profileId bigint;
	DECLARE @pkey1 bigint;
	DECLARE @pkey2 bigint;
	DECLARE @pkey3 bigint;
	DECLARE @pkey4 bigint;
	DECLARE @pkey5 bigint;
	DECLARE @pkey1NullInd bigint;
	DECLARE @pkey2NullInd bigint;
	DECLARE @pkey3NullInd bigint;
	DECLARE @pkey4NullInd bigint;
	DECLARE @pkey5NullInd bigint;
	DECLARE @pkey1DataType nvarchar(32);
	DECLARE @pkey2DataType nvarchar(32);
	DECLARE @pkey3DataType nvarchar(32);
	DECLARE @pkey4DataType nvarchar(32);
	DECLARE @pkey5DataType nvarchar(32);
	DECLARE @strSql nvarchar(MAX);
	DECLARE @pkey1Sql nvarchar(MAX);
	DECLARE @pkey2Sql nvarchar(MAX);
	DECLARE @pkey3Sql nvarchar(MAX);
	DECLARE @pkey4Sql nvarchar(MAX);
	DECLARE @pkey5Sql nvarchar(MAX);
	DECLARE @RowsDeleted bigint;
	DECLARE @debug int;

	BEGIN TRY
		SET NOCOUNT ON;	
		SET @debug=NULL;
		if (@debug is not null) SET NOCOUNT OFF;		
		SELECT @repoId=MASTER_REPOSITORY_ID, @profileId=PROFILE_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @repoName;
		if (@repoId is null)  RAISERROR('Repository not found: %s', 16, 1, @repoName);
		if (@profileId is null)  RAISERROR('Profile not found: %s', 16, 1, @repoName);
		if (@debug is not null) PRINT 'repository id=' + CAST(@repoId AS VARCHAR); 
		if (@debug is not null) PRINT 'profile id=' + CAST(@profileId AS VARCHAR); 
		if (@toDate is null) SET @toDate = GETDATE();
		
		SELECT @pkey1=FORMAT_ATTR_ID, @pkey1NullInd=NULL_IND,@pkey1DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=1;
		SELECT @pkey2=FORMAT_ATTR_ID, @pkey2NullInd=NULL_IND,@pkey2DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=2;
		SELECT @pkey3=FORMAT_ATTR_ID, @pkey3NullInd=NULL_IND,@pkey3DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=3;
		SELECT @pkey4=FORMAT_ATTR_ID, @pkey4NullInd=NULL_IND,@pkey4DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=4;
		SELECT @pkey5=FORMAT_ATTR_ID, @pkey5NullInd=NULL_IND,@pkey5DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=5;
		if (@pkey1 is null)  RAISERROR('Primary key not found: %s', 16, 1, @repoName);
		if (@debug is not null) PRINT '@pkey1= F_' + CAST(@pkey1 AS VARCHAR); 
		if (@debug is not null) if (@pkey2 is not null) PRINT '@pkey2= F_' + CAST(@pkey2 AS VARCHAR); 
		if (@debug is not null) if (@pkey3 is not null) PRINT '@pkey3= F_' + CAST(@pkey3 AS VARCHAR); 
		if (@debug is not null) if (@pkey4 is not null) PRINT '@pkey4= F_' + CAST(@pkey4 AS VARCHAR); 
		if (@debug is not null) if (@pkey5 is not null) PRINT '@pkey5= F_' + CAST(@pkey5 AS VARCHAR); 

		BEGIN
		--Create Temp table
		CREATE TABLE #RepoRecordsToRestore(
			ID BIGINT IDENTITY(1,1) NOT NULL,
			[ITEM_ID] [bigint] NULL,
			[MASTER_REPOSITORY_ID] [bigint] NULL,
			[HAS_ERROR_IND] [int] NULL,
			[SYNC_ACTION] [int] NOT NULL,
			[SYNC_ACTION_DELETE] [int] NULL,
			[IS_DUPLCIATE] [int] NOT NULL,
			[RECORD_STATE] [bigint] NULL,
			[PRODUCTION_STATE] [bigint] NULL,
			[WORKFLOW_STATE] [bigint] NULL,
			[MESSAGE_ID] [nvarchar](255) NULL,
			[TRANSACTION_ID] [nvarchar](255) NULL,
			[ATTR_DATA] [xml] NULL,
			[STATE_UPDATE_TIME] [datetime] NULL,
			[STATE_UPDATE_MSG] [nvarchar](512) NULL,
			[CREATION_DATETIME] [datetime] NOT NULL,
			[CREATED_BY] [int] NOT NULL,
			[LAST_UPDATE_DATETIME] [datetime] NULL,
			[LAST_UPDATE_BY] [bigint] NULL,
			[ATTR_LAST_UPDATE_DATETIME] [datetime] NULL,
			[ATTR_LAST_UPDATE_BY] [bigint] NULL,
			[EXTERNAL_SESSION_INFO] [varchar](20) NOT NULL,
			[PK_COL_1] [nvarchar](128) NULL,
			[PK_COL_2] [nvarchar](128) NULL,
			[PK_COL_3] [nvarchar](120) NULL,
			[PK_COL_4] [nvarchar](32) NULL,
			[PK_COL_5] [nvarchar](32) NULL,
			PRIMARY KEY (ID)
		);
		
		--Insert into temp table
		INSERT INTO #RepoRecordsToRestore
			(
				ITEM_ID, MASTER_REPOSITORY_ID, HAS_ERROR_IND, SYNC_ACTION, SYNC_ACTION_DELETE, IS_DUPLCIATE, RECORD_STATE, 
				PRODUCTION_STATE, WORKFLOW_STATE, MESSAGE_ID, TRANSACTION_ID, ATTR_DATA, STATE_UPDATE_TIME, STATE_UPDATE_MSG, 
				CREATION_DATETIME, CREATED_BY, LAST_UPDATE_DATETIME, LAST_UPDATE_BY, ATTR_LAST_UPDATE_DATETIME, ATTR_LAST_UPDATE_BY, 
				EXTERNAL_SESSION_INFO
			)
		SELECT
			ITEM_ID, MASTER_REPOSITORY_ID, NULL as HAS_ERROR_IND, 0 as SYNC_ACTION, NULL AS SYNC_ACTION_DELETE, 
			0 as IS_DUPLCIATE, RECORD_STATE, PRODUCTION_STATE, WORKFLOW_STATE, MESSAGE_ID, TRANSACTION_ID, 
			ATTR_DATA, STATE_UPDATE_TIME, STATE_UPDATE_MSG, 
			getdate() as CREATION_DATETIME, 1 as CREATED_BY, 
			--MODIFICATION_DATETIME as LAST_UPDATE_DATETIME, 
			ENTRY_DATETIME as LAST_UPDATE_DATETIME, 
			MODIFIED_BY as LAST_UPDATE_BY, 
			--MODIFICATION_DATETIME as ATTR_LAST_UPDATE_DATETIME, 
			ENTRY_DATETIME as ATTR_LAST_UPDATE_DATETIME, 
			MODIFIED_BY as ATTR_LAST_UPDATE_BY, 'Restored from delete' as EXTERNAL_SESSION_INFO
		FROM 
			(select *, row_number() over (partition by item_id 
			  order by REPOSITORY_ITEM_HISTORY_ID desc) as rn
			  from b_repository_item_history where (MASTER_REPOSITORY_ID = @repoId) AND (MODIFY_ACTION = 'delete')
			  AND (ENTRY_DATETIME >= @fromDate)
			  AND (ENTRY_DATETIME <= @toDate)
			  
			) a
		where rn = 1 order by item_id;
		PRINT 'Found ' + CAST(@@ROWCOUNT as VARCHAR) + ' records that were deleted';
		
		--TODO: Change to find based on primary key?
		--don't add back item if it has already been restored
		DELETE FROM #RepoRecordsToRestore
		FROM  #RepoRecordsToRestore INNER JOIN B_MASTER_REPOSITORY_ITEM ON 
			#RepoRecordsToRestore.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID;
		PRINT 'Of which ' + CAST(@@ROWCOUNT as VARCHAR) + ' records have already been restored and removing from restore list.';

		-- Get PK Values
		SET @strSql = 'UPDATE #RepoRecordsToRestore SET ';
		SET @strSql = @strSql + '[PK_COL_1] = CAST(ATTR_DATA.query(N''data(Item/F_' + CAST(@pkey1 AS VARCHAR) + ')'') AS nvarchar(128))';
		if (@pkey2 is not null) SET @strSql = @strSql + ', [PK_COL_2] = CAST(ATTR_DATA.query(N''data(Item/F_' + CAST(@pkey2 AS VARCHAR) + ')'') AS nvarchar(128))';
		if (@pkey3 is not null) SET @strSql = @strSql + ', [PK_COL_3] = CAST(ATTR_DATA.query(N''data(Item/F_' + CAST(@pkey3 AS VARCHAR) + ')'') AS nvarchar(120))';
		if (@pkey4 is not null) SET @strSql = @strSql + ', [PK_COL_4] = CAST(ATTR_DATA.query(N''data(Item/F_' + CAST(@pkey4 AS VARCHAR) + ')'') AS nvarchar(32))';
		if (@pkey5 is not null) SET @strSql = @strSql + ', [PK_COL_5] = CAST(ATTR_DATA.query(N''data(Item/F_' + CAST(@pkey5 AS VARCHAR) + ')'') AS nvarchar(32))';
		if (@debug is not null) PRINT @strSql;
		EXEC (@strSql);
		PRINT 'Updated ' + CAST(@@ROWCOUNT as VARCHAR) + ' records with primary key information.';
		
		--Insert Back records to B_MASTER_ITEM
		BEGIN TRANSACTION
			SET IDENTITY_INSERT B_MASTER_REPOSITORY_ITEM ON;
			IF @@ERROR <> 0
			BEGIN
				ROLLBACK;
				RAISERROR ('Error inserting restored records', 16, 1);
			END
			INSERT INTO B_MASTER_REPOSITORY_ITEM
				   (ITEM_ID, REPOSITORY_ID, HAS_ERROR_IND, SYNC_ACTION, SYNC_ACTION_DELETE, IS_DUPLICATE, RECORD_STATE, PRODUCTION_STATE, 
				   WORKFLOW_STATE, MESSAGE_ID, TRANSACTION_ID, ATTR_DATA, STATE_UPDATE_TIME, STATE_UPDATE_MSG, CREATION_DATETIME, CREATED_BY, 
				   LAST_UPDATE_DATETIME, LAST_UPDATE_BY, ATTR_LAST_UPDATE_DATETIME, ATTR_LAST_UPDATE_BY, EXTERNAL_SESSION_INFO, PK_COL_1, PK_COL_2, 
				   PK_COL_3, PK_COL_4, PK_COL_5, MODIFY_ACTION)
			SELECT ITEM_ID, MASTER_REPOSITORY_ID, HAS_ERROR_IND, SYNC_ACTION, SYNC_ACTION_DELETE, IS_DUPLCIATE, RECORD_STATE, 
				   PRODUCTION_STATE, WORKFLOW_STATE, MESSAGE_ID, TRANSACTION_ID, ATTR_DATA, STATE_UPDATE_TIME, STATE_UPDATE_MSG, 
				   CREATION_DATETIME, CREATED_BY, LAST_UPDATE_DATETIME, LAST_UPDATE_BY, ATTR_LAST_UPDATE_DATETIME, ATTR_LAST_UPDATE_BY, 
				   EXTERNAL_SESSION_INFO, PK_COL_1, PK_COL_2, PK_COL_3, PK_COL_4, PK_COL_5,'update'
			FROM  #RepoRecordsToRestore;
			IF @@ERROR <> 0
			BEGIN
				ROLLBACK;
				RAISERROR ('Error inserting restored records', 16, 1);
			END
			PRINT 'Restored ' + CAST(@@ROWCOUNT as VARCHAR) + ' records.';

			SET IDENTITY_INSERT B_MASTER_REPOSITORY_ITEM OFF
			IF @@ERROR <> 0
			BEGIN
				ROLLBACK;
				RAISERROR ('Error inserting restored records', 16, 1);
			END
		COMMIT;

		--Drop Table
		DROP TABLE #RepoRecordsToRestore;
		END
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;	
END
go

