create view EPIMV_10293 as select ID, PLT_10295."F_12348" as F_1004365, PLT_10295."F_1" as F_1004364 from PLT_10295
go

