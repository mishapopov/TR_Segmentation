 
create procedure CN_Cleanup_Translation_Request_Queue(
	@batchId		bigint,
	@debugInd		int = 0

)
as
BEGIN
	DECLARE @numRows BIGINT;
	
	-- First, tag the queue entries with the designated batch ID
	DELETE FROM ChangeNotificationTranslationQueue 
	WHERE batchId = @batchId
	
	SET @numRows = @@ROWCOUNT;
	
	if @debugInd = 1
	BEGIN
		print 'Deleted ' + cast(@numRows as VARCHAR) + ' rows from queue.'
	END
	
	-- Return results of cleanup
	SELECT CAST(@numRows as VARCHAR) + ' rows deleted for batch ' + CAST(@batchId AS VARCHAR) AS Results
	
	
END
go

