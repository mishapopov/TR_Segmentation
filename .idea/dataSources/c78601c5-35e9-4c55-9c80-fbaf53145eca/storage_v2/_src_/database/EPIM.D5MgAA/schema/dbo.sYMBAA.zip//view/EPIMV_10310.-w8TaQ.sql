create view EPIMV_10310 as select ID, PLT_10312."F_1" as F_1004364, PLT_10312."F_12691" as F_1004727 from PLT_10312
go

