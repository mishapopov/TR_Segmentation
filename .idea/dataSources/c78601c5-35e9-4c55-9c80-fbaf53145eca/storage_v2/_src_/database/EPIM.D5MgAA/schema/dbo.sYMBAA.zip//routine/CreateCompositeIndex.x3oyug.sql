
CREATE PROCEDURE [dbo].[CreateCompositeIndex]
   @repositoryName VARCHAR(200),
   @indexName VARCHAR(200),
   @attributeList VARCHAR(500)
AS
BEGIN
    DECLARE @dropIndexSql nvarchar(MAX);
    DECLARE @querySql VARCHAR(MAX) -- holds the SQL statement for creating the view
    DECLARE @attributeName VARCHAR(255)
    DECLARe @systemName VARCHAR(50)
    DECLARE @attributeId VARCHAR(10)
    DECLARE @repositoryId VARCHAR(10)
    DECLARE @key VARCHAR(255)
    DECLARE @value VARCHAR(max)

    PRINT 'REPO=' + @repositoryName + '  INDEX=' + @indexName + '  ATTR=' + @attributeList
    -- Get the repository ID
    SELECT @repositoryId = cast(master_repository_id as VARCHAR) from b_master_repository where name = @repositoryName

    -- Create the SQL perform the extraction query
    
    SET @dropIndexSql = 'if exists (select * from sys.indexes WHERE name = ''' + @indexName + ''') drop Index ' + @indexName + ' ON B_SNAPSHOT_' + @repositoryId;
    SET @querySql = 'CREATE NONCLUSTERED INDEX [' + @indexName + '] ON [dbo].[B_SNAPSHOT_' + @repositoryId + '] (';
            
    DECLARE @position int
    DECLARE @keyPosition int
    DECLARE @firstAttribute int
    SET @firstAttribute = 1;
    SET @position = 1;
    SET @attributeList = @attributeList + ',';
    WHILE charindex(',',@attributeList,@position) <> 0
       BEGIN
          SET @attributeName = substring(@attributeList, @position, charindex(',',@attributeList,@position) - @position);
          
          -- Get the system name for the attribute
   
          SET @systemName = @attributeName;
          select @systemName = 'F_' + cast(f.format_attr_id as varchar) from b_format_attr f, b_master_repository m
	      WHERE f.profile_id = m.profile_id
	      AND m.name = @repositoryName
	      AND (f.name = @attributeName
	      OR f.restricted_Name = @attributeName)
	  
	  SELECT attributeName=@attributeName,systemName=@systemName
	  if (@firstAttribute <> 1) 
	  BEGIN
		SET @querySql = @querySql + ',';
	  END
	  SET @firstAttribute = 0;	  
	  SET @querySql = @querySql + '[' + @systemName + '] ASC';
	      
          -- Next attribute
          SET @position = charindex(',',@attributeList,@position) + 1
       END
    
    
    
    -- Add Remainder of index (except for:  ON [epim_data])
    
    SET @querySql = @querySql + ' ) INCLUDE ( 	[ITEM_ID]) ';
    
    -- Drop the Index
    print @dropIndexSql;
    EXECUTE (@dropIndexSql);


    print @querySql;
    EXECUTE (@querySql) 
        
end
go

