
create procedure epim_contents_replacement_colsize (
      @YourTableName nvarchar(255),
      @ResultsTableName nvarchar(255)  )
As
BEGIN
	DECLARE @sql nvarchar(MAX) = '';

	DECLARE @whileIter int = 1
	DECLARE @whileTotal int  

	SELECT @whileTotal = COUNT(*) FROM sys.columns c
                         INNER JOIN  sys.types t ON c.user_type_id = t.user_type_id
                         WHERE c.object_id = OBJECT_ID(@YourTableName)
	WHILE @whileIter <= @whileTotal
	BEGIN

		SELECT  @sql =  N'INSERT INTO ' + @ResultsTableName + ' (columnName,  columnLargestValueInData, columnMaxLength) SELECT ''' 
						+ sc.name + ''' AS columnName, max(len(dbo.epim_convert_xml_special_chars([' + sc.name + ']))), ' + 
						CONVERT(varchar,sc.max_length) + ' FROM [' + t.name + ']'  
		FROM  sys.tables AS t
		INNER JOIN sys.columns AS sc ON t.object_id = sc.object_id
		INNER JOIN sys.types AS st ON sc.system_type_id = st.system_type_id
		WHERE column_id = @whileIter
		AND t.name = @YourTableName
		AND st.name IN ('char', 'varchar', 'nchar', 'nvarchar')

		PRINT @sql

		exec sp_executesql @sql
		SET @whileIter += 1
	END

END;
go

