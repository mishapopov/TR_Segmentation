create view EPIMV_10313 as select ID, PLT_10315."F_1" as F_1004523, PLT_10315."F_12498" as F_1004524 from PLT_10315
go

