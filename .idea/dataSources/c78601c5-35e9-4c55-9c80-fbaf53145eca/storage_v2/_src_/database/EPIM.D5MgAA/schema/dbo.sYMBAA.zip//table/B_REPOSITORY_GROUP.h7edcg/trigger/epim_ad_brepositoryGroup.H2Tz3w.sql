CREATE TRIGGER epim_ad_brepositoryGroup ON B_REPOSITORY_GROUP
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = repository_group_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BrepositoryGroup', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BrepositoryGroup', @obj_id;
    END
go

