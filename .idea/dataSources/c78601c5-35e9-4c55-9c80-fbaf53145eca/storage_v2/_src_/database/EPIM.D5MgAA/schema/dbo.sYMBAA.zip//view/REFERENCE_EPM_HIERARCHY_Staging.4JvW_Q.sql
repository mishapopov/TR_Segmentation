CREATE VIEW dbo.[REFERENCE_EPM_HIERARCHY_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004681 AS [EPM_Reference_Code], F_1004682 AS [System_Name], F_1004683 AS [Value] FROM dbo.B_SNAPSHOT_10240 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to dbadmin
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to ewsys
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to boomi
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to informatica
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to som
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to apttus
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to epmdev
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to MDMAdmin
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to produser1
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to produser3
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to produser2
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to VIEW_ACCESS
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to integration_team
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to ecmxread
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to MPOPOV_TEST
go

grant select on REFERENCE_EPM_HIERARCHY_Staging to digital
go

