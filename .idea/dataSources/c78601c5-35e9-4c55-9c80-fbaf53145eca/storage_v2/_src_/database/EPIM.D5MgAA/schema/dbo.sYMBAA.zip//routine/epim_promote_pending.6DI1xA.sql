--#BEGIN#
create procedure [dbo].[epim_promote_pending]
	@stagingRepoName nvarchar(255),
	@savedsetName nvarchar(255),
	@itemIdList varchar(max)
AS
BEGIN
	DECLARE @savedSetId bigint;
	DECLARE @stageRepoId bigint;
	DECLARE @prodRepoId bigint;
	DECLARE @profileId bigint;
	DECLARE @pkey1 bigint;
	DECLARE @pkey2 bigint;
	DECLARE @pkey3 bigint;
	DECLARE @pkey4 bigint;
	DECLARE @pkey5 bigint;
	DECLARE @pkey1NullInd bigint;
	DECLARE @pkey2NullInd bigint;
	DECLARE @pkey3NullInd bigint;
	DECLARE @pkey4NullInd bigint;
	DECLARE @pkey5NullInd bigint;
	DECLARE @pkey1DataType nvarchar(32);
	DECLARE @pkey2DataType nvarchar(32);
	DECLARE @pkey3DataType nvarchar(32);
	DECLARE @pkey4DataType nvarchar(32);
	DECLARE @pkey5DataType nvarchar(32);
	DECLARE @prodRepoName nvarchar(255);
	DECLARE @RowsDeleted bigint;
	DECLARE @strSql nvarchar(MAX);
	DECLARE @debug int;

	BEGIN TRY
		SET @debug=null;
		if (@debug is null) SET NOCOUNT ON;
		SET @prodRepoName=REPLACE(@stagingRepoName, 'Staging','Production');
		SELECT @stageRepoId=MASTER_REPOSITORY_ID, @profileId=PROFILE_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @stagingRepoName;
		if (@stageRepoId is null)  RAISERROR('Staging Repository not found: %s', 16, 1, @stagingRepoName);
		if (@profileId is null)  RAISERROR('Profile not found: %s', 16, 1, @stagingRepoName);
		SELECT @prodRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE NAME = @prodRepoName;
		if (@prodRepoId is null)  RAISERROR('Production Repository not found: %s', 16, 1, @stagingRepoName);
		SELECT @pkey1=FORMAT_ATTR_ID, @pkey1NullInd=NULL_IND,@pkey1DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=1;
		SELECT @pkey2=FORMAT_ATTR_ID, @pkey2NullInd=NULL_IND,@pkey2DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=2;
		SELECT @pkey3=FORMAT_ATTR_ID, @pkey3NullInd=NULL_IND,@pkey3DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=3;
		SELECT @pkey4=FORMAT_ATTR_ID, @pkey4NullInd=NULL_IND,@pkey4DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=4;
		SELECT @pkey5=FORMAT_ATTR_ID, @pkey5NullInd=NULL_IND,@pkey5DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=5;

		if (@pkey1 is null)  RAISERROR('Primary key not found: %s', 16, 1, @stagingRepoName);
		if (@savedsetName is null AND @itemIdList is null)  RAISERROR('Saved Set name or Item id List must be defined: %s', 16, 1, @stagingRepoName);
		if (@debug is not null) PRINT 'create temp table'; 
		CREATE TABLE #PendFuture(
			ID BIGINT IDENTITY(1,1) NOT NULL,
			[STAGE_REPSOITORY_ID] [bigint] NULL,
			[STAGE_NAME] [nvarchar](255) NULL,
			[DESCRIPTION] [nvarchar](512) NULL,
			[EFFECTIVE_DATE] [datetime] NULL,
			[EXPIRATION_DATE] [datetime] NULL,
			[REQUEST_TYPE] [bigint] NULL,
			[CREATED_BY] [bigint] NULL,
			[CREATION_DATETIME] [datetime] NULL,
			[LAST_UPDATE_BY] [bigint] NULL,
			[LAST_UPDATE_DATETIME] [datetime] NULL,
			[APPROVAL_REQUIRED_IND] [bigint] NULL,
			[EXTERNAL_SESSION_INFO] [nvarchar](512) NULL,
			[REQUEST_STATUS] [bigint] NULL,
			[STAGE_ITEM_ID] [bigint] NULL,
			[APPROVAL_IND] [bigint] NULL,
			[APPLIED_STATUS_CODE] [bigint] NULL,
			[HAS_ERROR_IND] [bigint] NULL,
			[STAGE_REQUEST_ID] [bigint] NULL,
			[STAGE_REQUEST_DETAIL_ID] [bigint] NULL,
			[PROD_REPSOITORY_ID] [bigint] NULL,
			[PROD_ITEM_ID] [bigint] NULL,
			[PROD_REQUEST_ID] [bigint] NULL,
			[PROD_REQUEST_DETAIL_ID] [bigint] NULL,
			[PROD_NAME] [nvarchar](255) NULL,
			PRIMARY KEY (ID)	
		) ON [PRIMARY];
		if (@debug is not null) PRINT 'Insert Staging futures into temp table'; 
		if (@savedsetName IS NOT NULL)
		BEGIN
			if (@debug is not null) PRINT 'Checking saved set ' + @savedsetName; 
			SELECT  @savedSetId=ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr WHERE 
			    ss.saved_set_id = ssr.saved_set_id and ssr.MASTER_REPOSITORY_ID=@stageRepoId and NAME = @savedsetName;	
			if (@savedSetId is null)  RAISERROR('Saved Set not found: %s', 16, 1, @savedsetName);
			if (@debug is not null) PRINT 'Get Items for saved set : "' + @savedsetName + '"	= ' + cast(@savedSetId as varchar);
			INSERT INTO #PendFuture
								  (STAGE_REPSOITORY_ID, STAGE_NAME, DESCRIPTION, EFFECTIVE_DATE, EXPIRATION_DATE, REQUEST_TYPE, CREATED_BY, CREATION_DATETIME, LAST_UPDATE_BY, 
								  LAST_UPDATE_DATETIME, APPROVAL_REQUIRED_IND, EXTERNAL_SESSION_INFO, REQUEST_STATUS, STAGE_ITEM_ID, APPROVAL_IND, APPLIED_STATUS_CODE,
								   HAS_ERROR_IND, STAGE_REQUEST_ID, STAGE_REQUEST_DETAIL_ID,PROD_REPSOITORY_ID,PROD_NAME)
			SELECT     pr.REPOSITORY_ID AS STAGE_REPSOITORY_ID, pr.NAME, pr.DESCRIPTION, pr.EFFECTIVE_DATE, pr.EXPIRATION_DATE, pr.REQUEST_TYPE, pr.CREATED_BY, 
								  pr.CREATION_DATETIME, pr.LAST_UPDATE_BY, pr.LAST_UPDATE_DATETIME, pr.APPROVAL_REQUIRED_IND, pr.EXTERNAL_SESSION_INFO, pr.REQUEST_STATUS, 
								  prd.ITEM_ID AS STAGE_ITEM_ID, prd.APPROVAL_IND, prd.APPLIED_STATUS_CODE, prd.HAS_ERROR_IND, pr.PENDING_REQUEST_ID AS STAGE_REQUEST_ID, 
								  prd.PENDING_REQUEST_DETAIL_ID AS STAGE_REQUEST_DETAIL_ID, @prodRepoId AS PROD_REPSOITORY_ID, pr.NAME + '_prod'
			FROM         B_PENDING_REQUEST_DETAIL AS prd with (nolock)INNER JOIN
								  B_PENDING_REQUEST AS pr with (nolock) ON prd.PENDING_REQUEST_ID = pr.PENDING_REQUEST_ID INNER JOIN
								  B_SAVED_SET_ITEM AS ssi with (nolock) ON prd.ITEM_ID = ssi.ITEM_ID
			WHERE     (ssi.SAVED_SET_ID = @savedSetId) AND (pr.REPOSITORY_ID=@stageRepoId) AND (pr.EFFECTIVE_DATE >= GETDATE()) AND (prd.APPLIED_STATUS_CODE = 0);
		END
		if (@itemIdList IS NOT NULL)
		BEGIN
			if (@debug is not null) PRINT 'Get Items for list ' + @itemIdList; 
			CREATE TABLE #PendFuture2(
				ITEM_ID [bigint] NULL
			);
			SET @strSql =	'INSERT INTO #PendFuture2 (ITEM_ID) SELECT a.ITEM_ID FROM (SELECT ITEM_ID FROM B_MASTER_REPOSITORY_ITEM with (nolock) ' +
							' WHERE (ITEM_ID IN (' + @itemIdList + '))) AS a ' +
							' WHERE NOT EXISTS (SELECT STAGE_ITEM_ID FROM #PendFuture AS b with (nolock) WHERE b.STAGE_ITEM_ID = a.ITEM_ID)';
			if (@debug is not null) PRINT @strSql;
			EXEC (@strSql);
			INSERT INTO #PendFuture
								  (STAGE_REPSOITORY_ID, STAGE_NAME, DESCRIPTION, EFFECTIVE_DATE, EXPIRATION_DATE, REQUEST_TYPE, CREATED_BY, CREATION_DATETIME, LAST_UPDATE_BY, 
								  LAST_UPDATE_DATETIME, APPROVAL_REQUIRED_IND, EXTERNAL_SESSION_INFO, REQUEST_STATUS, STAGE_ITEM_ID, APPROVAL_IND, APPLIED_STATUS_CODE,
								   HAS_ERROR_IND, STAGE_REQUEST_ID, STAGE_REQUEST_DETAIL_ID,PROD_REPSOITORY_ID,PROD_NAME)
			SELECT     pr.REPOSITORY_ID AS STAGE_REPSOITORY_ID, pr.NAME, pr.DESCRIPTION, pr.EFFECTIVE_DATE, pr.EXPIRATION_DATE, pr.REQUEST_TYPE, pr.CREATED_BY, 
								  pr.CREATION_DATETIME, pr.LAST_UPDATE_BY, pr.LAST_UPDATE_DATETIME, pr.APPROVAL_REQUIRED_IND, pr.EXTERNAL_SESSION_INFO, pr.REQUEST_STATUS, 
								  prd.ITEM_ID AS STAGE_ITEM_ID, prd.APPROVAL_IND, prd.APPLIED_STATUS_CODE, prd.HAS_ERROR_IND, pr.PENDING_REQUEST_ID AS STAGE_REQUEST_ID, 
								  prd.PENDING_REQUEST_DETAIL_ID AS STAGE_REQUEST_DETAIL_ID, @prodRepoId AS PROD_REPSOITORY_ID, pr.NAME + '_prod'
			FROM         B_PENDING_REQUEST_DETAIL AS prd with (nolock)INNER JOIN
								  B_PENDING_REQUEST AS pr with (nolock) ON prd.PENDING_REQUEST_ID = pr.PENDING_REQUEST_ID INNER JOIN
								  #PendFuture2 AS ssi with (nolock) ON prd.ITEM_ID = ssi.ITEM_ID
			WHERE     (pr.REPOSITORY_ID=@stageRepoId) AND (pr.EFFECTIVE_DATE >= GETDATE()) AND (prd.APPLIED_STATUS_CODE = 0);
			DROP TABLE #PendFuture2;
		END

		if (@debug is not null) PRINT 'Check if any futures exists'; 
		IF EXISTS(SELECT TOP (1) 1 as expr1 FROM #PendFuture) 
		BEGIN
			if (@debug is not null) PRINT 'Update production item id from staging item id'; 
			SET @strSql = 'UPDATE #PendFuture SET PROD_ITEM_ID = tp.ITEM_ID FROM ';
			SET @strSql = @strSql + '(SELECT s.ITEM_ID, s.F_' + CAST(@pkey1 as varchar) + ' as pk1 ';
			if (@pkey2 is not null) 
			BEGIN
				if (@pkey2NullInd=1) 
					SET @strSql = @strSql + ', s.F_' + CAST(@pkey2 as varchar) + ' as pk2 ';
				else
					SET @strSql = @strSql + ', ISNULL(s.F_' + CAST(@pkey2 as varchar) + ',-999999) as pk2 ';
			END
			if (@pkey3 is not null)
			BEGIN
				if (@pkey3NullInd=1) 
					SET @strSql = @strSql + ', s.F_' + CAST(@pkey3 as varchar) + ' as pk3 ';
				else
					SET @strSql = @strSql + ', ISNULL(s.F_' + CAST(@pkey3 as varchar) + ',-999999) as pk3 ';
			END			
			if (@pkey4 is not null)
			BEGIN
				if (@pkey4NullInd=1) 
					SET @strSql = @strSql + ', s.F_' + CAST(@pkey4 as varchar) + ' as pk4 ';
				else
					SET @strSql = @strSql + ', ISNULL(s.F_' + CAST(@pkey4 as varchar) + ',-999999) as pk4 ';
			END
			if (@pkey5 is not null)
			BEGIN
				if (@pkey5NullInd=1) 
					SET @strSql = @strSql + ', s.F_' + CAST(@pkey5 as varchar) + ' as pk5 ';
				else
					SET @strSql = @strSql + ', ISNULL(s.F_' + CAST(@pkey5 as varchar) + ',-999999) as pk5 ';
			END
			SET @strSql = @strSql + ' FROM B_SNAPSHOT_' + CAST(@stageRepoId as varchar) + ' AS s with (nolock)) ts ';
			SET @strSql = @strSql + ' INNER JOIN ';
			SET @strSql = @strSql + ' (SELECT p.ITEM_ID, p.F_' + CAST(@pkey1 as varchar) + ' as pk1 ';
			if (@pkey2 is not null) 
			BEGIN
				if (@pkey2NullInd=1) 
					SET @strSql = @strSql + ', p.F_' + CAST(@pkey2 as varchar) + ' as pk2 ';
				else
					SET @strSql = @strSql + ', ISNULL(p.F_' + CAST(@pkey2 as varchar) + ',-999999) as pk2 ';
			END
			if (@pkey3 is not null)
			BEGIN
				if (@pkey3NullInd=1) 
					SET @strSql = @strSql + ', p.F_' + CAST(@pkey3 as varchar) + ' as pk3 ';
				else
					SET @strSql = @strSql + ', ISNULL(p.F_' + CAST(@pkey3 as varchar) + ',-999999) as pk3 ';
			END			
			if (@pkey4 is not null)
			BEGIN
				if (@pkey4NullInd=1) 
					SET @strSql = @strSql + ', p.F_' + CAST(@pkey4 as varchar) + ' as pk4 ';
				else
					SET @strSql = @strSql + ', ISNULL(p.F_' + CAST(@pkey4 as varchar) + ',-999999) as pk4 ';
			END
			if (@pkey5 is not null)
			BEGIN
				if (@pkey5NullInd=1) 
					SET @strSql = @strSql + ', p.F_' + CAST(@pkey5 as varchar) + ' as pk5 ';
				else
					SET @strSql = @strSql + ', ISNULL(p.F_' + CAST(@pkey5 as varchar) + ',-999999) as pk5 ';
			END
			SET @strSql = @strSql + ' FROM B_SNAPSHOT_' + CAST(@prodRepoId as varchar) + ' AS p with (nolock)) tp ';
			SET @strSql = @strSql + ' ON ts.pk1=tp.pk1 ';
			if (@pkey2 is not null) SET @strSql = @strSql + ' AND ts.pk2=tp.pk2 ';
			if (@pkey3 is not null) SET @strSql = @strSql + ' AND ts.pk3=tp.pk3 ';
			if (@pkey4 is not null) SET @strSql = @strSql + ' AND ts.pk4=tp.pk4 ';
			if (@pkey5 is not null) SET @strSql = @strSql + ' AND ts.pk5=tp.pk5 ';
			SET @strSql = @strSql + ' INNER JOIN #PendFuture ON ts.ITEM_ID = #PendFuture.STAGE_ITEM_ID'		

			if (@debug is not null) PRINT @strSql;
			EXEC (@strSql);
			if (@debug is not null) PRINT 'Check if production item id exists'; 
			IF EXISTS(SELECT TOP (1) 1 as expr1 FROM #PendFuture WHERE (PROD_ITEM_ID IS NOT NULL)) 
			BEGIN
				if (@debug is not null) PRINT 'Delete from pending request attr where prod item exists';
				SET @RowsDeleted = 1
				WHILE (@RowsDeleted > 0)
				BEGIN
					DELETE TOP (10000)
						FROM B_PENDING_REQUEST_ATTR
						FROM B_PENDING_REQUEST_ATTR INNER JOIN
							 B_PENDING_REQUEST_DETAIL AS prd ON 
							 B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID = prd.PENDING_REQUEST_DETAIL_ID 
							 INNER JOIN #PendFuture AS pf ON 
						    prd.ITEM_ID = pf.PROD_ITEM_ID
						WHERE (pf.PROD_ITEM_ID IS NOT NULL)
						SET @RowsDeleted = @@ROWCOUNT
				END
				if (@debug is not null) PRINT 'Delete from pending request detail where prod item exist';
				SET @RowsDeleted = 1
				WHILE (@RowsDeleted > 0)
				BEGIN
					DELETE TOP (10000) 
						FROM B_PENDING_REQUEST_DETAIL
						FROM B_PENDING_REQUEST_DETAIL INNER JOIN
							 #PendFuture AS pf ON B_PENDING_REQUEST_DETAIL.ITEM_ID = pf.PROD_ITEM_ID
						WHERE (pf.PROD_ITEM_ID IS NOT NULL)
						SET @RowsDeleted = @@ROWCOUNT
				END
				if (@debug is not null) PRINT 'Delete from pending request for empty prod requests';
				SET @RowsDeleted = 1
				WHILE (@RowsDeleted > 0)
				BEGIN
					DELETE TOP (10000) 
						FROM B_PENDING_REQUEST
						FROM B_PENDING_REQUEST LEFT OUTER JOIN
							 B_PENDING_REQUEST_DETAIL AS prd ON B_PENDING_REQUEST.PENDING_REQUEST_ID = prd.PENDING_REQUEST_ID
						WHERE (prd.PENDING_REQUEST_DETAIL_ID IS NULL) AND (B_PENDING_REQUEST.REPOSITORY_ID = @prodRepoId)					
						SET @RowsDeleted = @@ROWCOUNT
				END
				if (@debug is not null) PRINT 'Update temp with existing prod requests';
				UPDATE	#PendFuture
				SET		PROD_REQUEST_ID = pr.PENDING_REQUEST_ID
				FROM	B_PENDING_REQUEST AS pr INNER JOIN
						#PendFuture ON pr.EFFECTIVE_DATE = #PendFuture.EFFECTIVE_DATE AND pr.NAME = #PendFuture.PROD_NAME AND 
						pr.REPOSITORY_ID = #PendFuture.PROD_REPSOITORY_ID
				WHERE	(#PendFuture.PROD_ITEM_ID IS NOT NULL);
				
				if (@debug is not null) PRINT 'Insert New Pending Requests';
				INSERT INTO B_PENDING_REQUEST
									  (REPOSITORY_ID, NAME, EFFECTIVE_DATE, EXPIRATION_DATE, REQUEST_TYPE, CREATED_BY, CREATION_DATETIME, LAST_UPDATE_BY, 
									  LAST_UPDATE_DATETIME, APPROVAL_REQUIRED_IND, EXTERNAL_SESSION_INFO, REQUEST_STATUS, DESCRIPTION)
				SELECT  DISTINCT PROD_REPSOITORY_ID, PROD_NAME, EFFECTIVE_DATE, EXPIRATION_DATE, REQUEST_TYPE, CREATED_BY, CREATION_DATETIME, LAST_UPDATE_BY, 
									  LAST_UPDATE_DATETIME, -99, EXTERNAL_SESSION_INFO, -99, STAGE_REQUEST_ID
				FROM         #PendFuture
				WHERE     (PROD_ITEM_ID IS NOT NULL) AND (PROD_REQUEST_ID IS NULL)
				ORDER BY STAGE_REQUEST_ID;

				if (@debug is not null) PRINT 'Set Pending Request Id for newly added Item ids';
				UPDATE	#PendFuture
				SET		PROD_REQUEST_ID = pr.PENDING_REQUEST_ID
				FROM	B_PENDING_REQUEST AS pr INNER JOIN
						#PendFuture ON pr.EFFECTIVE_DATE = #PendFuture.EFFECTIVE_DATE AND pr.NAME = #PendFuture.PROD_NAME AND 
						pr.REPOSITORY_ID = #PendFuture.PROD_REPSOITORY_ID
				WHERE     (PROD_ITEM_ID IS NOT NULL) AND (PROD_REQUEST_ID IS NULL);
				
				if (@debug is not null) PRINT 'Insert new Pending Request Details';
				INSERT INTO B_PENDING_REQUEST_DETAIL (PENDING_REQUEST_ID, ITEM_ID, APPROVAL_IND, APPLIED_STATUS_CODE, HAS_ERROR_IND)
				SELECT PROD_REQUEST_ID, PROD_ITEM_ID, -99, -99, HAS_ERROR_IND
				FROM         #PendFuture
				WHERE     (PROD_ITEM_ID IS NOT NULL) AND (PROD_REQUEST_ID IS NOT NULL);
				
				if (@debug is not null) PRINT 'Set Pending Request Detail Id for newly added Item ids';
				UPDATE	#PendFuture
				SET		PROD_REQUEST_DETAIL_ID = prd.PENDING_REQUEST_DETAIL_ID
				FROM	B_PENDING_REQUEST_DETAIL AS prd INNER JOIN
						#PendFuture ON prd.PENDING_REQUEST_ID = #PendFuture.PROD_REQUEST_ID AND prd.ITEM_ID = #PendFuture.PROD_ITEM_ID						
				WHERE     (PROD_ITEM_ID IS NOT NULL) AND (PROD_REQUEST_ID IS NOT NULL);				
				
				if (@debug is not null) PRINT 'Add Request attrs';
				INSERT INTO B_PENDING_REQUEST_ATTR
									  (PENDING_REQUEST_DETAIL_ID, FORMAT_ATTR_ID, REVERT_VALUE, PENDING_VALUE, CALCULATON, TYPE_CODE)
				SELECT     pf.PROD_REQUEST_DETAIL_ID, pra.FORMAT_ATTR_ID, pra.REVERT_VALUE, pra.PENDING_VALUE, pra.CALCULATON, pra.TYPE_CODE
				FROM         #PendFuture AS pf INNER JOIN
									  B_PENDING_REQUEST_ATTR AS pra ON pf.STAGE_REQUEST_DETAIL_ID = pra.PENDING_REQUEST_DETAIL_ID
				WHERE     (pf.PROD_ITEM_ID IS NOT NULL) AND (pf.PROD_REQUEST_ID IS NOT NULL) AND (pf.PROD_REQUEST_DETAIL_ID IS NOT NULL);  		
				
				if (@debug is not null) PRINT 'reset detail status';
				UPDATE	B_PENDING_REQUEST_DETAIL
				SET		APPROVAL_IND = pf.APPROVAL_IND, APPLIED_STATUS_CODE = pf.APPLIED_STATUS_CODE
				FROM	#PendFuture AS pf INNER JOIN
						B_PENDING_REQUEST_DETAIL prd ON pf.PROD_REQUEST_DETAIL_ID = prd.PENDING_REQUEST_DETAIL_ID;
						
				if (@debug is not null) PRINT 'reset request status';
				UPDATE	B_PENDING_REQUEST
				SET		APPROVAL_REQUIRED_IND = pf.APPROVAL_REQUIRED_IND, REQUEST_STATUS = pf.REQUEST_STATUS, DESCRIPTION=NULL
				FROM	#PendFuture AS pf INNER JOIN
						B_PENDING_REQUEST pr ON pf.PROD_REQUEST_ID = pr.PENDING_REQUEST_ID;					
			END
		END
		if (@debug is not null) PRINT 'Drop temp table';
		DROP table #PendFuture

	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;	
END
go

