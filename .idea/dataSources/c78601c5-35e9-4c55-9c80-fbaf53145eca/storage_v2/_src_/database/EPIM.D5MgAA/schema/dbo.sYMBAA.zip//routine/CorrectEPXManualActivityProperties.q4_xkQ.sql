
CREATE PROCEDURE [dbo].[CorrectEPXManualActivityProperties] 
   @epxDB VARCHAR(max),
   @command VARCHAR(10)

AS
BEGIN
-- Correct the null properties in EPX manual activities that were not carried over
-- from the EPX migration.
-- Assumes the EPX database name is "EPX" and the query is run from the EPIM database
-- Syntax:
--
-- CorrectEPXManualActivityProperties <epxDbName>,<command>
--
-- WHERE:
--
--	<epxDbName> - name of the EPX database (e.g., EPX, EPXDEV, etc.)
--	<command> - operation to be performed:
--		VIEW - display the activities that need to be updated
--		UPDATE - update the activities
--
-- Example calls:  
--		CorrectEPXManualActivityProperties N'EPX','VIEW'
--		CorrectEPXManualActivityProperties N'EPX','UPDATE'

	DECLARE @sql VARCHAR(max)
	
	set @sql='';
	
	if (@command = 'UPDATE')
	BEGIN
		-- Update the null properties in manual activities to have empty strings
		
		set @sql=@sql+'update ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY set property_value = '''' where ACTIVITY_PROPERTY_ID in ( ' +
			'select ap.ACTIVITY_PROPERTY_ID from ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY ap ' +
			'join ' + @epxDB + '.dbo.P_ACTIVITY a on a.ACTIVITY_ID = ap.ACTIVITY_ID ' +
			'join ' + @epxDB + '.dbo.P_PROCESS p on a.PROCESS_ID = p.PROCESS_ID ' +
			'where ap.PROPERTY_KEY in ( ' + 
			'''P_WORKITEM_ENABLE_PIM_REPO_PREF_ID'', ' +
			'''P_WORKITEM_ENABLE_PIM_REPO_PREF_NAME'', ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_CRITERIA'', ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_ID'' , ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_NAME'', ' +
			'''P_WORKITEM_ENABLE_PIM_TASK_ICON'', ' +
			'''P_WORKITEM_ENABLE_PIM_TASK_JSON_ATTR'' ' +
		') ' +
		'and ap.PROPERTY_VALUE is null ' +
		'and a.ACTIVITY_TYPE_CODE = 8) ';
	END
	ELSE
	BEGIN
		-- View the null properties in manual activities
	set @sql = 'select p.name, a.name, ap.PROPERTY_KEY, ap.*, a.*, p.* ' +
		'from ' + @epxDB + '.dbo.P_PROCESS p ' +
		'join ' + @epxDB + '.dbo.P_ACTIVITY a on p.PROCESS_ID = a.PROCESS_ID ' +
		'join ' + @epxDB + '.dbo.P_ACTIVITY_PROPERTY ap on ap.ACTIVITY_ID = a.ACTIVITY_ID ' +
		'where ap.PROPERTY_VALUE is null ' +
		'and a.ACTIVITY_TYPE_CODE = 8 ' +
		'and ap.PROPERTY_KEY in ( ' + 
			'''P_WORKITEM_ENABLE_PIM_REPO_PREF_ID'', ' +
			'''P_WORKITEM_ENABLE_PIM_REPO_PREF_NAME'', ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_CRITERIA'', ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_ID'' , ' +
			'''P_WORKITEM_ENABLE_PIM_SEARCH_NAME'', ' +
			'''P_WORKITEM_ENABLE_PIM_TASK_ICON'', ' +
			'''P_WORKITEM_ENABLE_PIM_TASK_JSON_ATTR'' ' +
		') ' +
		'order by p.NAME, a.name, ap.PROPERTY_KEY ';
	END
	
	-- Execute the generated SQL
	
	print @sql
	EXEC (@sql)
END
go

