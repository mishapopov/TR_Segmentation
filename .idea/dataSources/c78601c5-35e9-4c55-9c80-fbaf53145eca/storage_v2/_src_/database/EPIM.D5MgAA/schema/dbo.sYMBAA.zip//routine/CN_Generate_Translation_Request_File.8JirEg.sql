 
create procedure CN_Generate_Translation_Request_File(
	@repositoryName		varchar(255),
	@languageExt		varchar(25),
	@translateLanguageExt	varchar(25),
	@translationName	varchar(100),
	@batchId		bigint,
	@debugInd		int

)
as
BEGIN
/*

CN_Generate_Translation_Request_File - generates a translation request file from the ChangeNotificationTranslationQueue
for a specific repository, source language, and target language

Parameters:

	repositoryName		Name of the repository
	languageExt		Extension of the source language (default if null)
	translateLanguageExt	Extension of the target language
	translationName		Name of the applicable translation definition in the Change Notification Translation Registry repository
	batchId			A unique number (e.g., Export Job attribute value)
	debugInd		Output debug logging if 1

Example Call:

	EXEC CN_Generate_Translation_Request_File N'Brand_Staging',null,'fr','Brand_Staging',1234,1
	
When called, the stored procedure performs the following steps:
1.	Tags each record in the Change Notification Transformation Queue table with matching repository, source and destination language with the batchId.
2.	Returns a result set of the newest translation for each attribute in each record being translated including the following data:
		CN_Translation_Name
		CN_Internal_Record_Id
		CN_Attribute_Name
		oldTranslatedValue (FUTURE)
		CN_Attribute_Value
		changedby
		changedDatetime
		CN_Attribute_Language
		CN_Translate_Language
		primary key columns as defined in the Profile for the repository (attribute names)
		descriptive attributes and their values from the referenced repository record

*/
	DECLARE @sql VARCHAR(max);
	DECLARE @primaryKey VARCHAR(max);
	DECLARE @descriptiveAttributes VARCHAR(max);
	DECLARE @position int
	DECLARE @keyPosition int
	DECLARE @attributeName VARCHAR(max);
	DECLARE @columnName VARCHAR(max);
	DECLARE @numRows BIGINT;
	
	-- First, tag the queue entries with the designated batch ID
	UPDATE 
		ChangeNotificationTranslationQueue 
	SET 
		batchId=@batchId
  	FROM ChangeNotificationTranslationQueue cn
  	JOIN B_MASTER_REPOSITORY_ITEM i on i.ITEM_ID = cn.internalRecordId
        WHERE (cn.dequeueInSyncOnly = 0 OR i.RECORD_STATE = 0)
		AND repositoryName=@repositoryName
		AND isnull(languageExt, '')=isnull(@languageExt, '')
		AND translateLanguageExt=@translateLanguageExt
		AND batchId IS NULL
		AND translationName = @translationName

	SET @numRows = @@ROWCOUNT;
	
	if @debugInd = 1
	BEGIN
		print 'Tagged ' + cast(@numRows as VARCHAR) + ' rows in queue.'
	END
	
	-- Next, construct the SQL to generate the request file entries
	
	SET @sql='WITH trq AS '
	SET @sql=@sql+'( '
	SET @sql=@sql+'   SELECT *, '
	SET @sql=@sql+'   ROW_NUMBER() OVER (PARTITION BY internalRecordId,attributeName,translateLanguageExt ';
	SET @sql=@sql+'   ORDER BY seqNumber DESC) AS rn ';
	SET @sql=@sql+'   FROM ChangeNotificationTranslationQueue ';
	SET @sql=@sql+'   WHERE translationName = ''' + @translationName + ''' ';
	SET @sql=@sql+'   AND batchId = ' + cast(@batchId as VARCHAR);
	SET @sql=@sql+' ) '
	SET @sql=@sql+'SELECT ''' + @translationName + ''' as CN_Translation_Name, ';
	SET @sql=@sql+'trq.internalRecordId as CN_Internal_Record_ID, trq.attributeName as CN_Attribute_Name, ';
	SET @sql=@sql+'null as CN_Attribute_Translated_Value, trq.newValue as CN_Attribute_Value, ';
	SET @sql=@sql+'trq.changedBy, trq.changedDatetime, trq.languageExt as CN_Attribute_Language, ';
	SET @sql=@sql+'trq.translateLanguageExt as CN_Translate_Language, ';
	
	-- Add the primary keys for the source repository
	
	select @primaryKey=STUFF(
	         (SELECT ', i.' + isnull(fa.RESTRICTED_NAME, '"' + fa.NAME + '"') + ' AS "' + fa.NAME + '"'
		          FROM B_FORMAT_ATTR fa
				  JOIN B_MASTER_REPOSITORY m on m.PROFILE_ID = fa.PROFILE_ID
				  WHERE m.NAME = @repositoryName
				  AND fa.PKEY_SEQ_NUM > 0
				  ORDER BY fa.PKEY_SEQ_NUM
		          FOR XML PATH (''))
		          , 1, 1, '')
		FROM B_FORMAT_ATTR;
	
	if @debugInd = 1
	BEGIN
		print 'Primary key: ' + @primaryKey
	END
	
	
	-- Add an alias to each primary key attribute
	
	SET @sql=@sql + @primaryKey;
		
	-- Add any descriptive attributes to the query
	
	select @descriptiveAttributes=isnull(CN_Descriptive_Attribute_Name, '')
		FROM CN_Translation_Registry
		WHERE CN_Translation_Name = @translationName

	
	if @debugInd = 1
	BEGIN
		print 'Descriptive attributes: ' + @descriptiveAttributes
	END
	
		
	if (len(@descriptiveAttributes) > 0)
	BEGIN
		SET @position = 1
		SET @descriptiveAttributes = @descriptiveAttributes + ',';
		WHILE charindex(',',@descriptiveAttributes,@position) <> 0
		BEGIN
			SET @attributeName = substring(@descriptiveAttributes, @position, charindex(',',@descriptiveAttributes,@position) - @position);
			if @debugInd = 1
			BEGIN
				print 'Attribute Name: ' + @attributeName
			END

			-- Get column name for attribute
		
			SELECT @columnName = isnull(fa.RESTRICTED_NAME, '"' + fa.NAME + '"')
				FROM B_FORMAT_ATTR fa
				JOIN B_MASTER_REPOSITORY mr ON fa.PROFILE_ID = mr.PROFILE_ID
				WHERE fa.NAME = @attributeName
				AND mr.NAME = @repositoryName
			if @debugInd = 1
			BEGIN
				print 'Column Name: ' + @columnName
			END

			
			SET @sql=@sql + ',i.' + @columnName + ' AS "' + @attributeName + '"';
		
			-- Next attribute
			SET @position = charindex(',',@descriptiveAttributes,@position) + 1
		END
	END
	
	-- Identify sources of data
	SET @sql=@sql+' FROM CN_Translation_Registry tr';
	SET @sql=@sql+' JOIN trq on tr.CN_Translation_Name = ''' + @translationName + '''';
	SET @sql=@sql+' JOIN ' + @repositoryName + ' i ON i.InternalRecordId = trq.internalRecordId';
	SET @sql=@sql+' WHERE trq.rn = 1';

	-- Execute SQL
	
	if @debugInd = 1
	BEGIN
		print 'sql: ' + @sql
	END
	
	EXECUTE(@sql)
END
go

