create view EPIMV_10118 as select ID, PLT_10118."F_12348" as F_1004365, PLT_10118."F_1" as F_1004364 from PLT_10118
go

