

CREATE PROCEDURE [dbo].[TR_DynamicPriceChangeHash1]
    @internalRecordId int,  -- Internal Record ID of Change Request
    @source VARCHAR(10)	-- Name of source repo (Staging, Clone)

AS BEGIN

    -- TR_DynamicPriceChangeHash1 - Creates a hash for the price records associated to product
    -- variants located within a request.
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_DynamicPriceChangeHash1 5770496,'Change'
    --   5770261 ; 5729970
    --
    -- Workflow Activity:
    --
    -- EXEC TR_DynamicPriceChangeHash1 %itemIds%,'Change'
    --
    -- Create a price hash based on price records values associated to product variants
    -- within a price change request.

    DECLARE @sql nVARCHAR(max)


    Declare @priceHash1 varchar(max);
    set @sql = ' SELECT @priceHash1 = CONCAT(@priceHash1, ' +
               'convert(varchar(max),pvp.Price_Type,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Type_Term,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Start_Date,0),''|'', ' +
               'convert(varchar(max),pvp.Price_End_Date,0),''|'', ' +
               'convert(varchar(max),pvp.Price,0),''|'', ' +
               'convert(varchar(max),pvp.Currency,0),''|'', ' +
               'convert(varchar(max),pvp.Multi_Year_Eligible,0),''|'', ' +
               'convert(varchar(max),pvpt.Price_Tier_Maximum,0),''|'', ' +
               'convert(varchar(max),pvpt.Price_Tier_Minimum,0),''|'', ' +
			   'convert(varchar(max),pvpt.Price,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Tier_Units,0),''|'', ' +
               'convert(varchar(max),pvp.Price_of_Incremental_User,0),''|'', ' +
               'convert(varchar(max),pvp.Customer_Type,0),''|'', ' +
               'convert(varchar(max),pvp.Service_Type,0),''('', ' +
               'row_number() over(order by pvp.Product_Variant_ID, pvp.Product_Price_ID asc),'')'') ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_ID ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'left outer join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pv.Product_Variant_ID = pvp.Product_Variant_ID ' +
               'left outer join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' pvpt on pvpt.Product_Price_ID = pvp.Product_Price_ID ' +
               'and pvp.Product_Variant_ID is not null ' +
               'and pvp.Product_Price_ID is not null ' +
               'and r.InternalRecordId = ' + cast(@internalRecordId as varchar);



    print @sql
    BEGIN TRY
        exec sp_executesql @sql, N'@priceHash1 varchar(max) out', @priceHash1 out
    END TRY
    BEGIN CATCH
        set @priceHash1 = 'none';
    END CATCH

    select master.dbo.fn_varbintohexstr(HASHBYTES('SHA2_256', @priceHash1)) as priceHash1

END
go

