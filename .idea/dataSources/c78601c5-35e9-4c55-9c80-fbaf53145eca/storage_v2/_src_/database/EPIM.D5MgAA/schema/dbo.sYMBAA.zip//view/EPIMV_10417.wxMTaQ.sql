create view EPIMV_10417 as select ID, PLT_10419."F_1" as F_1004364, PLT_10419."F_12682" as F_1004718 from PLT_10419
go

