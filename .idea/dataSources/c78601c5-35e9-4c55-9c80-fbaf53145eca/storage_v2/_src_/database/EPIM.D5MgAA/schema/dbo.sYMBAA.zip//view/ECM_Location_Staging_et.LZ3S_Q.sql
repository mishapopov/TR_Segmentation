CREATE VIEW dbo.[ECM_Location_Staging_et] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated] FROM dbo.B_SNAPSHOT_10308_et s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

