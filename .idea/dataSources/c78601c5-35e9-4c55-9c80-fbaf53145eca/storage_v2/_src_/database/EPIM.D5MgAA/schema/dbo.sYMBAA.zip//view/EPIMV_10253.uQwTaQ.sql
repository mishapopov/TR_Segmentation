create view EPIMV_10253 as select ID, PLT_10255."F_12348" as F_1004365, PLT_10255."F_1" as F_1004364 from PLT_10255
go

