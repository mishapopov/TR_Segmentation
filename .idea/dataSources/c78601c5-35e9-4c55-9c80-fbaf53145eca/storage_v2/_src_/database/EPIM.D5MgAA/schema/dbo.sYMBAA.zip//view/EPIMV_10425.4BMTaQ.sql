create view EPIMV_10425 as select ID, PLT_10427."F_12349" as F_1004366, PLT_10427."F_1" as F_1004364 from PLT_10427
go

