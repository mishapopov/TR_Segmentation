CREATE VIEW dbo.[REFERENCE_ECM_ECC_MAPPING] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005792 AS [BU_Classification_1], F_1005793 AS [BU_Classification_2], F_1005794 AS [BU_Classification_3], F_1005795 AS [BU_Segment_Desc], F_1005796 AS [ECC_Level_1], F_1005797 AS [ECC_Level_2], F_1005798 AS [ECC_Level_3], F_1005791 AS [ECC_Mapping_Id], F_1005799 AS [Source_System_Name] FROM dbo.B_SNAPSHOT_10340 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_ECM_ECC_MAPPING to boomi
go

grant select on REFERENCE_ECM_ECC_MAPPING to informatica
go

grant select on REFERENCE_ECM_ECC_MAPPING to som
go

grant select on REFERENCE_ECM_ECC_MAPPING to epmdev
go

grant select on REFERENCE_ECM_ECC_MAPPING to ecmxread
go

grant select on REFERENCE_ECM_ECC_MAPPING to MPOPOV_TEST
go

grant select on REFERENCE_ECM_ECC_MAPPING to digital
go

