

create view SavedSetFilter as
select distinct m.NAME as RepositoryName, ss.NAME as SavedSetName, s.item_id from b_saved_set_item s
join B_SAVED_SET ss on ss.SAVED_SET_ID = s.SAVED_SET_ID
join B_SAVED_SET_REPO ssr on s.SAVED_SET_ID = ssr.SAVED_SET_ID
join B_MASTER_REPOSITORY m on ssr.MASTER_REPOSITORY_ID = m.MASTER_REPOSITORY_ID

go

