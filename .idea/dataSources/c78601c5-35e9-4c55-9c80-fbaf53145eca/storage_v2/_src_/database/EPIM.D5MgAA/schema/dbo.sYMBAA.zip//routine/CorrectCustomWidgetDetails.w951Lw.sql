
  CREATE PROCEDURE [dbo].CorrectCustomWidgetDetails(
	@profileName VARCHAR(200),
	@attributeName VARCHAR(200),
	@referenceName VARCHAR(200),
	@actualReferenceName VARCHAR(200)
  )
    AS BEGIN
    
        -- CorrectCustomWidgetDetails - Updates the CUSTOM_WIDGET_DETAILS to correct the F_ 
        -- references (which have IDs from the migration source) to the correct F_ references
        -- based on the actualReferenceName
	
	-- Parameters:
	--
	-- profileName - name of the profile
	-- attributeName - name of the attribute with a CUSTOM_WIDGET_DETAILS SQL query that may need to be corrected
	-- referenceName - F_ number of the attribute in the migration source
	-- actualReferenceName - attual attribute name for the reference

        --
        -- Example SQL: 
        --
        --  EXEC CorrectCustomWidgetDetails N'Change Notification Registry','CN_Attribute_Name','F_1001034','CN_Repository_Name'


	DECLARE @profileId BIGINT
	DECLARE @attributeId BIGINT
	DECLARE @correctAttributeId BIGINT
	DECLARE @correctCustomWidgetDetails VARCHAR(max)
	
	-- Get the target profile ID
	SELECT @profileId=PROFILE_ID from B_PROFILE where NAME = @profileName
	
	-- Get the target attribute ID
	SELECT @attributeId=FORMAT_ATTR_ID from B_FORMAT_ATTR where PROFILE_ID = @profileId AND NAME = @attributeName
	
	-- Get the correct attribute ID
	SELECT @correctAttributeId=FORMAT_ATTR_ID from B_FORMAT_ATTR where PROFILE_ID = @profileId AND NAME = @actualReferenceName

	-- Correct the custom widget details
	
	select @correctCustomWidgetDetails = replace(fa.CUSTOM_WIDGET_DETAILS, @referenceName, 'F_' + 
		cast(@correctAttributeId as VARCHAR)) 
		from B_FORMAT_ATTR fa
		where fa.FORMAT_ATTR_ID = @attributeId
	
	-- Only update if correction was defined
	if @correctCustomWidgetDetails is not null
	BEGIN
		update B_FORMAT_ATTR set CUSTOM_WIDGET_DETAILS=@correctCustomWidgetDetails 
		where FORMAT_ATTR_ID = @attributeId
	END
	ELSE
	BEGIN
		SELECT 'Profile=' + @profileName + '  Attribute=' + @attributeName + ' -  details not updated'
	END
END
  go

