create view EPIMV_10294 as select ID, PLT_10296."F_1" as F_1004364 from PLT_10296
go

