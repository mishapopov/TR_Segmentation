
Create Function epim_rtrim (@str nvarchar(MAX)) returns nvarchar(MAX)
As
BEGIN
DECLARE @trimchars nvarchar(10)
SET @trimchars = CHAR(9)+CHAR(10)+CHAR(13)+CHAR(32)
if (@str is not null)
begin
    IF @str LIKE '%[' + @trimchars + ']'
    SET @str = REVERSE(dbo.LTrimX(REVERSE(@str)))
end
RETURN @str
END

go

