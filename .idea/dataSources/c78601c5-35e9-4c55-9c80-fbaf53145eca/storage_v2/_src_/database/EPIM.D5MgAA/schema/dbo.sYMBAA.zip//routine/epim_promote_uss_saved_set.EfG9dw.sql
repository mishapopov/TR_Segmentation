create  PROCEDURE [dbo].[epim_promote_uss_saved_set]
	@stageSavedSetName varchar(255),
	@stageRepository varchar(255),
	@wid int,
	@doSecond int
	
AS
BEGIN
	DECLARE @debug int;
	DECLARE @execStmt  nvarchar(max);   
	DECLARE @stageSavedSetId bigint;
	DECLARE @stageRepoId bigint;
	DECLARE @prodRepoId bigint;
	DECLARE @secondStageRepoId bigint;
	DECLARE @secondProdRepoId bigint;
	DECLARE @secondSavedSetId bigint;
	DECLARE @find nvarchar(5);
    DECLARE @replace nvarchar(5);
    DECLARE @secondSQL nvarchar(max);
    DECLARE @ParmDefinition as NVARCHAR(MAX);
	DECLARE	@productionItemIdList nvarchar(max);
	DECLARE @firstSnapshotName NVARCHAR(255);
	DECLARE @secondSnapshotName NVARCHAR(255);
	DECLARE @prodSavedSetId BIGINT;
	DECLARE @secondProdSavedSetId BIGINT;
	DECLARE @prodRepo varchar(255);
	DECLARE @prodSavedSet varchar(255);
	DECLARE @secondProdRepo varchar(255);
	DECLARE @secondProdSavedSet varchar(255);
	DECLARE @secondStageRepo varchar(255);
	DECLARE @secondSavedSet varchar(255);


	SET @debug=null;
	if (@debug is null) SET NOCOUNT ON;
	
	SET @prodRepo=NULL;
	SET @prodSavedSet=NULL;
	SET @secondProdRepo=NULL;
	SET @secondProdSavedSet=NULL;
	SET @secondStageRepo=NULL;
	SET @secondSavedSet=NULL;

    Set @find = ''+ char(39) +'';
    Set @replace = ''+char(39)+char(39)+'';
    
	SET @prodRepo=NULL;
	SET @secondStageRepo=NULL;
	SET @secondSavedSet=NULL;
	SET @secondProdRepo=NULL;
	SET @secondSQL =NULL;

	IF (@stageRepository = 'PIM_Brand_Staging')
		BEGIN
		SET @prodRepo='PIM_Brand_Production';
		SET @secondStageRepo='PIM_ManufacturerBrand_Staging';
		SET @secondSavedSet='ManuBrandPromote_' + CAST(@wid as varchar);
		SET @secondProdRepo='PIM_ManufacturerBrand_Production';
		SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
		SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
		SET @secondSQL = 'INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) SELECT @param1, mb.InternalRecordId FROM [' + @firstSnapshotName + '] b with(nolock) INNER JOIN [' + @secondSnapshotName + '] mb with(nolock) ON b.[Brand Id] = mb.[Brand Id] INNER JOIN  B_SAVED_SET_ITEM with(nolock) ON b.InternalRecordId = B_SAVED_SET_ITEM.ITEM_ID WHERE (B_SAVED_SET_ITEM.SAVED_SET_ID = @param2)';
		END
	ELSE
		BEGIN
		IF (@stageRepository = 'PIM_Manufacturer_Staging')
			BEGIN
			SET @prodRepo='PIM_Manufacturer_Production';
			SET @secondStageRepo='PIM_ManufacturerBrand_Staging';
			SET @secondSavedSet='ManuBrandPromote_' + CAST(@wid as varchar);
			SET @secondProdRepo='PIM_ManufacturerBrand_Production';
			SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
			SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
			SET @secondSQL = 'INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) SELECT @param1, mb.InternalRecordId FROM [' + @firstSnapshotName + '] m with(nolock) INNER JOIN [' + @secondSnapshotName + '] mb with(nolock) ON m.[Manufacturer Id] = mb.[Manufacturer Id] INNER JOIN  B_SAVED_SET_ITEM with(nolock) ON m.InternalRecordId = B_SAVED_SET_ITEM.ITEM_ID WHERE (B_SAVED_SET_ITEM.SAVED_SET_ID = @param2)';
			END
		ELSE
			BEGIN
			IF (@stageRepository = 'PIM_ManufacturerBrand_Staging')
				BEGIN
				SET @prodRepo='PIM_ManufacturerBrand_Production';
				SET @secondStageRepo=NULL;
				SET @secondSavedSet=NULL;
				SET @secondProdRepo=NULL;
				SET @secondSQL = NULL;
				END
			ELSE
				BEGIN
				IF (@stageRepository = 'PIM_Vendor_Staging')
					BEGIN
					SET @prodRepo='PIM_Vendor_Production';
					SET @secondStageRepo=NULL;
					SET @secondSavedSet=NULL;
					SET @secondProdRepo=NULL;
					SET @secondSQL = NULL;
					END
				ELSE
					BEGIN
					IF (@stageRepository = 'PIM_ProductLine_Staging')
						BEGIN
						SET @prodRepo='PIM_ProductLine_Production';
						SET @secondStageRepo=NULL;
						SET @secondSavedSet=NULL;
						SET @secondProdRepo=NULL;
						SET @secondSQL = NULL;
						END
					ELSE
						BEGIN
						IF (@stageRepository = 'PIM_Product_Staging')
							BEGIN
							SET @prodRepo='PIM_Product_Production';
							SET @secondStageRepo='PIM_TaxonomyCatalog_Staging';
							SET @secondSavedSet='ProductHierarchyPromote_' + CAST(@wid as varchar);
							SET @secondProdRepo='PIM_TaxonomyCatalog_Production';
							SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
							SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
							SET @secondSQL = 'INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) SELECT @param1, h.InternalRecordId FROM [' + @firstSnapshotName + '] s with(nolock) INNER JOIN B_SAVED_SET_ITEM with(nolock) ON s.InternalRecordId = B_SAVED_SET_ITEM.ITEM_ID INNER JOIN [' + @secondSnapshotName + '] h with(nolock) ON s.[SKU Group Auto-Id] = h.[Product ID] WHERE (B_SAVED_SET_ITEM.SAVED_SET_ID = @param2)';
							END
						ELSE
							BEGIN
							IF (@stageRepository = 'PIM_Item_Staging')
								BEGIN
								SET @prodRepo='PIM_Item_Production';
								SET @secondStageRepo='PIM_Extended_Staging';
								SET @secondSavedSet='ItemExtendedPromote_' + CAST(@wid as varchar);
								SET @secondProdRepo='PIM_Extended_Production';
								SELECT @firstSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
								SELECT @secondSnapshotName=PUBLICATION_USER FROM B_MASTER_REPOSITORY WHERE NAME = @secondStageRepo;
								SET @secondSQL = 'INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID) SELECT @param1, e.InternalRecordId FROM [' + @secondSnapshotName + '] e with(nolock) INNER JOIN [' + @firstSnapshotName + '] i with(nolock) ON e.[Master Item Id] = i.[Master Item Id] INNER JOIN B_SAVED_SET_ITEM with(nolock) ON i.InternalRecordId = B_SAVED_SET_ITEM.ITEM_ID WHERE (B_SAVED_SET_ITEM.SAVED_SET_ID = @param2)';
								END
							ELSE
								BEGIN
								IF (@stageRepository = 'PIM_Extended_Staging')
									BEGIN
									SET @prodRepo='PIM_Extended_Production';
									SET @secondStageRepo=NULL;
									SET @secondSavedSet=NULL;
									SET @secondProdRepo=NULL;
									SET @secondSQL = NULL;
									END
								ELSE
									BEGIN
										IF (@stageRepository = 'PIM_TaxonomyCatalog_Staging')
											BEGIN
												SET @prodRepo='PIM_TaxonomyCatalog_Production';
												SET @secondStageRepo=NULL;
												SET @secondSavedSet=NULL;
												SET @secondProdRepo=NULL;
												SET @secondSQL = NULL;
											END
										ELSE
										BEGIN
											RAISERROR('Reopo not found: %s', 16, 1, @stageRepository);
										END
									END
								END
							END
						END
					END
				END
			END
		END
    SELECT @stageRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY WHERE NAME = @stageRepository;
    if (@stageRepoId IS NOT NULL)
		BEGIN
		--SET @execStmt = 'IF NOT EXISTS (SELECT ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr 
		--WHERE ss.saved_set_id = ssr.saved_set_id and ssr.MASTER_REPOSITORY_ID = ' + CAST(@stageRepoId as varchar) + ' 
		--AND NAME = ''' +  replace(@stageSavedSetName,@find,@replace)   + ''') 
		--INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME) 
		--VALUES (1, ' + CAST(@stageRepoId as varchar) + ', N''' + replace(@stageSavedSetName,@find,@replace)  + ''', N''system defined saved set'', 0, GETDATE())';
		--if (@debug is not null) PRINT '142: ' + @execStmt
		--EXECUTE (@execStmt);
		--SELECT  @stageSavedSetId=saved_Set_id FROM B_SAVED_SET with(nolock) WHERE MASTER_REPOSITORY_ID=@stageRepoId and NAME = @stageSavedSetName;
		IF NOT EXISTS (SELECT ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr WHERE 
		               ss.saved_set_id = ssr.saved_set_id and NAME = @stageSavedSetName AND ssr.MASTER_REPOSITORY_ID=@stageRepoId) 
		BEGIN
		   INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME) 
		       VALUES (1, @stageRepoId, @stageSavedSetName, 'system defined saved set', 0, GETDATE());
		   SELECT  @stageSavedSetId=SCOPE_IDENTITY();	
		   INSERT INTO B_SAVED_SET_REPO(MASTER_REPOSITORY_ID, SAVED_SET_ID) VALUES (@stageRepoId, @stageSavedSetId);
		END
				
		
		if (@debug is not null) PRINT '145: ' + 'Saved Set id for ' + @stageSavedSetName + ' is ' + CAST(@stageSavedSetId as varchar(50));   
		if (@debug is not null) PRINT '146: @secondStageRepo=' + @secondStageRepo    
		IF (@secondStageRepo is not null AND @doSecond=1)
			BEGIN
			SELECT @secondStageRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY with(nolock) WHERE NAME = @secondStageRepo;
			--SET @execStmt = 'IF NOT EXISTS (SELECT saved_Set_id FROM B_SAVED_SET WHERE MASTER_REPOSITORY_ID = 
			--' + CAST(@secondStageRepoId as varchar) + ' AND NAME = ''' +  replace(@secondSavedSet,@find,@replace)   + ''') 
			--INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME) 
			--VALUES (1, ' + CAST(@secondStageRepoId as varchar) + ', N''' + replace(@secondSavedSet,@find,@replace)  + ''', N''system defined saved set'', 0, GETDATE())';
			--if (@debug is not null) PRINT '151: ' + @execStmt
			--EXECUTE (@execStmt);
			--SELECT  @secondSavedSetId=saved_Set_id FROM B_SAVED_SET with(nolock) WHERE MASTER_REPOSITORY_ID=@secondStageRepoId and NAME = @secondSavedSet;
		     IF NOT EXISTS (SELECT ss.saved_Set_id FROM B_SAVED_SET ss, B_SAVED_SET_REPO ssr WHERE 
		               ss.saved_set_id = ssr.saved_set_id and NAME = @secondSavedSet AND ssr.MASTER_REPOSITORY_ID=@secondStageRepoId) 
		     BEGIN
		        INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME) 
		            VALUES (1, @secondStageRepoId, @secondSavedSet, 'system defined saved set', 0, GETDATE());
		        SELECT  @secondSavedSetId=SCOPE_IDENTITY();	
		        INSERT INTO B_SAVED_SET_REPO(MASTER_REPOSITORY_ID, SAVED_SET_ID) VALUES (@secondStageRepoId, @secondSavedSetId);
		     END

			if (@debug is not null) PRINT '154: ' + 'Saved Set id for ' + @secondSavedSet + ' is ' + CAST(@secondSavedSetId as varchar(50));   
		    
			DELETE FROM B_SAVED_SET_ITEM WHERE saved_Set_id=@secondSavedSetId;
			SET @ParmDefinition = N'@param1 int, @param2 int' 
			if (@debug is not null) PRINT '158: ' + @secondSQL
			EXEC sp_executesql  @secondSQL, @ParmDefinition,  @param1 = @secondSavedSetId, @param2 = @stageSavedSetId;
			END
			
		if (@debug is not null) PRINT '162: Promote Main'
		create table #tmpPromote(tmpResultLog nvarchar(max))
		if (@debug is not null) PRINT '163: create table'
		insert into #tmpPromote EXEC epim_promote_bulk @stageRepository, @prodRepo, @stageSavedSetName, NULL, 1, '','','','',0,@prodSavedSet output, @productionItemIdList output
		if (@debug is not null) PRINT '164:get prod'
		SELECT @prodRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY WHERE NAME = @prodRepo;
		if (@debug is not null) PRINT '172: do if'
		IF (@secondStageRepo is not null AND @doSecond=1)
			BEGIN
				if (@debug is not null) PRINT '173: Promote Second'
				insert into #tmpPromote EXEC epim_promote_bulk @secondStageRepo, @secondProdRepo, @secondSavedSet, NULL, 0 , '','','','',0,@secondProdSavedSet output, @productionItemIdList output
				SELECT @secondProdRepoId=MASTER_REPOSITORY_ID FROM B_MASTER_REPOSITORY WHERE NAME = @secondProdRepo;
			END
		ELSE
			BEGIN
			SET @secondStageRepo=null;
			SET @secondSavedSet=null;
			SET @secondProdSavedSet=null;
			SET @secondProdRepo=null;
			SET @secondProdRepoId=null;
			END
		drop table #tmpPromote;
	END
    if (@debug is not null) PRINT '191: done'
	SELECT @prodRepo as ProdRepo, @prodRepoId as ProdRepoId, @prodSavedSet as ProdSavedSet, @secondProdRepo as SecondProdRepo, @secondProdRepoId as SecondProdRepoId, @secondProdSavedSet as SecondProdSavedSet, @secondStageRepo as SecondStageRepo, @secondStageRepoId as SecondStageRepoId, @secondSavedSet as SecondSavedSet
END


go

