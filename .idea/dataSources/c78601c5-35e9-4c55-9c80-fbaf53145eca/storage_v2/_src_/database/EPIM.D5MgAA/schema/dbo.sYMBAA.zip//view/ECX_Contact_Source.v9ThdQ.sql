CREATE VIEW dbo.[ECX_Contact_Source] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005514 AS [Contact_Title], F_1005519 AS [Contact_Type], F_1005505 AS [Data_ID], F_1005528 AS [Data_Steward_Review_Is_Required], F_1005617 AS [del_load_date], F_1005616 AS [del_status], F_1005615 AS [del_target_date], F_1005614 AS [del_target_days], F_1005516 AS [Department], F_1005626 AS [Fax], F_1005506 AS [First_Name], F_1005518 AS [GUID], F_1005625 AS [Home_Phone_Number], F_1005526 AS [is_excluded], F_1005529 AS [Is_Inactive], F_1005527 AS [Is_Record_Logically_Deleted], F_1005530 AS [Is_Signed_Up_for_E_Billing], F_1005515 AS [Job_Function], F_1005508 AS [Last_Name], F_1005900 AS [Last_Update_Timestamp], F_1005507 AS [Middle_Name], F_1005511 AS [Mobile_Number], F_1005509 AS [Name_Suffix], F_1005624 AS [Personal_Email_Address], F_1005517 AS [Phone_Extension], F_1005523 AS [Practice_Area], F_1005630 AS [Salutation], F_1005521 AS [Source_System_Contact_ID], F_1005512 AS [Source_System_Customer_ID], F_1005513 AS [Source_System_Customer_Name], F_1005522 AS [Source_System_Name], F_1005520 AS [Work_Email_Address], F_1005510 AS [Work_Phone_Number] FROM dbo.B_SNAPSHOT_10317 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on ECX_Contact_Source to boomi
go

grant select on ECX_Contact_Source to informatica
go

grant select on ECX_Contact_Source to ecmxread
go

