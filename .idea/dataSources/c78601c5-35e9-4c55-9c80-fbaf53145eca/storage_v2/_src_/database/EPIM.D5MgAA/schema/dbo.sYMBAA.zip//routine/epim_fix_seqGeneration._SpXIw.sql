
create procedure   epim_fix_seqGeneration(
      @repositoryName nvarchar(255)
      )
As
BEGIN
    DECLARE @strSql NVARCHAR(max)
    DECLARE @repoId NVARCHAR(10)
    DECLARE @attrFName nvarchar(255)
    DECLARE @countOfMissing BIGINT
    DECLARE @iId BIGINT
    DECLARE @anItemId BIGINT
    DECLARE @anRecordState BIGINT
    DECLARE @tp_id INT
    DECLARE @nextId varchar(50)
    DECLARE @countUpdate BIGINT
	SET NOCOUNT ON;
	BEGIN TRY    
    
		print('Drop and recreate temp table FIX_DATA_TEMP_ITEMS');
		IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FIX_DATA_TEMP_ITEMS' AND type = 'U') DROP TABLE FIX_DATA_TEMP_ITEMS;
		CREATE TABLE FIX_DATA_TEMP_ITEMS (itemsId BIGINT IDENTITY(1,1) NOT NULL, item_id BIGINT, AttrValue NVARCHAR(max),RECORD_STATE BIGINT,PRIMARY KEY (itemsId));

		print('Get repo Id');
		SELECT @repoId = cast(master_repository_id as VARCHAR) from b_master_repository where name = @repositoryName;
		if (@repoId is null)  RAISERROR('Repository not found: %s', 16, 1, @repositoryName);

		print ('Get Seqs attr');
		SELECT @attrFName='F_' + CAST(B_FORMAT_ATTR.FORMAT_ATTR_ID as VARCHAR)
			FROM  B_MASTER_REPOSITORY INNER JOIN
				   B_PROFILE ON B_MASTER_REPOSITORY.PROFILE_ID = B_PROFILE.PROFILE_ID INNER JOIN
				   B_FORMAT_ATTR ON B_PROFILE.PROFILE_ID = B_FORMAT_ATTR.PROFILE_ID
				WHERE (B_FORMAT_ATTR.SEQ_GEN_IND = 1) AND (B_MASTER_REPOSITORY.MASTER_REPOSITORY_ID = @repoId)
		if (@attrFName is null)  RAISERROR('Sequence Attribute not found for repository: %s', 16, 1, @repositoryName);
				
		print('Get owning trading partner id');
		SELECT @tp_id = OWNER_TRADING_PARTNER_ID from b_master_repository where MASTER_REPOSITORY_ID = @repoId;
		if (@tp_id is null)  RAISERROR('Owning Trading Parnter not found: %s', 16, 1, @repositoryName);
		print('owning tp=' + cast(@tp_id as varchar));

		SET @strSql = 'INSERT INTO FIX_DATA_TEMP_ITEMS (item_id, record_state) 
							SELECT s.ITEM_ID, m.RECORD_STATE
							FROM  B_SNAPSHOT_' + @repoId + ' AS s INNER JOIN
								  B_MASTER_REPOSITORY_ITEM AS m ON s.ITEM_ID = m.ITEM_ID
							WHERE (s.' + @attrFName + ' IS NULL)';								   
		print('INSERT sql: ' + @strSql);
		EXECUTE (@strSql); 

		select @countOfMissing=COUNT(*) from FIX_DATA_TEMP_ITEMS;
	    print(CAST(@countOfMissing as varchar) + ' missing ids.');
	    	
		SET @iId = (SELECT MIN(itemsId) FROM  FIX_DATA_TEMP_ITEMS );
		SET @countUpdate=0;
		print('loop Min id from temp table is not null ');
		WHILE @iId is not null
		BEGIN
			SELECT @anItemId = item_id, @anRecordState = RECORD_STATE from FIX_DATA_TEMP_ITEMS where itemsId = @iId;
			if (@anRecordState is null) SET @anRecordState=1;
			if (@anRecordState =0) SET @anRecordState=2;
			EXEC epim_auto_sequence @gtin_value = @nextId OUTPUT, @tp_id = @tp_id
			--SET @nextId= @iId + @startingSequence;
			--print('@nextId=' + CAST(@nextId as varchar));
			SET @strSql = 'update b_master_repository_item set record_state = ' + CAST(@anRecordState as varchar) + ', attr_data.modify(''insert <' + @attrFName + '>' + CAST(@nextId as varchar) + '</' + @attrFName + '> as last into (/Item)[1]'') where item_id = ' + cast(@anItemId as nvarchar);        
			--print(@strSql)
			EXECUTE (@strSql); 
			SET @strSql = 'update B_SNAPSHOT_' + @repoId + ' set ' + @attrFName + '=' + CAST(@nextId as varchar) + ' where item_id = ' + cast(@anItemId as nvarchar);        
			--print(@strSql)
			EXECUTE (@strSql);
			SET @countUpdate=@countUpdate+1;
	        SET @nextId = null;
			SET @iId = (SELECT MIN(itemsId) FROM  FIX_DATA_TEMP_ITEMS WHERE  itemsId > @iId)
		END
		print('Updated:');
		print(@countUpdate);
		DROP TABLE FIX_DATA_TEMP_ITEMS;
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;	
END
go

