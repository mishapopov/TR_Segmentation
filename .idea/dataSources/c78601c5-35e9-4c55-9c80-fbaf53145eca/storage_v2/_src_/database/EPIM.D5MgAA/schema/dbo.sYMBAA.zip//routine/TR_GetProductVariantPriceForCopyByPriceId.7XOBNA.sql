
CREATE PROCEDURE [dbo].[TR_GetProductVariantPriceForCopyByPriceId]
    @itemIds VARCHAR(200),  -- Delimited list of source product variant price IDs
    @savedSetId int, -- saved set ID of source product variant price
    @source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
    @target VARCHAR(10)	-- Name of target (Clone, Change, State)
AS BEGIN

    -- TR_GetProductVariantPriceForCopy - Retrieves the source and target Product Variant Price records
    -- for the specified list of Product Variant Item IDs or the saved set from the designated source repository
    -- to be copied to the designated target repository.  Returns the internal record Id of each
    -- source Product Variant Price record along with the Internal Record Id of the corresponding
    -- target Product Variant Price record (or null if it doesn't exist).  Not to be used for cloning
    -- as cloning will need new IDs for all cloned records.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_GetProductVariantPriceForCopyByPriceId '6318181,6318166,6318164',null,'Change','Staging'
    --
    --  EXEC TR_GetProductVariantPriceForCopyByPriceId null,10548,'Staging','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductVariantPriceForCopyByPriceId '%itemIds%',%savedSetId%,'Staging','Change'

    DECLARE @sql VARCHAR(max)

    -- Determine if saved set was specified

    IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds
            SET @sql = 'select spvp.InternalRecordId as source, tpvp.InternalRecordId as target ' +
                       'FROM PRODUCT_VARIANT_PRICE_' + @source + ' spvp ' +
                       'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_' + @target + ' tpvp ON tpvp.Product_Price_ID = spvp.Product_Price_ID ' +
                       'WHERE spvp.InternalRecordId in (' + @itemIds + ')'
        END
    ELSE
        BEGIN
            -- Code set - use it
            SET @sql = 'select spvp.InternalRecordId as source, tpvp.InternalRecordId as target ' +
                       'FROM PRODUCT_VARIANT_PRICE_' + @source + ' spvp ' +
                       'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spvp.InternalRecordId ' +
                       'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_' + @target + ' tpvp ON tpvp.Product_Price_ID = spvp.Product_Price_ID ' +
                       'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR)
        END

    print @sql
    EXECUTE (@sql)

END
go

