
create procedure epim_add_snapshot_update_col (
      @useTabName int,
      @useRestrictedNames int	  )
As
BEGIN
	DECLARE @rc int
	DECLARE @colExists int
    DECLARE @sql NVARCHAR(max)
    DECLARE @snapSql NVARCHAR(max)
    DECLARE @repositoryId bigint
	DECLARE @tabName nvarchar(255)
	DECLARE @repoName nvarchar(255)
	DECLARE @viewName nvarchar(255)
	DECLARE @params nvarchar(100)
    	        
	BEGIN tran

	EXEC @rc = sp_getapplock @Resource='myLock', @LockMode='EXCLUSIVE', @LockOwner='TRANSACTION', @LockTimeout=15000
	if (@rc = 0)
	begin
		-- Get the repository IDs
		print('got lock')
   
		DECLARE repoCursor CURSOR FOR 
		SELECT mr.master_repository_id, mr.tab_name, mr.name FROM b_master_repository mr
		ORDER BY master_repository_id
    
		OPEN repoCursor
		FETCH NEXT FROM repoCursor INTO @repositoryId, @tabName, @repoName

		WHILE @@FETCH_STATUS = 0
		BEGIN
              
			-- see if column exists
			set @sql = 'IF NOT EXISTS (select * from Information_SCHEMA.columns where Table_name=''B_SNAPSHOT_' 
						+ cast(@repositoryId as varchar) 
						+ ''' and COLUMN_NAME=''DATA_LAST_UPDATE_DATETIME'') select @colExists=0 ELSE select @colExists=1';
			set @params = '@colExists int output';
			exec sp_executesql @sql,  @params, @colExists output;

			if (@colExists = 0)
			BEGIN
			  begin try
				-- Add a column to the snapshot table
				SET @snapSql = ' ALTER TABLE B_SNAPSHOT_' + cast(@repositoryId as varchar) 
								+ ' ADD DATA_LAST_UPDATE_DATETIME DATETIME NULL';
				print ('snapSql = ' + @snapSql);
				EXECUTE (@snapSql); 
			  end try
			  begin catch
				print ('alter table B_snapshot error = ');
			  end catch
			END

			-- see if friendly view snapshot_last_updated column exists
			SET @viewName = @tabName;
			if (@useTabName = 1) SET @viewName=@repoName
			set @sql = 'IF NOT EXISTS (select * from Information_SCHEMA.columns where Table_name=''' + @viewName
						+ ''' and COLUMN_NAME=''Snapshot_LAST_UPDATED'') select @colExists=0 ELSE select @colExists=1';
			set @params = '@colExists int output';
			exec sp_executesql @sql,  @params, @colExists output;

			if (@colExists = 0)
			BEGIN
			  begin try
				print ('friendlyView: viewName = ' + @viewName + ' repoName = ' + @repoName + ' useRestrictedNames = ' + cast(@useRestrictedNames as varchar));
				EXEC epim_create_friendly_view @viewName, @repoName, @useRestrictedNames
			  end try
			  begin catch
			    print ('friendlyView alter error');
			  end catch
			END
		
			FETCH NEXT FROM repoCursor INTO @repositoryId, @tabName, @repoName            
		END
    END

    CLOSE repoCursor
    DEALLOCATE repoCursor
    
	COMMIT

END;
go

