CREATE TRIGGER epim_ad_btransmissionOption ON B_TRANSMISSION_OPTION
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = transmission_option_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BtransmissionOption', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BtransmissionOption', @obj_id;
    END
go

