
 CREATE PROCEDURE [dbo].[TR_GetTargetDate]
  	@internalRecordId int  -- Internal Record ID of Change Request
 AS BEGIN
    -- Anthony - DEPRECATED By 20191209 Changes

        -- TR_GetTargetDate - Checks the pricing for the Product Variants in a Change Request
        -- for any changes.  Returns true if changes were found.

    select distinct b.InternalRecordId as InternalId_staging, a.InternalRecordId as InternalId_change, FORMAT(DATEADD(day, -1, a.Price_Start_Date),'dd-MMM-yyyy') AS Target_Date
    from (SELECT pvp.Product_Variant_ID,pvp.Price_Type,pvp.Customer_Type,pvp.Price_of_Incremental_User,pvp.Service_Type,pvp.Multi_Year_Eligible,pvp.Price_Type_Term,
    pvp.Currency,pvp.Price_Tier_Units,pvpt.Price_Tier_Minimum,pvpt.Price_Tier_Maximum,pvp.Price_Start_Date,pvp.Price_End_Date,pvp.InternalRecordId
    from Request_Change r
    join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_Id
    join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
    join PRODUCT_VARIANT_PRICE_Change pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID
    left join PRODUCT_VARIANT_PRICE_TIER_Change pvpt on pvp.Product_Price_ID =pvpt.Product_Price_ID
    where pvp.InternalRecordId =@internalRecordId ) a left join (SELECT pvp.Product_Variant_ID,pvp.Price_Type,pvp.Customer_Type,pvp.Price_of_Incremental_User,pvp.Service_Type,pvp.Multi_Year_Eligible,pvp.Price_Type_Term,
    pvp.Currency,pvp.Price_Tier_Units,pvpt.Price_Tier_Minimum,pvpt.Price_Tier_Maximum,pvp.Price_Start_Date,pvp.Price_End_Date,pvp.InternalRecordId
    from
    PRODUCT_VARIANT_Staging pv
    join PRODUCT_VARIANT_PRICE_Staging pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID
    left join PRODUCT_VARIANT_PRICE_TIER_Staging pvpt on pvp.Product_Price_ID =pvpt.Product_Price_ID ) b
    on ISNULL(a.Product_Variant_ID, 0)=ISNULL(b.Product_Variant_ID, 0)
    and ISNULL(a.Price_Type, 0)=ISNULL(b.Price_Type, 0)
    and ISNULL(a.Customer_Type, 0)=ISNULL(b.Customer_Type, 0)
    and ISNULL(a.Price_of_Incremental_User, 0)=ISNULL(b.Price_of_Incremental_User, 0)
    and ISNULL(a.Service_Type, 0)=ISNULL(b.Service_Type, 0)
    and ISNULL(a.Multi_Year_Eligible, 0)=ISNULL(b.Multi_Year_Eligible, 0)
    and ISNULL(a.Price_Type_Term, 0)=ISNULL(b.Price_Type_Term, 0)
    and ISNULL(a.Currency, 0)=ISNULL(b.Currency, 0)
    and ISNULL(a.Price_Tier_Units, 0)=ISNULL(b.Price_Tier_Units, 0)
    --and ISNULL(a.Price_Tier_Minimum, 0)=ISNULL(b.Price_Tier_Minimum, 0)
    --and ISNULL(a.Price_Tier_Maximum, 0)=ISNULL(b.Price_Tier_Maximum, 0)
    where
    b.Product_Variant_ID is not null and a.Price_Start_Date!=b.Price_Start_Date and
    ((a.Price_Start_Date between b.Price_Start_Date and b.Price_End_Date) or
    (a.Price_End_Date between b.Price_Start_Date and b.Price_End_Date) or (a.Price_Start_Date < b.Price_Start_Date and a.Price_End_Date > b.Price_End_Date) or
    (a.Price_Start_Date > b.Price_Start_Date and a.Price_End_Date < b.Price_End_Date) )
    and a.Price_Start_Date>b.Price_Start_Date
    and a.InternalRecordId!= b.InternalRecordId

END
 go

