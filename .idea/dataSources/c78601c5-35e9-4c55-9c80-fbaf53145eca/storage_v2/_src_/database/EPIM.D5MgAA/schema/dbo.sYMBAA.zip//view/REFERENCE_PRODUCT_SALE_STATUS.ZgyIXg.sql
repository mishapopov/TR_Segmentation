CREATE VIEW dbo.[REFERENCE_PRODUCT_SALE_STATUS] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004468 AS [EPM_Reference_Code], F_1004469 AS [System_Name], F_1004470 AS [Value] FROM dbo.B_SNAPSHOT_10172 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to dbadmin
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to ewsys
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to boomi
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to informatica
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to som
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to apttus
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to epmdev
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to MDMAdmin
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to produser1
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to produser3
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to produser2
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to VIEW_ACCESS
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to integration_team
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to ecmxread
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to MPOPOV_TEST
go

grant select on REFERENCE_PRODUCT_SALE_STATUS to digital
go

