
CREATE FUNCTION [dbo].[LTrimX](@str nVARCHAR(MAX)) RETURNS nVARCHAR(MAX)
AS
BEGIN
DECLARE @trimchars nVARCHAR(10)
SET @trimchars = CHAR(9)+CHAR(10)+CHAR(13)+CHAR(32)
IF @str LIKE '[' + @trimchars + ']%' SET @str = SUBSTRING(@str, PATINDEX('%[^' + @trimchars + ']%', @str), 8000)
RETURN @str
END
go

