create view [dbo].[EPIM_REP_SV10103] as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1003512)') as nvarchar(MAX))  as F_1003512,  CAST(attr_data.query('data(Item/F_1003513)') as varchar(MAX))  as F_1003513,  CAST(attr_data.query('data(Item/F_1003514)') as nvarchar(MAX))  as F_1003514,  CAST(attr_data.query('data(Item/F_1003515)') as nvarchar(MAX))  as F_1003515,  CAST(attr_data.query('data(Item/F_1003516)') as nvarchar(MAX))  as F_1003516,  CAST(attr_data.query('data(Item/F_1003517)') as varchar(MAX))  as F_1003517,  CAST(attr_data.query('data(Item/F_1003518)') as nvarchar(MAX))  as F_1003518 from b_master_repository_item bmri where bmri.repository_id = 10103

go

grant select on EPIM_REP_SV10103 to boomi
go

