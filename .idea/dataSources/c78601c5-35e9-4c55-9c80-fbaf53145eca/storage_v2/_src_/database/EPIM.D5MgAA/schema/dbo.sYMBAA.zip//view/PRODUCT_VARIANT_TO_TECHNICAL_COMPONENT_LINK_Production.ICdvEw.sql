CREATE VIEW dbo.[PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004527 AS [Product_Variant_ID], F_1004598 AS [Product_Variant_To_Technical_Component_Link_ID], F_1004528 AS [Technical_Component_ID], F_1004529 AS [Technical_Component_Type] FROM dbo.B_SNAPSHOT_10164 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to dbadmin
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to ewsys
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to boomi
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to informatica
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to som
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to apttus
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to epmdev
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to MDMAdmin
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to produser1
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to produser3
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to produser2
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to VIEW_ACCESS
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to integration_team
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to ecmxread
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to MPOPOV_TEST
go

grant select on PRODUCT_VARIANT_TO_TECHNICAL_COMPONENT_LINK_Production to digital
go

