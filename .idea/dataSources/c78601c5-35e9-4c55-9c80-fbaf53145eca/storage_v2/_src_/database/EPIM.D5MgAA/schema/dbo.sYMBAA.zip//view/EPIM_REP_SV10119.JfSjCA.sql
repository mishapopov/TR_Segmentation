create view [dbo].[EPIM_REP_SV10119] as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1004285)') as varchar(MAX))  as F_1004285,  CAST(attr_data.query('data(Item/F_1004286)') as varchar(MAX))  as F_1004286 from b_master_repository_item bmri where bmri.repository_id = 10119

go

grant select on EPIM_REP_SV10119 to boomi
go

