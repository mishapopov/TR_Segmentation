
  CREATE PROCEDURE [dbo].DeleteWorkItemFromEnable(
	@workItemId BIGINT,
	@internalRecordId BIGINT,
	@epxDbName VARCHAR(100)
  )
    AS BEGIN
    
        -- DeleteWorkItemFromEnable - deletes the designated work item from the designated Enable workflow tables. 

		-- Parameters:
		--
		-- workItemId - work item ID
		-- internalRecordId - internal record ID of the repository record on which the work item is anchored.
		-- epxDbName - name of the EPX database

        --
        -- Example SQL: 
        --
        --  EXEC DeleteWorkItemFromEnable 589894,10505221,'EPX'
        --

	DECLARE @results VARCHAR(max);
	DECLARE @sql NVARCHAR(max);
	DECLARE @numRows INTEGER;
	
	BEGIN TRAN
	
	-- Delete the Enable work item version item records
	delete from b_work_item_version_item where WORK_ITEM_VERSION_ID in 
		(select WORK_ITEM_VERSION_ID from b_work_item_version where WORK_ITEM_ID = @workItemId)
	
	set @results='Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Item Version Items;  ';

	-- Delete the Enable work item version records
	delete from b_work_item_version where WORK_ITEM_ID = @workItemId
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Item Versions;  ';
	
	-- Delete the Enable work item records
	delete from b_work_item where WORK_ITEM_ID = @workItemId
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Items;  ';
	
	-- Delete the work item version lineage
	
	set @sql = 'delete from ' + @epxDbName + '.dbo.P_VERSION_LINEAGE where PARENT_VERSION_ID in ' + 
		'(select WORK_VERSION_ID from ' + @epxDbName + '.dbo.P_WORK_ITEM_VERSION where WORK_ITEM_ID = ' +
		cast(@workItemId as VARCHAR) + ')';
	exec (@sql);
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' EPX Work Item Version Lineages;  ';
	
	-- Delete the work item properties
	set @sql = 'delete from ' + @epxDbName + '.dbo.P_WORK_ITEM_PROPERTY where WORK_VERSION_ID in ' +
		'(select WORK_VERSION_ID from ' + @epxDbName + '.dbo.P_WORK_ITEM_VERSION where WORK_ITEM_ID = ' +
		cast(@workItemId as VARCHAR) + ')';
	exec (@sql);
		
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Item Properties;  ';
	
	-- Delete the work item versions
	set @sql = 'delete from ' + @epxDbName + '.dbo.P_WORK_ITEM_VERSION where WORK_ITEM_ID = ' + 
		cast(@workItemId as VARCHAR);
	exec (@sql);
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Item Versions;  ';
	

	-- Delete the work item
	set @sql='delete from ' + @epxDbName + '.dbo.P_WORK_ITEM where WORK_ITEM_ID = ' + cast(@workItemId as VARCHAR)
	exec (@sql);
	set @results=@results + 'Deleted ' + CAST(@@ROWCOUNT as VARCHAR) + ' Enable Work Items;  ';

	-- Clear lock on item record if it's not in other workflows

	set @sql = 'select @numRows=count( wip2.PROPERTY_VALUE) ' +
		'from epx.dbo.P_WORK_ITEM_VERSION wiv ' +
		'join ' + @epxDbName + '.dbo.P_WORK_ITEM wi on wi.WORK_ITEM_ID = wiv.WORK_ITEM_ID ' +
		'join ' + @epxDbName + '.dbo.P_WORK_ITEM_PROPERTY wip2 on wiv.WORK_VERSION_ID = wip2.WORK_VERSION_ID ' +
		'and wip2.PROPERTY_KEY = ''itemIds'' ' +
		'where wiv.CURRENT_IND = 1 ' +
		'and wiv.DELETED_IND = 0 ' +
		'and wiv.STATUS_CODE <> 4 ' +
		'and wip2.PROPERTY_VALUE = ''' + cast(@internalRecordId as VARCHAR) + '''';
	print @sql
	exec sp_executesql @sql, N'@numRows int out', @numRows out
	if @numRows = 0
	BEGIN
		update B_MASTER_REPOSITORY_ITEM set WORKFLOW_STATE = 0 where ITEM_ID = @internalRecordId
		set @results=@results + 'Cleared workflow lock on  ' + CAST(@@ROWCOUNT as VARCHAR) + ' Repository records;  ';
	END

	COMMIT TRAN
	
	select @results as Results
END
  go

