CREATE TRIGGER epim_ad_bstyleMap ON B_STYLE_MAP
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = style_map_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BstyleMap', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BstyleMap', @obj_id;
    END
go

