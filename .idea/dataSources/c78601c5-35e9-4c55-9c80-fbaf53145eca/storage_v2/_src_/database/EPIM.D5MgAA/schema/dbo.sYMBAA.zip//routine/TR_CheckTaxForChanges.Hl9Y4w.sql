
CREATE PROCEDURE [dbo].[TR_CheckTaxForChanges]
@internalRecordId int  -- Internal Record ID of Change Request

AS BEGIN

    -- TR_CheckTaxForChanges - Checks the tax for the Product Variants in a Change Request
    -- for any changes.  Returns true if changes were found.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_CheckTaxForChanges 5714408
    --
    -- Workflow Activity:
    --
    -- EXEC TR_CheckTaxForChanges %itemIds%


    -- Check if any tax has changed.  If new tax is added, it will appear as a change


    -- TR_CheckTaxForChanges - Checks the tax for the Product Variants in a Change Request
    -- for any changes.  Returns true if changes were found.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_CheckTaxForChanges 5714408
    --
    -- Workflow Activity:
    --
    -- EXEC TR_CheckTaxForChanges %itemIds%


    -- Check if any tax has changed.  If new tax is added, it will appear as a change


    select case when changedRowCount > 0 then 'true' else 'false' end as hasTaxChanges
    from (
             select sum(changedRows) as changedRowCount
             from (
                      -- update tax record in change
                      select count(*) as changedRows
                      from Request_Change r
                               join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
                               join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
                               join PRODUCT_VARIANT_TAX_Change pvt on pv.Product_Variant_ID = pvt.Product_Variant_ID
                               join PRODUCT_VARIANT_TAX_Staging spvt on pvt.Product_Tax_ID = spvt.Product_Tax_ID
                      where (
                                  isnull(pvt.Product_Tax_Category, '') <> isnull(spvt.Product_Tax_Category, '')
                              or isnull(pvt.Product_Tax_Classification, '') <> isnull(spvt.Product_Tax_Classification, '')
                              or isnull(pvt.Country_Code, '') <> isnull(spvt.Country_Code, '')
                              or isnull(pvt.US_Tax_Product_Code, '') <> isnull(spvt.US_Tax_Product_Code, '')
                              or isnull(pvt.Canada_Tax_Product_Code, '') <> isnull(spvt.Canada_Tax_Product_Code, '')
                              or isnull(pvt.Brazil_Tax_Control_Code, '') <> isnull(spvt.Brazil_Tax_Control_Code, '')
                              or isnull(pvt.India_Tax_HSN_Code, '') <> isnull(spvt.India_Tax_HSN_Code, '')
                              or isnull(pvt.Product_Variant_ID,0) <> isnull(spvt.Product_Variant_ID,0)
                              or isnull(pvt.Status_Code,'') <> isnull(spvt.Status_Code,'')
                          )
                        and r.InternalRecordId = @internalRecordId
                      union
                      -- add tax record in change
                      select count(*)
                      from Request_Change r
                               join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
                               join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
                               join PRODUCT_VARIANT_TAX_Change pvt on pv.Product_Variant_ID = pvt.Product_Variant_ID
                               left join PRODUCT_VARIANT_TAX_Staging spvt on pvt.Product_Tax_ID = spvt.Product_Tax_ID
                      where spvt.InternalRecordId is null
                        and r.InternalRecordId = @internalRecordId
                      union
                      -- delete tax record in change
                      select count(*)
                      from Request_Change r
                               join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
                               join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
                               join PRODUCT_VARIANT_TAX_Staging spvt on spvt.Product_Variant_ID = pv.Product_Variant_ID
                               left join PRODUCT_VARIANT_TAX_Change pvt on pvt.Product_Tax_ID = spvt.Product_Tax_ID
                      where pvt.InternalRecordId is null
                        and r.InternalRecordId = @internalRecordId
                  ) v
         ) b

END
go

