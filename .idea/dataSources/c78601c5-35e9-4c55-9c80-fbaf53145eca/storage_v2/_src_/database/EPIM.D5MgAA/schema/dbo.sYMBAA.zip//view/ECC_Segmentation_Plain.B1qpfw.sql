Create   view ECC_Segmentation_Plain as
select code, DESCRIPTION, 1 as level
from TR_Hierarchy_metadata
where name = 'ECC_Hierarchy'
  and isnull(PARENT_CODE, '') = ''
union all
select code, DESCRIPTION, 2 as level
from TR_Hierarchy_metadata
where name = 'ECC_Hierarchy'
  and PARENT_CODE like 'L1_%'
union all
select code, DESCRIPTION, 3 as level
from TR_Hierarchy_metadata
where name = 'ECC_Hierarchy'
  and PARENT_CODE like 'L2_%'
go

