
create procedure epim_convert_code_set_all_language 
As
BEGIN
   declare @startId bigint;
   
	SET @startId = (select min(code_Set_detail_ID) from b_code_Set_detail 
	                where DESCRIPTION_LANGUAGES is not null and all_languages is null);
	WHILE @startId is not null
	begin
		BEGIN TRANSACTION
			update b_code_Set_detail set all_languages = ('<Desc>'+ DESCRIPTION_LANGUAGES + '</Desc>')
			where code_Set_detail_ID >= @startId and code_Set_detail_ID < (@startId+20000)
		COMMIT;
		SET @startId = (SELECT MIN(code_Set_detail_ID) FROM  b_code_Set_detail 
				                WHERE DESCRIPTION_LANGUAGES is not null and all_languages is null and
								code_Set_detail_id >= (@startId + 20000));
	end

END;

go

