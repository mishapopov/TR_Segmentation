
CREATE PROCEDURE [dbo].[GetPublicationTableAttributesForTaxonomyNode] 
   @repositoryName VARCHAR(255),
   @publicationTemplate VARCHAR(255),
   @taxonomyNode VARCHAR(255)
AS
BEGIN

    DECLARE @formula VARCHAR(512)
    CREATE TABLE #Attributes ( attributeName nvarchar(200))


    -- Generate SQL using designated property name for attribute names
    DECLARE attributeCursor CURSOR FOR 

    select pmd.ELEMENT_FORMULA
    from B_PUB_MAPPING_DETAIL pmd
    join B_PUB_CONTEXT_MAPPING pcm on pcm.PUB_CONTEXT_MAPPING_ID = pmd.PUB_CONTEXT_MAPPING_ID
    join B_PUB_CONTEXT pc on pc.PUB_CONTEXT_ID = pcm.PUB_CONTEXT_ID
    join B_PUB_CONTEXT_MAP_REP pcmr on pcmr.PUB_CONTEXT_ID = pcm.PUB_CONTEXT_ID
    join B_DESIGN_ELEMENT de on de.DESIGN_ELEMENT_ID = pmd.DESIGN_ELEMENT_ID and de.STYLE_MAP_ID = pcm.STYLE_MAP_ID
    where de.ELEMENT_NAME like 'T%' AND NOT SUBSTRING(de.element_Name, 2, LEN(de.ELEMENT_NAME)-1) like '%[^0-9]%'
    and pmd.ELEMENT_FORMULA like '${' + @repositoryName + '.%'
    and pc.NAME = @publicationTemplate
    and pcm.CODE_SET_NODE_VALUE like @taxonomyNode
    
    OPEN attributeCursor

    FETCH NEXT FROM attributeCursor 
    INTO @formula

    WHILE @@FETCH_STATUS = 0
    BEGIN
                                    
        -- Parse the formula and extract the Attribute names

        DECLARE @position int
        DECLARE @startPosition int
        DECLARE @attributePosition int
        DECLARE @endPosition int
        DECLARE @attributeName VARCHAR(255)
        SET @position = 1
        print @formula
        WHILE charindex('${' + @repositoryName + '.',@formula,@position) <> 0
        BEGIN
            -- Found the beginning of a desired reference - find the end and extract the attribute ID/name
            SET @startPosition = charindex('${' + @repositoryName + '.', @formula, @position)
            SET @endPosition = charIndex('}', @formula, @startPosition)
            SET @attributePosition = @startPosition + LEN('${' + @repositoryName + '.')
            SET @attributeName = SUBSTRING(@formula, @attributePosition, @endPosition - @attributePosition)
            print @attributeName
            
            -- Attribute reference should be an F_ number but could be an actual attribute name (with escaped characters)
            if charindex('F_', @attributeName) = 1
            BEGIN
                -- Get the actual attribute name for the F_ #
                select @attributeName=name from B_FORMAT_ATTR WHERE FORMAT_ATTR_ID = cast(RIGHT(@attributeName, len(@attributeName)-2) as bigint)
            END
            ELSE
            BEGIN
                -- Unescape the attribute name
                SET @attributeName = REPLACE(@attributeName, '\','')
            END
            print @attributeName
            
            -- Save the attribute name
            INSERT INTO #Attributes VALUES(@attributeName)
            
            -- Prepare check for more mappings in the current formula
            SET @position = @endPosition
        END
        
        -- Get next formula
        
        FETCH NEXT FROM attributeCursor 
        INTO @formula
            
    END

    CLOSE attributeCursor
    DEALLOCATE attributeCursor
    -- Return attribute names found
    SELECT DISTINCT * from #Attributes
    
    -- Cleaup
    DROP TABLE #Attributes
END
go

