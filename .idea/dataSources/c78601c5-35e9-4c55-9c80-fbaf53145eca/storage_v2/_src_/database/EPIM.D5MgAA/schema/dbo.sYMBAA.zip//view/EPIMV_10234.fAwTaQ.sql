create view EPIMV_10234 as select ID, PLT_10236."F_12498" as F_1004524, PLT_10236."F_1" as F_1004523 from PLT_10236
go

