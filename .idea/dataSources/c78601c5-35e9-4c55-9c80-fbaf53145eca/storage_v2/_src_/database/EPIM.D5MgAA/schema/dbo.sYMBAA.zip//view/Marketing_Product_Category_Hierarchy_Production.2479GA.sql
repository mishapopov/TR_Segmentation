CREATE VIEW dbo.[Marketing_Product_Category_Hierarchy_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1000425 AS [Hierarchy_Name], F_1000426 AS [Id], F_1005241 AS [Is_Primary], F_1000994 AS [LinkRelationshipPath], F_1000427 AS [NodeValue], F_1000995 AS [ParentID], F_1000428 AS [Product_Id], F_1000429 AS [SequenceNum], F_1000430 AS [Status] FROM dbo.B_SNAPSHOT_10296 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on Marketing_Product_Category_Hierarchy_Production to dbadmin
go

grant select on Marketing_Product_Category_Hierarchy_Production to boomi
go

grant select on Marketing_Product_Category_Hierarchy_Production to informatica
go

grant select on Marketing_Product_Category_Hierarchy_Production to som
go

grant select on Marketing_Product_Category_Hierarchy_Production to apttus
go

grant select on Marketing_Product_Category_Hierarchy_Production to epmdev
go

grant select on Marketing_Product_Category_Hierarchy_Production to MDMAdmin
go

grant select on Marketing_Product_Category_Hierarchy_Production to produser1
go

grant select on Marketing_Product_Category_Hierarchy_Production to produser3
go

grant select on Marketing_Product_Category_Hierarchy_Production to produser2
go

grant select on Marketing_Product_Category_Hierarchy_Production to digital
go

