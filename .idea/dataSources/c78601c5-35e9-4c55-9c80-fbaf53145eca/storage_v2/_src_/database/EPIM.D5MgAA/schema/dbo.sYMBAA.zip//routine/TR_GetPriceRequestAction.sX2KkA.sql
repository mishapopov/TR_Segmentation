
CREATE PROCEDURE [dbo].[TR_GetPriceRequestAction]
    @priceRequestId VARCHAR(200), -- Internal Record ID of the Request
    @source VARCHAR(10) -- Name of source (Build, Clone, Change, State)
AS
BEGIN
    -- TR_GetPriceRequestAction - Get the price request action based on the logic below.
    --
    -- Check if the price is a new record based on header data. If no match is found in staging, then the price action is new
    -- Check if the price if a merge based on header data and start date. If a match is found in staging and the end date differs then the price action is update.
    -- Check if the price if a merge based on header data and start date. If a match is found in staging and the end date is the same then the price action is none.
    -- If a match is found on header attributes but no matching start date then this is a price change
    --
    -- * For price change, the workflow will need to update the existing price records with a new end date and create the new active record
    -- * If there is a calculation error (missing request record), then the price action is error
    -- * For pricing, the only update allowed is to the price end date
    --
    -- Header attributes: Product Variant ID, Price Type, Price Type Term, Currency, Price Tier Units, Customer Type, Service Type
    --
    -- Example SQL:
    --
    -- EXEC TR_GetPriceRequestAction '6318181','Change'
    -- EXEC TR_GetPriceRequestAction '6318166','Change'
    -- EXEC TR_GetPriceRequestAction '6318164','Change'
    -- EXEC TR_GetPriceRequestAction '1234567','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetPriceRequestAction '%itemIds%','%source%'
    --
    -- Returns
    -- priceAction: new, update, priceChange, error
    -- priceStagingIds: single record for update or list for priceChange
    -- priceEndDate: current price end date for update or start date - 1 for priceChange

    DECLARE @priceAction VARCHAR(20), -- action to return
        @priceEndDate datetime, -- current end date for update or end date - 1 for priceChange
        @priceStagingIds nvarchar(max), -- staging ID for update or IDs for priceChange
        @sql NVARCHAR(max),
        @isNewRequest int = -1,
        @isDateMatch int = -1,
        @priceStartDate datetime,
        @sqlHeader NVARCHAR(MAX)

    set @sqlHeader = '' +
                     'and isnull(pvps.Price_Type,'''') = isnull(pvp.Price_Type,'''')
                      and isnull(pvps.Price_Type_Term,'''') = isnull(pvp.Price_Type_Term,'''')
                      and isnull(pvps.Currency,'''') = isnull(pvp.Currency,'''')
                      and isnull(pvps.Price_Tier_Units,'''') = isnull(pvp.Price_Tier_Units,'''')
                      and isnull(pvps.Customer_Type,'''') = isnull(pvp.Customer_Type,'''')
                      and isnull(pvps.Service_Type,'''') = isnull(pvp.Service_Type,'''') '
    -----------------------------------------------------------------------------
    -- Check if the price request already exists in pricing staging
    -- if it already exists then see if there is a matching record by start date
    -----------------------------------------------------------------------------

    set @sql = '
select top 1 @isNewPriceRecord = case when pvps.InternalRecordId is null then 1 else 0 end
    , @priceEndDate = pvp.Price_End_Date
	, @priceStartDate = pvp.Price_Start_Date
from PRODUCT_VARIANT_PRICE_' + @source + ' pvp
left join PRODUCT_VARIANT_PRICE_Staging pvps ON pvps.Product_Variant_ID = pvp.Product_Variant_ID ' +
               '' + @sqlHeader +
               'where pvp.InternalRecordId = ' + @priceRequestId;

    print 'checkForNewRecordSql - ' + @sql;

    -- Catch errors in case repo does not exist
    BEGIN TRY
        exec sp_executesql @sql, N'@isNewPriceRecord int out,@priceEndDate datetime out,@priceStartDate datetime out', @isNewRequest out, @priceEndDate out, @priceStartDate out
    END TRY
    BEGIN CATCH
        set @priceAction = 'error';
    END CATCH

    if @isNewRequest = -1
        -- record does not exist in request source
        set @priceAction = 'none'
    else if @isNewRequest = 1
        -- no match by header row so new price record
        set @priceAction = 'new'
    else
        -- determine if update or price change
        begin

            -- at least one matching row was found on header attributes
            -- now check for same start date and different end date
            set @sql = '
select top 1 @priceStagingId = cast(pvps.InternalRecordId as nvarchar(max))
	, @sameEndDate = case when pvp.Price_End_Date = pvps.Price_End_Date then 1 else 0 end
from PRODUCT_VARIANT_PRICE_' + @source + ' pvp
inner join PRODUCT_VARIANT_PRICE_Staging pvps ON pvps.Product_Variant_ID = pvp.Product_Variant_ID ' +
                       '' + @sqlHeader +
                       'and pvps.Price_Start_Date = pvp.Price_Start_Date
                   where pvp.InternalRecordId = ' + @priceRequestId;

            print 'checkForUpdateRecordSql - ' + @sql;

            -- Catch errors in case repo does not exist
            BEGIN TRY
                exec sp_executesql @sql, N'@priceStagingId nvarchar(max) out,@sameEndDate int out', @priceStagingIds out, @isDateMatch out
            END TRY
            BEGIN CATCH
                set @priceAction = 'error';
            END CATCH

            -- determine the final action for match by header attributes
            -- start and end date match then do nothing
            -- start date match but not end date then update
            -- no matching start date then pricechange
            select @priceAction = case
                                      when @isDateMatch = 1 then 'none'
                                      when isnull(@priceStagingIds,'') <> '' then 'update'
                                      else 'priceChange'
                end

            if @priceAction = 'priceChange'
                begin
                    set @priceEndDate = dateadd(dd,-1,@priceStartDate)

                    -- get a comma delimited list of price staging ids to update with a new end date
                    -- criteria is to match on header attributes for staging record
                    -- and prestaging price start date - 1 < staging price end date
                    set @sql = '
select @priceChangeIds=stuff((
    select '','' + cast(pvps.InternalRecordId as nvarchar(50))
    from PRODUCT_VARIANT_PRICE_' + @source + ' pvp
    inner join PRODUCT_VARIANT_PRICE_Staging pvps ON pvps.Product_Variant_ID = pvp.Product_Variant_ID ' +
                               '' + @sqlHeader +
                               'and dateadd(dd,-1,pvp.Price_Start_Date) < pvps.Price_End_Date
                           where pvp.InternalRecordId = ' + @priceRequestId + '
    ),1,1,'''')'

                    print 'checkForPriceChangeIdsSql - ' + @sql

                    BEGIN TRY
                        exec sp_executesql @sql, N'@priceChangeIds nvarchar(max) out', @priceStagingIds out
                    END TRY
                    BEGIN CATCH
                        set @priceAction = 'error';
                    END CATCH

                end
        end

    -- can get a null if the price request id does not exist
    select @priceAction as priceAction, @priceStagingIds as priceStagingIds, format(@priceEndDate,'dd-MMM-yyyy') as priceEndDate

END
go

