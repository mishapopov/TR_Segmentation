CREATE VIEW dbo.[PERSON_ROLE_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004740 AS [Acquired_Company], F_1004741 AS [Address_1], F_1004742 AS [Address_2], F_1004743 AS [Address_3], F_1004744 AS [Alternate_Address_1], F_1004745 AS [Alternate_Address_2], F_1004746 AS [Alternate_Address_3], F_1004747 AS [Alternate_City], F_1004748 AS [Alternate_Country_Name], F_1004749 AS [Alternate_Employee_ID_Type], F_1004750 AS [Alternate_ID], F_1004751 AS [Alternate_Postal_Code], F_1004752 AS [Alternate_State_Name], F_1004753 AS [Approval_Amount], F_1004754 AS [Birth_Date], F_1004755 AS [Business_Partner], F_1004756 AS [Business_Unit_Code], F_1004757 AS [Business_Unit_Description], F_1004758 AS [Business_Unit_Level_2], F_1004759 AS [Business_Unit_Level_2_Description], F_1004760 AS [Business_Unit_Level_3], F_1004761 AS [Business_Unit_Level_3_Description], F_1004762 AS [Business_Unit_Level_4], F_1004763 AS [Business_Unit_Level_4_Description], F_1004764 AS [Business_Unit_Level_5], F_1004765 AS [Business_Unit_Level_5_Description], F_1004766 AS [Business_Unit_Level_6], F_1004767 AS [Business_Unit_Level_6_Description], F_1004768 AS [Business_Unit_Level_7], F_1004769 AS [Business_Unit_Level_7_Description], F_1004770 AS [City], F_1004771 AS [Company], F_1004772 AS [Company_Code], F_1004773 AS [Company_Description], F_1004774 AS [Company_Short_Description_Override], F_1004775 AS [Cost_Center], F_1004776 AS [Country_Code], F_1004777 AS [Country_Name], F_1004778 AS [Date_Rescinded], F_1004779 AS [Department_Description], F_1004780 AS [Department_ID], F_1004781 AS [Display_First_Name], F_1004782 AS [Display_Last_Name], F_1004783 AS [Display_Name], F_1004784 AS [E_mail_Address], F_1004785 AS [Employee_ID], F_1004786 AS [Employee_Postal], F_1004787 AS [Enable_Person_ID], F_1004788 AS [End_Date], F_1004789 AS [Facsimile_Telephone_Number], F_1004790 AS [FLSA_Status], F_1004791 AS [General_Ledger_Location], F_1004792 AS [GL_Company_Code], F_1004793 AS [Global_Dial], F_1004794 AS [Hire_Date], F_1004795 AS [HRBP_ID], F_1004796 AS [HRBP_Name], F_1004797 AS [ICT], F_1004798 AS [ICT_Date], F_1004799 AS [Internal_Office_Floor], F_1004800 AS [Internal_Office_Location], F_1004801 AS [Is_Active_Role], F_1004802 AS [Job_Code], F_1004803 AS [Job_Code_Description], F_1004804 AS [Job_Family], F_1004805 AS [Job_Family_Description], F_1004806 AS [Job_Title], F_1004807 AS [LDAP_Record_Description], F_1004808 AS [LDAP_Record_Type], F_1004809 AS [Location], F_1004810 AS [Location_Description], F_1004811 AS [Location_Short_Description], F_1004812 AS [Manager_Description_Override], F_1004813 AS [Manager_ID], F_1004814 AS [Manager_Indicator], F_1004815 AS [Manager_Indicator_Description], F_1004816 AS [Manager_Name], F_1004817 AS [Manager_Override], F_1004818 AS [Middle_Initial], F_1004819 AS [Mobile_Telephone_Number], F_1004820 AS [Organization_Supervisor_ID], F_1004821 AS [Organization_Supervisor_name], F_1004822 AS [Pay_Group], F_1004823 AS [Pension_Indicator], F_1004824 AS [Person_Role_ID], F_1004825 AS [Postal_Code], F_1004826 AS [Preferred_First_Name], F_1004827 AS [Preferred_Last_Name], F_1004828 AS [Primary_Work_Telephone_Number], F_1004829 AS [Primary_Work_Telephone_Number_Extension], F_1004830 AS [Record_Profile_Type], F_1004831 AS [Role_End_Date], F_1004832 AS [Role_Start_Date], F_1004833 AS [SAP_Currency], F_1004834 AS [SSN], F_1004835 AS [Standard_Hours], F_1004836 AS [State], F_1004837 AS [State_Name], F_1004838 AS [Supplier_Name], F_1005052 AS [Upcoming_Transfer], F_1005053 AS [Upcoming_Transfer_Date], F_1004841 AS [User_Status], F_1004842 AS [User_Type], F_1005056 AS [validation_results] FROM dbo.B_SNAPSHOT_10252 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PERSON_ROLE_Staging to dbadmin
go

grant select on PERSON_ROLE_Staging to ewsys
go

grant select on PERSON_ROLE_Staging to boomi
go

grant select on PERSON_ROLE_Staging to informatica
go

grant select on PERSON_ROLE_Staging to som
go

grant select on PERSON_ROLE_Staging to apttus
go

grant select on PERSON_ROLE_Staging to epmdev
go

grant select on PERSON_ROLE_Staging to MDMAdmin
go

grant select on PERSON_ROLE_Staging to produser1
go

grant select on PERSON_ROLE_Staging to produser3
go

grant select on PERSON_ROLE_Staging to produser2
go

grant select on PERSON_ROLE_Staging to integration_team
go

grant select on PERSON_ROLE_Staging to digital
go

