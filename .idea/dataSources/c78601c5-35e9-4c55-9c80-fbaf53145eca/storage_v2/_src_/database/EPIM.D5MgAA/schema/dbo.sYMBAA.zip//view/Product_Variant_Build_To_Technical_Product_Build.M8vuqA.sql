CREATE VIEW dbo.[Product Variant Build To Technical Product Build] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1003473 AS [Attribute_ID], F_1003474 AS [Attribute_Name], F_1003475 AS [SequenceNum], F_1003476 AS [Taxonomy_Node_ID] FROM dbo.B_SNAPSHOT_10218 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on [Product Variant Build To Technical Product Build] to boomi
go

grant select on [Product Variant Build To Technical Product Build] to informatica
go

grant select on [Product Variant Build To Technical Product Build] to som
go

grant select on [Product Variant Build To Technical Product Build] to apttus
go

grant select on [Product Variant Build To Technical Product Build] to epmdev
go

grant select on [Product Variant Build To Technical Product Build] to MPOPOV_TEST
go

grant select on [Product Variant Build To Technical Product Build] to digital
go

