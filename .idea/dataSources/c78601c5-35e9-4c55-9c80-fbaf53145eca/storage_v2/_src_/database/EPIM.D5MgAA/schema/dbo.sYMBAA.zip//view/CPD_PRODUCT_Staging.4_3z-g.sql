CREATE VIEW dbo.[CPD_PRODUCT_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005202 AS [CPDProductID], F_1005207 AS [CPDSourceSystem], F_1005201 AS [EPMCPMProductID], F_1005208 AS [ProductMarketingRecordID], F_1005206 AS [SAPFinishedItemMaterialNumber], F_1005203 AS [SAPFullServiceMaterialNumber], F_1005204 AS [SAPFullSetMaterialNumber], F_1005205 AS [SAPSubMaterialNumber] FROM dbo.B_SNAPSHOT_10281 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on CPD_PRODUCT_Staging to dbadmin
go

grant select on CPD_PRODUCT_Staging to boomi
go

grant select on CPD_PRODUCT_Staging to informatica
go

grant select on CPD_PRODUCT_Staging to som
go

grant select on CPD_PRODUCT_Staging to apttus
go

grant select on CPD_PRODUCT_Staging to epmdev
go

grant select on CPD_PRODUCT_Staging to MDMAdmin
go

grant select on CPD_PRODUCT_Staging to produser1
go

grant select on CPD_PRODUCT_Staging to produser3
go

grant select on CPD_PRODUCT_Staging to produser2
go

grant select on CPD_PRODUCT_Staging to digital
go

