create   view TR_Contact_Exclusion as
select rule_id,
       isnull(upper(first_name), upper('_novalue'))    FIRST_NAME,
       isnull(upper(last_name), upper('_novalue'))     LAST_NAME,
       isnull(upper(email_address), upper('_novalue')) EMAIL_ADDRESS,
       isnull(upper(first_name), upper('_novalue')) + isnull(upper(last_name), upper('_novalue')) + isnull(upper(email_address), upper('_novalue')) FULL_STRING
from ECX_Contact_Exclusion
go

grant select on TR_Contact_Exclusion to boomi
go

grant select on TR_Contact_Exclusion to informatica
go

