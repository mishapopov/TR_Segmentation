
CREATE TRIGGER epim_ad_bcodeSetDetail ON B_CODE_SET_DETAIL
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = code_set_detail_id from deleted;

	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BcodeSetDetail', @obj_id;
    END
go

