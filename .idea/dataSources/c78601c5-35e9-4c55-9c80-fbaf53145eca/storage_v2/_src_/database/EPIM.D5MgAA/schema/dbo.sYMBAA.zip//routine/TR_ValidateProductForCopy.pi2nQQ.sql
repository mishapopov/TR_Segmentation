
  CREATE PROCEDURE [dbo].[TR_ValidateProductForCopy]
    @itemIds VARCHAR(200),  -- Delimited list of source product variants
    @savedSetId int,    -- Saved set ID of source product variants
    @source VARCHAR(10),    -- Name of source (Staging)
    @target VARCHAR(10) -- Name of target (Change, State)
    AS BEGIN
    
        -- TR_ValidateProductForCopy - Verifies that none of the selected Product variants are in the 
        -- target repository.  If they are, then the request fails due to items already in workflow.  Returns
        -- either 'none' or a delimited list of Product Variant IDs that were found in the target.  Can specify
        -- either a delimited list or saved set of Product Variant records in the source repository (referenced by 
        -- Internal Record Ids).
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_ValidateProductForCopy '5707081, 5707083, 5707082, 5707127, 5707037, 5707043',null,'Staging','Build'
        --
        --  EXEC TR_ValidateProductForCopy null,10548,'Staging','Build'
        --
        -- Workflow Activity:
        --
        -- EXEC TR_ValidateProductForCopy '%itemIds%',%savedSetId%,'Staging','State'
        
        DECLARE @sql VARCHAR(max)
        
        -- Determine if saved set was specified
        
        IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds and see if any of the same Product Variant IDs are in the target
            SET @sql = 'select isnull(STUFF((select '','' + cast(tp.PRODUCT_ID as VARCHAR) as [text()] ' +
                'FROM PRODUCT_' + @source + ' sp  ' +
                'join PRODUCT_' + @target + ' tp on tp.PRODUCT_ID = sp.PRODUCT_ID ' +
                'where sp.InternalRecordId in (' + @itemIds + ') FOR XML PATH('''')), 1, 1, ''''), ''none'') as existingRecords'

    END
        ELSE
        BEGIN
            -- Code set - use it and see if any of the same Product Variant IDs are in the target
            SET @sql = 'select isnull(STUFF((select '','' + cast(tp.PRODUCT_ID as VARCHAR) as [text()] ' +
                'from PRODUCT_' + @source + ' sp ' +
                'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = sp.InternalRecordId ' +
                'join PRODUCT_' + @target + ' tp on tp.PRODUCT_ID = sp.PRODUCT_ID ' +
                'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  as existingRecords'
    END

        print @sql
        EXECUTE (@sql)
        
    END
  go

