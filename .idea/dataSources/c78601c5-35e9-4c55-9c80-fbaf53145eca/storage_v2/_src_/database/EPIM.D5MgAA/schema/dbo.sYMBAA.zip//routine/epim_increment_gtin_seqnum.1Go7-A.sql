
--#BEGIN#
Create Procedure [dbo].[epim_increment_gtin_seqnum] ( @tpId int )
As
    BEGIN
	DECLARE @sNum int;
    
	select @sNum = starting_seq_num from b_trading_partner where trading_partner_id = @tpId;
	update b_trading_partner set starting_seq_num = (@sNum+1) where trading_partner_id=@tpId;

END
go

