create view EPIMV_10256 as select ID, PLT_10258."F_12348" as F_1004365, PLT_10258."F_1" as F_1004364 from PLT_10258
go

