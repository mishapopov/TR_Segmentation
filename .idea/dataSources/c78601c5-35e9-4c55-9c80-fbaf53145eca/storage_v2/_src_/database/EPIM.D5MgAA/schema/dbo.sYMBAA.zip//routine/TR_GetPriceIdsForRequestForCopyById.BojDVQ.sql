
CREATE PROCEDURE [dbo].[TR_GetPriceIdsForRequestForCopyById]
    @requestId VARCHAR(200),  -- Internal Record ID of the Request
    @source VARCHAR(10)	-- Name of source (Build, Clone, Change, State)
AS BEGIN

    -- TR_GetPriceIdsForRequestForCopyById - Retrieves the Price IDs of all linked records for the designated
    -- request record (by InternalRecordId) in the designated request pre-stage repository (Clone, Build, Change, or
    -- State).  Returns a comma-delimited list of all linked Price Ids or 'none' if no linked pricing records are found
    --
    -- To do: Consider enhancement to also filter out matches by header data and same start/end date as those are no action recordsthat are not a match by header data
    -- and start/end date. These are records that will need to have an action taken for merging to staging.
    --
    -- Header attributes: Product Variant ID, Price Type, Price Type Term, Currency, Price Tier Units, Customer Type, Service Type
    --
    -- Example SQL:
    --
    --  EXEC TR_GetPriceIdsForRequestForCopyById '6317946','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetPriceIdsForRequestForCopyById '%itemIds%','%source%'

    DECLARE @sql NVARCHAR(max)
    DECLARE @productVariantPrice VARCHAR(max)

    -----------------------------------------------------------------------------
    -- Get list of product variant price records
    -----------------------------------------------------------------------------

    set @sql = '' +
               'SELECT @productVariantPrice = isnull(STUFF((' +
               'select '','' + cast(pvp.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' ' +
               'order by pvp.Price_Start_Date ' +
               'FOR XML PATH('''') ' +
               '), 1, 1, ''''), ''none'')  ';

    print 'productVariantPrice - ' + @sql;

    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantPrice varchar(max) out', @productVariantPrice out
    END TRY
    BEGIN CATCH
        set @productVariantPrice = 'none';
    END CATCH

    -----------------------------------------------------------------------------
    -- Return all ids
    -----------------------------------------------------------------------------

    select @productVariantPrice as productVariantPrice

END
go

