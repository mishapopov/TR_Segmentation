
CREATE PROCEDURE [dbo].[NextChangeNotificationSequence] 
AS
BEGIN
	DECLARE @NextSequence table (ID int);
	
	BEGIN TRAN

	INSERT INTO dbo.ChangeNotificationSequenceTable 
       	OUTPUT inserted.id INTO @NextSequence
	DEFAULT VALUES

	ROLLBACK TRAN
	
	SELECT * from @NextSequence;
END
go

