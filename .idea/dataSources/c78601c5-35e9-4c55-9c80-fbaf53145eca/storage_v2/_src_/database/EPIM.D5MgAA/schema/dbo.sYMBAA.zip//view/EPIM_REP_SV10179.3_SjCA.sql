create view EPIM_REP_SV10179 as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1004565)') as nvarchar(MAX))  as F_1004565,  CAST(attr_data.query('data(Item/F_1004566)') as nvarchar(MAX))  as F_1004566,  CAST(attr_data.query('data(Item/F_1004567)') as nvarchar(MAX))  as F_1004567 from b_master_repository_item bmri where bmri.repository_id = 10179
go

