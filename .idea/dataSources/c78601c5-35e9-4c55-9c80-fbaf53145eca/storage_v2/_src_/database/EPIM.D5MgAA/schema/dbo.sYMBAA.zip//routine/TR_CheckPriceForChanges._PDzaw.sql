
CREATE PROCEDURE [dbo].[TR_CheckPriceForChanges]
@internalRecordId int  -- Internal Record ID of Change Request

AS BEGIN

    -- TR_CheckPriceForChanges - Checks the pricing for the Product Variants in a Change Request
    -- for any changes.  Returns true if changes were found.
    --
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_CheckPriceForChanges 5714408
    --
    -- Workflow Activity:
    --
    -- EXEC TR_CheckPriceForChanges %itemIds%


    -- Check if any pricing has changed.  If new pricing is added, it will appear as a change

    -------------------------------------------------------------------------------------------------------
    -- 1/17/20 AR - Old logic commented out. Instead of comparing values, new logic will be to check if
    --              at least one price record was added in the change repositories as price and price tier
    --              are no longer copied by default on the product variant change or price change workflows
    -------------------------------------------------------------------------------------------------------

    --select case when changedRows > 0 then 'true' else 'false' end as hasPriceChanges
    --from (
    --         select count(*) as changedRows
    --         from Request_Change r
    --                  join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
    --                  join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
    --                  left outer join PRODUCT_VARIANT_PRICE_Change pvp on pv.Product_Variant_ID = pvp.Product_Variant_ID
    --                  left outer join PRODUCT_VARIANT_PRICE_TIER_Change pvpt on pvpt.Product_Price_ID = pvp.Product_Price_ID
    --                  left outer join PRODUCT_VARIANT_PRICE_Staging spvp on pvp.Product_Price_ID = spvp.Product_Price_ID
    --                  left outer join PRODUCT_VARIANT_PRICE_TIER_Staging spvpt on spvpt.Product_Price_ID = spvp.Product_Price_ID
    --         where (isnull(pvp.Price_Type, '') <> isnull(spvp.Price_Type, '')
    --             or isnull(pvp.Price_Type_Term, '') <> isnull(spvp.Price_Type_Term, '')
    --             or isnull(cast(pvp.Price_Start_Date as VARCHAR), '') <> isnull(cast(spvp.Price_Start_Date as VARCHAR), '')
    --             or isnull(cast(pvp.Price_End_Date as VARCHAR), '') <> isnull(cast(spvp.Price_End_Date as VARCHAR), '')
    --             or isnull(pvp.Price, 0.0) <> isnull(spvp.Price, 0.0)
    --             or isnull(pvp.Currency, '') <> isnull(spvp.Currency, '')
    --             or isnull(pvp.Multi_Year_Eligible, '') <> isnull(spvp.Multi_Year_Eligible, '')
    --             or isnull(pvpt.Price_Tier_Minimum, 0.0)  <> isnull(spvpt.Price_Tier_Minimum, 0.0)
    --             or isnull(pvpt.Price_Tier_Maximum, 0.0)  <> isnull(spvpt.Price_Tier_Maximum, 0.0)
    --             or isnull(pvp.Price_Tier_Units, '') <> isnull(spvp.Price_Tier_Units, '')
    --             or isnull(pvp.Price_of_Incremental_User, 0.0) <> isnull(spvp.Price_of_Incremental_User, 0.0)
    --             or isnull(pvp.Customer_Type, '') <> isnull(spvp.Customer_Type, '')
    --             or isnull(pvp.Service_Type, '') <> isnull(spvp.Service_Type, ''))
    --           and r.InternalRecordId = @internalRecordId) v

    select case when count(1) > 0 then 'true' else 'false' end as hasPriceChanges
    from Request_Change r
             join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
             join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
             join PRODUCT_VARIANT_PRICE_Change pvp on pv.Product_Variant_ID = pvp.Product_Variant_ID
        and r.InternalRecordId = @internalRecordId

END
go

