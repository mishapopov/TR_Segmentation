create view EPIMV_10285 as select ID, PLT_10287."F_1" as F_1004364 from PLT_10287
go

