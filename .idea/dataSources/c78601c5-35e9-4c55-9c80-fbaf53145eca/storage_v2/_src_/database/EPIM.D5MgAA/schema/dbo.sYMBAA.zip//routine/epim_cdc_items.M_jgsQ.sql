

CREATE PROCEDURE [dbo].[epim_cdc_items] 
	@beginDate DATETIME,
	@endDate DATETIME,
	@optionInd int
AS
SET NOCOUNT ON;
BEGIN

    if (@optionInd = 1)
		SELECT count(*) FROM cdc.fn_cdc_get_all_changes_dbo_B_MASTER_REPOSITORY_ITEM(
									sys.fn_cdc_map_time_to_lsn('smallest greater than', @beginDate),
									sys.fn_cdc_map_time_to_lsn('largest less than or equal', @endDate), 
									'all');
	else
		SELECT item_id, repository_id, attr_data FROM cdc.fn_cdc_get_all_changes_dbo_B_MASTER_REPOSITORY_ITEM(
									sys.fn_cdc_map_time_to_lsn('smallest greater than', @beginDate),
									sys.fn_cdc_map_time_to_lsn('largest less than or equal', @endDate), 
									'all');

END
go

