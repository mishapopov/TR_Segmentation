--#BEGIN#
-- exec epim_initialize_enable_search 


Create Procedure [dbo].[epim_initialize_enable_search] 
As
    BEGIN

    declare @tcnt bigint;
    declare @startRow int;
    declare @startRowIndex int;
    declare @maximumRows int;
    DECLARE @first_id bigint;
    declare @strViewText varchar(MAX);
    declare @truncStmt varchar(512);
    Declare @temptable table (itemid bigint);

    SET @truncStmt = 'Disable Trigger triggerUpdateSearchTable ON B_MASTER_REPOSITORY_ITEM';
    EXECUTE (@truncStmt);
    
    SET @truncStmt = 'Truncate table B_MASTER_REPOSITORY_SEARCH_ATTRIBUTES';                 			
    EXECUTE (@truncStmt);

    SET NOCOUNT ON;
    SET @startRowIndex = 1;
    SET @maximumRows = 10000;
    SET @tcnt = (SELECT COUNT(Item_Id) FROM B_MASTER_REPOSITORY_ITEM);


    WHILE (@startRowIndex <= @tcnt)
    BEGIN
      SET ROWCOUNT @startRowIndex

      SELECT @first_id = Item_ID FROM B_MASTER_REPOSITORY_ITEM with (nolock) Order BY Item_id
      
      -- Now, set the row count to MaximumRows and get
      -- all records >= @first_id
      SET ROWCOUNT @maximumRows
      
      Delete From @temptable
      
      INSERT INTO @temptable
      SELECT item_id FROM B_MASTER_REPOSITORY_ITEM  with (nolock) where item_id >= @first_id Order by item_id 

      SET ROWCOUNT 0

      INSERT INTO 
            B_MASTER_REPOSITORY_SEARCH_ATTRIBUTES (
                              Repository_Id,
                              Repository_Item_Id,
                              Repository_Item_Attribute_SystemName,
                              Repository_Item_Attribute_Value
                              )           

            SELECT 
                              Repository_Id,item_id,  Details.query('local-name(.)').value('.','NVARCHAR(20)') AS Repository_Item_Attribute_SystemName,
                              Details.value('.','NVARCHAR(max)') AS Repository_Item_Attribute_Value 
            FROM B_MASTER_REPOSITORY_ITEM  with (nolock) CROSS APPLY 
                                      ATTR_DATA.nodes('//Item/*') AS NewTable(Details) 
            where ITEM_ID in (select itemid from @temptable)                  
      
      Set @startRowIndex = @startRowIndex  + @maximumRows
    END

    SET @strViewText = 'ENABLE Trigger triggerUpdateSearchTable ON B_MASTER_REPOSITORY_ITEM';
    execute (@strViewText);

END
go

