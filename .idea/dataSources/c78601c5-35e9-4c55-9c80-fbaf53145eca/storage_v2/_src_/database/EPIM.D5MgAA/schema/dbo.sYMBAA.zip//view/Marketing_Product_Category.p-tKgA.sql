CREATE VIEW dbo.[Marketing_Product_Category] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005236 AS [Hierarchy_Name], F_1005237 AS [Id], F_1005238 AS [IsPrimary], F_1005239 AS [Product_Id], F_1005240 AS [Status] FROM dbo.B_SNAPSHOT_10289 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

