
  CREATE PROCEDURE [dbo].[TR_CloneProductVariantByID]
  	@internalRecordId bigint,
  	@userPreferenceName varchar(200),
  	@numberOfClones int,
  	@maxClones int
    AS BEGIN
    
        -- TR_CloneProductVariantByID - returns the specified number of copies of the designated
        -- Product Variant record to be cloned the designated number of times.  Includes
        -- only those attributes specified in the designated user preference
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_CloneProductVariantByID 5701387,'Clone Product Variant',10,500   
        --
        -- Workflow Activity:
        --
        -- EXEC TR_CloneProductVariantByID %itemIds%,'Clone Product Variant',%numberOfClones%,500
        
    	-- Limit the maximum number of clones
    	if @numberOfClones > 500
    	BEGIN
    		SET @numberOfClones = 500
    	END
	DECLARE @querySql nvarchar(MAX)
	DECLARE @attributeName VARCHAR(255)
	DECLARE @repositoryName VARCHAR(200)
	DECLARe @restrictedName VARCHAR(50)

	-- Get the repository name
	SELECT @repositoryName = m.name 
	from b_master_repository_item i 
	join b_master_repository m on m.master_repository_id = i.repository_id
	where item_id = @internalRecordId

	-- Create the SQL perform the extraction query - include empty auto-sequenced ID (so new numbers are generated)
    
	SET @querySql = 'select top ' + cast(@numberOfClones as varchar) + ' null as [Product Variant ID]';
            
	DECLARE db_cursor CURSOR FOR  
	select fa.NAME as AttributeName, fa.RESTRICTED_NAME
	from B_USER_PREF_DISPLAY_ATTR upa
	join B_USER_PREFERENCE up on up.USER_PREFERENCE_ID = upa.USER_PREFERENCE_ID
	join B_MASTER_REPOSITORY m on up.MASTER_REPOSITORY_ID = m.MASTER_REPOSITORY_ID
	join B_FORMAT_ATTR fa on upa.FORMAT_ATTR_ID = fa.FORMAT_ATTR_ID
	join B_REPOSITORY_FMT_ATTR_MAPPING rfam on rfam.MASTER_REPOSITORY_ID = m.MASTER_REPOSITORY_ID
		and rfam.FORMAT_ATTR_ID = fa.FORMAT_ATTR_ID
	where up.NAME = @userPreferenceName
	and m.NAME = @repositoryName
	and fa.NAME <> 'Product Variant ID'
	-- Only include attributes in the snapshot
	and rfam.SEARCHABLE_IND = 1
	order by upa.SEQ_NUM
    
	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @attributeName,@restrictedName

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		-- add to SQL
		SET @querySql = @querySql + ',';
		SET @querySql = @querySql + @restrictedName + ' as [' +  @attributeName + ']';
    
		FETCH NEXT FROM db_cursor INTO @attributeName,@restrictedName 
    	END  
    
	CLOSE db_cursor  
	DEALLOCATE db_cursor 
    
	-- Add FROM clause

	SET @querySql = @querySql + ' from [' + @repositoryName + '] v';
	
	-- Add CROSS JOIN to generate the multiple records
	
	SET @querySql = @querySql + ' CROSS JOIN sys.all_objects';
	
	-- Limit to a single source record
	
	SET @querySql = @querySql + ' WHERE v.InternalRecordId = ' + cast(@internalRecordId as VARCHAR);

	-- Execute query 
	
	print @querySql;

	EXECUTE (@querySql) 
		
    END
  go

