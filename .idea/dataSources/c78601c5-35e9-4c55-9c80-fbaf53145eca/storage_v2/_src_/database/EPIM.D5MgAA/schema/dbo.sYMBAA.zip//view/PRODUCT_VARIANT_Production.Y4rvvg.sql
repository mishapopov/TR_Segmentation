CREATE VIEW dbo.[PRODUCT_VARIANT_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004718 AS [Associated_Product_Family], F_1004712 AS [Bridge_Eligibility], F_1004705 AS [Bundle_Price_Type], F_1004704 AS [Bundle_Type], F_1004717 AS [Contract_Type], F_1004517 AS [Customer_Sales_Restriction], F_1004363 AS [Customer_Segment], F_1004719 AS [Eligible_Parties], F_1004365 AS [External_Product_Description], F_1004518 AS [Geographic_Sales_Restriction], F_1004366 AS [Internal_Product_Description], F_1004367 AS [Launch_Date], F_1004368 AS [Make_Royalty_Payments], F_1004707 AS [Maximum_Bundle_Components], F_1004706 AS [Minimum_Bundle_Components], F_1004727 AS [Official_Product_Name], F_1004687 AS [Product_Delivery], F_1004516 AS [Product_Id], F_1004370 AS [Product_Language], F_1004372 AS [Product_Sale_Status], F_1004679 AS [Product_Variant_GUID], F_1004364 AS [Product_Variant_ID], F_1004431 AS [Product_Version], F_1004375 AS [Proposed_End_of_Life_Date], F_1004376 AS [Proposed_Migration_Date], F_1004378 AS [Source_System], F_1004379 AS [Source_System_Product_ID], F_1004703 AS [Standalone_Saleable], F_1004381 AS [Target_Audience], F_1004708 AS [Trial_Eligible] FROM dbo.B_SNAPSHOT_10134 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PRODUCT_VARIANT_Production to dbadmin
go

grant select on PRODUCT_VARIANT_Production to ewsys
go

grant select on PRODUCT_VARIANT_Production to boomi
go

grant select on PRODUCT_VARIANT_Production to informatica
go

grant select on PRODUCT_VARIANT_Production to som
go

grant select on PRODUCT_VARIANT_Production to apttus
go

grant select on PRODUCT_VARIANT_Production to epmdev
go

grant select on PRODUCT_VARIANT_Production to MDMAdmin
go

grant select on PRODUCT_VARIANT_Production to produser1
go

grant select on PRODUCT_VARIANT_Production to produser3
go

grant select on PRODUCT_VARIANT_Production to produser2
go

grant select on PRODUCT_VARIANT_Production to integration_team
go

grant select on PRODUCT_VARIANT_Production to ecmxread
go

grant select on PRODUCT_VARIANT_Production to MPOPOV_TEST
go

grant select on PRODUCT_VARIANT_Production to digital
go

