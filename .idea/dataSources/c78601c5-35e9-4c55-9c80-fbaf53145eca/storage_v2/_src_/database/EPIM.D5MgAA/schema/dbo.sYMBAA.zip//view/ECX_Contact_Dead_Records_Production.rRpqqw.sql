CREATE VIEW dbo.[ECX_Contact_Dead_Records_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005495 AS [del_actual_deleted_date], F_1005491 AS [del_data_id], F_1005487 AS [del_guid], F_1005490 AS [del_load_date], F_1005489 AS [del_source_system_contact_id], F_1005492 AS [del_source_system_customer_id], F_1005488 AS [del_source_system_name], F_1005486 AS [del_status], F_1005493 AS [del_target_date], F_1005494 AS [del_target_days] FROM dbo.B_SNAPSHOT_10312 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on ECX_Contact_Dead_Records_Production to dbadmin
go

grant select on ECX_Contact_Dead_Records_Production to ewsys
go

grant select on ECX_Contact_Dead_Records_Production to boomi
go

grant select on ECX_Contact_Dead_Records_Production to informatica
go

grant select on ECX_Contact_Dead_Records_Production to som
go

grant select on ECX_Contact_Dead_Records_Production to apttus
go

grant select on ECX_Contact_Dead_Records_Production to epmdev
go

grant select on ECX_Contact_Dead_Records_Production to MDMAdmin
go

grant select on ECX_Contact_Dead_Records_Production to produser1
go

grant select on ECX_Contact_Dead_Records_Production to produser3
go

grant select on ECX_Contact_Dead_Records_Production to produser2
go

grant select on ECX_Contact_Dead_Records_Production to integration_team
go

grant select on ECX_Contact_Dead_Records_Production to ecmxread
go

grant select on ECX_Contact_Dead_Records_Production to digital
go

