

Create Procedure epim_bulkVal_sequence (@gtin_value varchar(50) out)
As
    BEGIN

    declare @seqCount int;
    declare @seqName varchar(100);
    declare @strCmd varchar(1000);

    SET NOCOUNT ON;
    SET @seqName = 'EPIM_BULKVAL_SEQ';

    SET @seqCount = (select count(*) from sysobjects where name = @seqName and type = 'U');
    if @seqCount < 1
    begin	
	SET @strCmd = 'Create TABLE ' + @seqName + 
			'(sequence_id int IDENTITY(000001,1) , col1 int) ' ;
	execute (@strCmd);
    end;

    SET @strCmd = 'insert into ' + @seqName + ' (col1) values (1) ';
    --print('epim_auto_sequence cmd: ' + @strCmd);
    execute (@strCmd);
    set @gtin_value = 'UI' + cast(@@identity as nvarchar(max));
    print('@gtin_value: ' + @gtin_value);

END
go

