
CREATE PROCEDURE [dbo].[CleanupOrphanedRecordsForRepository]
   @productionRepositoryName VARCHAR(max),
   @stagingRepositoryName VARCHAR(max),
   @numberOfMinutes int,
   @displayAttributes VARCHAR(max)
AS
BEGIN
	DECLARE @repositoryId as int
	CREATE TABLE #Messages(
		id bigint IDENTITY(1,1) NOT NULL,
		Message varchar(max))

      
	CREATE TABLE #CleanupIds(
		id bigint)
      
	DECLARE @sql VARCHAR(max);
	SET @sql = 'insert into #CleanupIds select p.InternalRecordId ' +
		'from [' + @productionRepositoryName + '] p ' +
		'join B_MASTER_REPOSITORY_ITEM mp on mp.ITEM_ID = p.InternalRecordId ' +
		'left outer join [' + @stagingRepositoryName + '] s on s.InternalRecordId = mp.STAGING_ITEM_ID ' +
		'left outer join B_REPOSITORY_ITEM_HISTORY h on h.ITEM_ID = mp.STAGING_ITEM_ID ' +
		'AND h.MODIFY_ACTION = ''delete'' AND h.MODIFICATION_DATETIME > DATEADD(minute,-' + cast(@numberOfMinutes as VARCHAR) + ',GETDATE()) ' +
		'where s.InternalRecordId is null ' +
		'and h.MODIFY_ACTION is null';
	EXEC (@sql);
      
	insert into #Messages(Message) values('Found  ' + cast(@@ROWCOUNT as varchar) + '  orphans ')
      	
      	-- Display details on orphan records (if specified)
      	if @displayAttributes IS NOT NULL
      	BEGIN
      		SET @sql = 'INSERT INTO #Messages(Message) SELECT ''Orphan: ';
      		DECLARE @position int;
      		DECLARE @attributeList VARCHAR(max);
      		DECLARE @attributeName VARCHAR(max);
      		
		SET @position = 1
		SET @attributeList = @displayAttributes + ',';
		WHILE charindex(',',@attributeList,@position) <> 0
		BEGIN
			SET @attributeName = substring(@attributeList, @position, charindex(',',@attributeList,@position) - @position);
			SET @sql = @sql + '  ' + @attributeName + '=''+ CAST([' + @attributeName + '] AS VARCHAR) + ''; ';
			-- Next key
			SET @position = charindex(',',@attributeList,@position) + 1
		END
		SET @sql = @sql + ''' FROM [' + @productionRepositoryName + '] p ' +
			'WHERE p.InternalRecordId in (SELECT id FROM #CleanupIds)';
		print @sql;
		
		EXEC (@sql);

      	END
	-- Delete items from B_MASTER_REPOSITORY_ITEM
	DELETE from B_MASTER_REPOSITORY_ITEM WHERE ITEM_ID in (SELECT id from #CleanupIds)
		
	insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from ' + @productionRepositoryName + '.');
	
	-- Delete items from Snapshot
	DECLARE @snapshotTableName varchar(200);
	DECLARE @includeKV int;
	SELECT @snapshotTableName = 'B_SNAPSHOT_' + cast(mr.MASTER_REPOSITORY_ID as VARCHAR), @includeKV = mr.INCLUDE_SNAPSHOT_KV_IND from B_MASTER_REPOSITORY mr where mr.NAME = @productionRepositoryName 
	
	SET @sql = 'DELETE FROM ' + @snapshotTableName + ' ' +
		'WHERE ITEM_ID in (SELECT id FROM #CleanupIds)';
	EXEC (@sql);
	insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from ' + @snapshotTableName + '.');
	
	-- Delete items from KV Snapshot (if defined)
	if (@includeKv = 1) 
	BEGIN
		SET @sql = 'DELETE FROM ' + @snapshotTableName + '_KV ' +
			'WHERE ITEM_ID in (SELECT id FROM #CleanupIds)';
		EXEC (@sql);
		insert into #Messages(Message) values('Deleted ' + cast(@@ROWCOUNT as VARCHAR) + ' records from ' + @snapshotTableName + '_KV.');
	END
      		
	-- Return message
	
	select Message from #Messages order by id
	

	DROP TABLE #Messages;
	DROP TABLE #CleanupIds
END

go

