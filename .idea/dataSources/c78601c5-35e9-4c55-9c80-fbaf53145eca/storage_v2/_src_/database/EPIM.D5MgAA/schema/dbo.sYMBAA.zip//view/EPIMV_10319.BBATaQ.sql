create view EPIMV_10319 as select ID, PLT_10321."F_1" as F_1004523, PLT_10321."F_12500" as F_1004526 from PLT_10321
go

