
CREATE TRIGGER epim_au_battr ON B_ATTR FOR UPDATE
AS 
    BEGIN
	declare @attrId int;
	declare @faId int;
	declare @vcId int;
	declare @expStr varchar(2000);
	declare @attrName varchar(500);
	declare @oldAttrName varchar(500);
    declare @tblFAIds table(RowID INT IDENTITY(1, 1), faID int);
    declare @tblVCIds table(RowID INT IDENTITY(1, 1), vcID int);
    declare @tblExpStrs table(RowID INT IDENTITY(1, 1), expSTR varchar(8000));
    declare @tblCount int;
    declare @tblCount2 int;
	declare @tblCount3 int;
	declare @iRow int;
	declare @jRow int;

	if @@ROWCOUNT = 0
		return
	set nocount on
	-- retrieve the object that was inserted
	select @attrId = attr_id, @attrName = name from inserted;
	SELECT @oldAttrName = (SELECT name FROM Deleted);

    	INSERT into @tblFAIds select format_attr_id from b_format_attr where attr_id = @attrId;
    	SET @tblCount = (select count(*) from @tblFAIds);

    	if  @tblCount > 0
    	BEGIN 
		SET @iRow = 1;
         	WHILE @iRow <= @tblCount
		begin
             	SELECT @faId = faID FROM @tblFAIds WHERE RowID = @iRow;
    		    INSERT into @tblVCIds select view_column_id from b_view_column where 
			format_attr_id = @faId;
    		    INSERT into @tblExpStrs select expression_string from b_view_column where 
			format_attr_id = @faId;
    		    SET @tblCount2 = (select count(*) from @tblVCIds);
		    SET @tblCount3 = (select count(*) from @tblExpStrs);

    		    if  @tblCount2 > 0
    		    BEGIN 
			SET @jRow = 1;
         		WHILE @jRow <= @tblCount2
			begin
             	SELECT @expStr = expSTR FROM @tblExpStrs WHERE RowID = @jRow;
             	SELECT @vcId = vcID FROM @tblVCIds WHERE RowID = @jRow;
			    SELECT @expStr = replace(@expStr, @oldAttrName, @attrName);
			    UPDATE b_view_column set expression_string = @expStr where
				view_column_id = @vcId;
		    	    SET @jRow = @jRow + 1;
			end;
    		    END; 
		    SET @iRow = @iRow + 1;
		end;
    	END; 

	-- update name for the attr in the fileLayoutMapping table
	update b_file_layout_mapping set name = @attrName where attr_id = @attrId;

END
go

