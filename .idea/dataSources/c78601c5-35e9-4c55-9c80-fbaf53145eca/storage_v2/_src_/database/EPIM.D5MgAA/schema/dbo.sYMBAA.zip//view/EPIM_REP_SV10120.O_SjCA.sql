create view EPIM_REP_SV10120 as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1004310)') as nvarchar(MAX))  as F_1004310,  CAST(attr_data.query('data(Item/F_1004311)') as nvarchar(MAX))  as F_1004311,  CAST(attr_data.query('data(Item/F_1004312)') as nvarchar(MAX))  as F_1004312,  CAST(attr_data.query('data(Item/F_1004313)') as nvarchar(MAX))  as F_1004313,  CAST(attr_data.query('data(Item/F_1004314)') as nvarchar(MAX))  as F_1004314,  CAST(attr_data.query('data(Item/F_1004315)') as nvarchar(MAX))  as F_1004315,  CAST(attr_data.query('data(Item/F_1004316)') as nvarchar(MAX))  as F_1004316,  CAST(attr_data.query('data(Item/F_1004317)') as nvarchar(MAX))  as F_1004317 from b_master_repository_item bmri where bmri.repository_id = 10120
go

grant select on EPIM_REP_SV10120 to boomi
go

