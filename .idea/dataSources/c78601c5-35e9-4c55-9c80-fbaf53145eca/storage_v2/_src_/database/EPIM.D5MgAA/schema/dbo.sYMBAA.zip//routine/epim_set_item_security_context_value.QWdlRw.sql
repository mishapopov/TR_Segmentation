
--
-- procedure to set BmasterRepositoryItem.securityContextValue to the created_by user's securityContextValue
--
--#BEGIN#
Create Procedure [dbo].[epim_set_item_security_context_value] 
As
    BEGIN

    SET NOCOUNT ON;
    
	update B_MASTER_REPOSITORY_ITEM set SECURITY_CONTEXT_VALUE = u.SECURITY_CONTEXT_VALUE
	FROM  B_MASTER_REPOSITORY_ITEM mri, B_USER u 
	where  mri.CREATED_BY = u.user_id and mri.REPOSITORY_ID in 
	      (select master_repository_id from B_MASTER_REPOSITORY where SECURITY_CONTEXT_IND = 1)

END
go

