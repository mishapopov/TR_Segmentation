create view EPIMV_10113 as select ID, PLT_10113."F_12349" as F_1004366, PLT_10113."F_1" as F_1004364 from PLT_10113
go

