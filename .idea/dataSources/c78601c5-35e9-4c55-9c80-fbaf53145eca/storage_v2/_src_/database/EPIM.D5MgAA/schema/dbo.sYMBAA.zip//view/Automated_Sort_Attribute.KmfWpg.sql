CREATE VIEW dbo.[Automated Sort Attribute] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1003473 AS [Attribute_ID], F_1003474 AS [Attribute_Name], F_1003475 AS [SequenceNum], F_1003476 AS [Taxonomy_Node_ID] FROM dbo.B_SNAPSHOT_10026 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

