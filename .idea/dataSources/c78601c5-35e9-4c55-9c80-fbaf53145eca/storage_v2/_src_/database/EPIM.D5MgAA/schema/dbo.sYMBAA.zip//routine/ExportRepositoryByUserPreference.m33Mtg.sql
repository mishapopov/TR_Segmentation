
CREATE PROCEDURE [dbo].[ExportRepositoryByUserPreference]
   @repositoryName VARCHAR(max),
   @userPreferenceName VARCHAR(max),
   @jobNumber VARCHAR(20)
AS
BEGIN
    DECLARE @createSql nvarchar(MAX);
    DECLARE @querySql VARCHAR(MAX) -- holds the SQL statement for creating the view
    DECLARE @attributeName VARCHAR(255)
    DECLARe @systemName VARCHAR(50)
    DECLARE @attributeId VARCHAR(10)
    DECLARE @repositoryId VARCHAR(10)
    DECLARE @key VARCHAR(255)
    DECLARE @value VARCHAR(max)

    -- Get the repository ID
    SELECT @repositoryId = cast(master_repository_id as VARCHAR) from b_master_repository where name = @repositoryName

    -- Create the SQL perform the extraction query
    
    SET @createSql = 'create table RepositoryHoldingTable'+@jobNumber + ' (';
    SET @querySql = 'insert into RepositoryHoldingTable' + @jobNumber +' select ';
            
    DECLARE @position int
    DECLARE @keyPosition int
    SET @position = 1
    DECLARE db_cursor CURSOR FOR  
	select fa.NAME as AttributeName,'F_' + cast(upa.FORMAT_ATTR_ID as VARCHAR) as SystemName
	from B_USER_PREF_DISPLAY_ATTR upa
	join B_USER_PREFERENCE up on up.USER_PREFERENCE_ID = upa.USER_PREFERENCE_ID
	join B_MASTER_REPOSITORY m on up.MASTER_REPOSITORY_ID = m.MASTER_REPOSITORY_ID
	join B_FORMAT_ATTR fa on upa.FORMAT_ATTR_ID = fa.FORMAT_ATTR_ID
	where up.NAME = @userPreferenceName
	and m.NAME = @repositoryName
	order by upa.SEQ_NUM
    
    OPEN db_cursor  
    FETCH NEXT FROM db_cursor INTO @attributeName,@systemName
    
    WHILE @@FETCH_STATUS = 0  
    BEGIN  
	  -- add to SQL
	  if @position > 1
	  BEGIN
	  	SET @createSql = @createSql + ',';
	  	SET @querySql = @querySql + ',';
	  END
	  SET @position = @position + 1;
	  SET @createSql = @createSql + '[' + @attributeName + '] VARCHAR(MAX)';
	  SET @querySql = @querySql + 'dbo.EW_CVT_XML(m.attr_data.value(''(/Item/' + @systemName + 
	      ')[1]'', ''varchar(max)'')) as [' +  @attributeName + ']';
    
          FETCH NEXT FROM db_cursor INTO @attributeName,@systemName 
    END  
    
    CLOSE db_cursor  
    DEALLOCATE db_cursor 

    SET @createSql = @createSql + ')';
    
    
    -- Add FROM clause
    
    SET @querySql = @querySql + ' from b_master_repository_item m ';
    
      
 
    -- Add condition to restrict to the specified repository
    
    SET @querySql = @querySql + ' WHERE m.repository_id = ''' + @repositoryId + '''';

    -- Create holding table
    print @createSql;
    EXECUTE (@createSql);


    print @querySql;
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;  
    BEGIN TRANSACTION;
    EXECUTE (@querySql) 
    COMMIT TRANSACTION;
    
    -- Generate results
    SET @querySql = 'select * from RepositoryHoldingTable' + @jobNumber;
    EXECUTE (@querySql)

    -- Drop holding table
    SET @querySql = 'DROP TABLE RepositoryHoldingTable' + @jobNumber;
    EXECUTE (@querySql)
    
end
go

