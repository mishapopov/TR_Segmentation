create view EPIMV_10220 as select ID, PLT_10222."F_1" as F_1004364, PLT_10222."F_12358" as F_1004375 from PLT_10222
go

