create view EPIMV_10239 as select ID, PLT_10241."F_1" as F_1004364, PLT_10241."F_12691" as F_1004727 from PLT_10241
go

