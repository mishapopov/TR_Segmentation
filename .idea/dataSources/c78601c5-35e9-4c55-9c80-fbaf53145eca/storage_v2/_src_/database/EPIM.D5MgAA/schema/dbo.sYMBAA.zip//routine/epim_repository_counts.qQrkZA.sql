--#BEGIN#
CREATE PROCEDURE [dbo].[epim_repository_counts] 
	@repoId bigint,
	@savedSetId bigint,
	@total BIGINT OUT,
	@stageProdInd BIGINT OUT,
	@partnerRepoId BIGINT OUT,
	@valid BIGINT OUT,
	@warning BIGINT OUT,
	@severe BIGINT OUT,
	@notValidated BIGINT OUT,
	@validInProd BIGINT OUT,
	@warningInProd BIGINT OUT,
	@severeInProd BIGINT OUT,
	@notValidatedInProd BIGINT OUT,
	@validNotInProd BIGINT OUT,
	@warningNotInProd BIGINT OUT,
	@severeNotInProd BIGINT OUT,
	@notValidatedNotInProd BIGINT OUT
AS
BEGIN

	SET @total = 0;
	SET @stageProdInd = 0;
	SET @partnerRepoId = 0;
	SET @valid = 0;
	SET @warning = 0;
	SET @severe = 0;
	SET @notValidated = 0;
	SET @validInProd = 0;
	SET @warningInProd = 0;
	SET @severeInProd = 0;
	SET @notValidatedInProd = 0;
	SET @validNotInProd = 0;
	SET @warningNotInProd = 0;
	SET @severeNotInProd = 0;
	SET @notValidatedNotInProd = 0;

	SELECT @stageProdInd=STAGING_PRODUCTION_IND, @partnerRepoId=STAGING_PROD_PARTNER_REPO_ID FROM B_MASTER_REPOSITORY WHERE MASTER_REPOSITORY_ID=@repoId;

	if (@savedSetId>0)
	    Select @total=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	           WHERE REPOSITORY_ID=@repoId AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	else
	    Select @total=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId;
	    
   
	if (@savedSetId>0)
	    Select @valid=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	           WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=0 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	else
	    Select @valid=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=0;
	    
	if (@savedSetId>0)
	    Select @warning=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	           WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=1 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	else
	    Select @warning=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=1;
	    
	if (@savedSetId>0)
	    Select @severe=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	           WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=3 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	else
	    Select @severe=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND HAS_ERROR_IND=3;
	    
	if (@savedSetId>0)
	    Select @notValidated=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	           WHERE REPOSITORY_ID=@repoId AND (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL) AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	else
	    Select @notValidated=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL);

	if (@stageProdInd=1)
	BEGIN
		if (@savedSetId>0)
	    		Select @validInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		  WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=0 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @validInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=0;
	    	
   
		if (@savedSetId>0)
	    		Select @warningInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		   WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=1 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @warningInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=1;
	    	
		if (@savedSetId>0)
	    		Select @severeInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		    WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=3 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @severeInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND HAS_ERROR_IND=3;

		if (@savedSetId>0)
	    		Select @notValidatedInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		     WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL) AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @notValidatedInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND RECORD_STATE=0 AND (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL);
		
		if (@savedSetId>0)
	    		Select @validNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		      WHERE REPOSITORY_ID=@repoId AND (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null)
	    		       AND HAS_ERROR_IND=0 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @validNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND 
	    		      (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) AND HAS_ERROR_IND=0;

		if (@savedSetId>0)
	    		Select @warningNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		       WHERE REPOSITORY_ID=@repoId AND (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) 
	    		       AND HAS_ERROR_IND=1 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @warningNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND 
	    		       (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) AND HAS_ERROR_IND=1;

		if (@savedSetId>0)
	    		Select @severeNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		        WHERE REPOSITORY_ID=@repoId AND (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) 
	    		        AND HAS_ERROR_IND=3 AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @severeNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId AND 
	    		        (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) AND HAS_ERROR_IND=3;

		if (@savedSetId>0)
	    		Select @notValidatedNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM mri, B_SAVED_SET_ITEM ssi 
	    		         WHERE REPOSITORY_ID=@repoId AND (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) 
	    		         AND (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL) AND mri.item_id=ssi.item_id AND ssi.saved_set_id=@savedSetId;
	    	else
	    		Select @notValidatedNotInProd=COUNT(*) FROM B_MASTER_REPOSITORY_ITEM WHERE REPOSITORY_ID=@repoId 
	    		         AND (RECORD_STATE=1 or RECORD_STATE=2 or RECORD_STATE is null) AND 
	    		         (HAS_ERROR_IND=2 OR HAS_ERROR_IND is NULL);
	END
END
go

