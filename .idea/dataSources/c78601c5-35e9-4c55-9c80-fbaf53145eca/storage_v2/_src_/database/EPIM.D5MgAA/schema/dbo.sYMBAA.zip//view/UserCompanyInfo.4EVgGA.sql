
CREATE VIEW [dbo].[UserCompanyInfo]
AS

-- Return e-mail address for each supplier

--	Picks the first supplier that is assigned to a division AND has an Email address defined.

-- 	Example use:  Select * from UniPro_SupplierInfo


	select u1.login, u1.COMPANY_NAME, u1.EMAIL FROM B_USER u1
	join (
		select min(LOGIN) as LOGIN, COMPANY_NAME
		from B_USER
		where COMPANY_NAME is not null 
		and COMPANY_NAME <> '' 
		and ISNUMERIC(COMPANY_NAME) = 1
		and EMAIL is not null
		and EMAIL <> ''
		group by COMPANY_NAME
	) u2 on u2.LOGIN = u1.LOGIN



go

grant select on UserCompanyInfo to boomi
go

grant select on UserCompanyInfo to informatica
go

