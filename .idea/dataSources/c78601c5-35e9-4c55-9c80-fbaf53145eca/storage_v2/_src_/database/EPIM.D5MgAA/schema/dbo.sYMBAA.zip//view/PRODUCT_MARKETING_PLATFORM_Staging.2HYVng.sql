CREATE VIEW dbo.[PRODUCT_MARKETING_PLATFORM_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005210 AS [Platform], F_1005212 AS [PlatformCategory], F_1005214 AS [PlatformCategoryBenefit], F_1005213 AS [PlatformCategoryFeature], F_1005211 AS [PlatformGroup], F_1005209 AS [PlatformRecordID] FROM dbo.B_SNAPSHOT_10284 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to dbadmin
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to boomi
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to informatica
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to som
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to apttus
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to epmdev
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to MDMAdmin
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to produser1
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to produser3
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to produser2
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to ecmxread
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to MPOPOV_TEST
go

grant select on PRODUCT_MARKETING_PLATFORM_Staging to digital
go

