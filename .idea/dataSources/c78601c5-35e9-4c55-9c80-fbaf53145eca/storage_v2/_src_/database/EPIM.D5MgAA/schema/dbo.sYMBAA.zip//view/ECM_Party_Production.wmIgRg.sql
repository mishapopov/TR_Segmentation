CREATE VIEW dbo.[ECM_Party_Production] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005596 AS [Additional_Name_1], F_1005597 AS [Additional_Name_2], F_1005571 AS [Currency], F_1005572 AS [Customer_Type], F_1005573 AS [DUNS_Number], F_1005574 AS [Email_Address], F_1005577 AS [First_Name], F_1005578 AS [Full_Name], F_1005579 AS [GUID], F_1005583 AS [Industry_Classification], F_1005584 AS [Is_Firm_Edition], F_1005585 AS [is_merged], F_1005586 AS [Is_Party_Sanctioned], F_1005587 AS [Is_Record_Logically_Deleted], F_1005588 AS [Is_Tax_VAT_Exempt], F_1005589 AS [Language_Code], F_1005590 AS [Last_Name], F_1005591 AS [Last_Update_Timestamp], F_1005592 AS [Middle_Name], F_1005594 AS [Name_Suffix], F_1005599 AS [Party_Full_Name], F_1005600 AS [Party_ID], F_1005602 AS [Party_Status], F_1005603 AS [Party_Type], F_1005620 AS [Standardized_Full_Name], F_1005913 AS [Standardized_Full_Name_lt], F_1005914 AS [Standardized_Full_Name_rt], F_1005606 AS [Sub_SBU_Name], F_1005611 AS [VAT_Code] FROM dbo.B_SNAPSHOT_10322 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on ECM_Party_Production to boomi
go

grant select on ECM_Party_Production to informatica
go

grant select on ECM_Party_Production to ecmxread
go

