
CREATE PROCEDURE [dbo].[TR_PriceTeamCheckPriceForChanges]
  	@internalRecordId int  -- Internal Record ID of Change Request
AS BEGIN

    -- Anthony - DEPRECATED By 20191209 Changes
    --
    -- TR_PriceTeamCheckPriceForChanges - Checks the pricing for the Product Variants in a
    -- Pricing Change Request workflow.
    --
    -- Returns a list of product variant price records to validate.
    --
    -- Example SQL:
    --
    --  EXEC TR_PriceTeamCheckPriceForChanges 5714408
    --
    -- Workflow Activity:
    --
    -- EXEC TR_CheckPriceForChanges %itemIds%

    SELECT STUFF((
        SELECT ',' + CAST(c.InternalId AS VARCHAR)
        FROM (
            SELECT distinct a.InternalRecordId as InternalId
            FROM (
                SELECT pvp.Product_Variant_ID,pvp.Price_Type,pvp.Customer_Type,pvp.Price_of_Incremental_User,pvp.Service_Type
                    ,pvp.Multi_Year_Eligible,pvp.Price_Type_Term,  pvp.Currency,pvp.Price_Tier_Units,pvpt.Price_Tier_Minimum
                    ,pvpt.Price_Tier_Maximum,pvp.Price_Start_Date,pvp.Price_End_Date,pvp.InternalRecordId
                from Request_Change r
                join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_Id
                join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
                join PRODUCT_VARIANT_PRICE_Change pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID
                left join PRODUCT_VARIANT_PRICE_TIER_Change pvpt on pvp.Product_Price_ID =pvpt.Product_Price_ID
                where r.InternalRecordId = @internalRecordId --%itemIds%
            ) a
            Inner join (
                SELECT pvp.Product_Variant_ID,pvp.Price_Type,pvp.Customer_Type,pvp.Price_of_Incremental_User,pvp.Service_Type
                    ,pvp.Multi_Year_Eligible,pvp.Price_Type_Term,  pvp.Currency,pvp.Price_Tier_Units
                    ,pvpt.Price_Tier_Minimum,pvpt.Price_Tier_Maximum,pvp.Price_Start_Date
                    ,pvp.Price_End_Date,pvp.InternalRecordId
                from PRODUCT_VARIANT_Staging pv
                join PRODUCT_VARIANT_PRICE_Staging pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID
                left join PRODUCT_VARIANT_PRICE_TIER_Staging pvpt on pvp.Product_Price_ID =pvpt.Product_Price_ID
            ) b  on ISNULL(a.Product_Variant_ID, 0)=ISNULL(b.Product_Variant_ID, 0)
        ) c FOR XML PATH('')
    ), 1, 1, '') as productVariantPrice
 		
    END
go

