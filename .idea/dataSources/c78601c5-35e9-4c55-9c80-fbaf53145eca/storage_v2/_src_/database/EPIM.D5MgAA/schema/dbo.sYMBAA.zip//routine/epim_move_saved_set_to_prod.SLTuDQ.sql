--#BEGIN#
create procedure [dbo].[epim_move_saved_set_to_prod]
	@stageSavedSetId bigint,
	@stageRepoId bigint,
	@prodSavedSetId bigint OUTPUT
AS
BEGIN
	DECLARE @stageSavedSetName nvarchar(255);
	DECLARE @sourceStageRepoId bigint;
	DECLARE @sourceProdRepoId bigint;
	DECLARE @prodRepoId bigint;
	DECLARE @savedSetUserId bigint;
	DECLARE @stagingRepoName nvarchar(255);
	DECLARE @prodRepoName nvarchar(255);
	DECLARE @prodSavedSetName nvarchar(255);
	DECLARE @RowsDeleted bigint;
	DECLARE @debug int;

	BEGIN TRY
		SET @debug=null;
		if (@debug is null) SET NOCOUNT ON;		
		if (@stageSavedSetId is null)  RAISERROR('Saved Set not found: %I64d', 16, 1, @stageSavedSetId);
		if (@debug is not null) PRINT '29: get saved set info'; 
		SELECT  @stageSavedSetName=NAME, @savedSetUserId=[USER_ID],@sourceStageRepoId=MASTER_REPOSITORY_ID FROM B_SAVED_SET with (nolock) WHERE SAVED_SET_ID=@stageSavedSetId;
		if (@stageSavedSetName is null)  RAISERROR('Saved Set not found: %I64d', 16, 1, @stageSavedSetId);
		if (@debug is not null) PRINT '32: stage saved set name is ' + @stageSavedSetName;
		if (@debug is not null) PRINT '33: saved set user id is ' + CAST(@savedSetUserId AS VARCHAR); 
		
		if (@debug is not null) PRINT '35: get repo info'; 
		SELECT @stagingRepoName=NAME, @prodRepoId=STAGING_PROD_PARTNER_REPO_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE MASTER_REPOSITORY_ID = @stageRepoId;
		if (@stagingRepoName is null)  RAISERROR('Staging Repository not found: %I64d', 16, 1, @stageRepoId);
		if (@prodRepoId is null)  RAISERROR('Production Repository not found: %s', 16, 1, @stagingRepoName);
		SELECT @prodRepoName=NAME  FROM B_MASTER_REPOSITORY with (nolock) WHERE MASTER_REPOSITORY_ID = @prodRepoId;
		if (@prodRepoName is null)  RAISERROR('Prod Repository not found: %I64d', 16, 1, @prodRepoId);		
		if (@debug is not null) PRINT '41: stage repo id=' + CAST(@stageRepoId AS VARCHAR); 
		if (@debug is not null) PRINT '42: stage repo name=' + @stagingRepoName; 
		if (@debug is not null) PRINT '43: prod repo id=' + CAST(@stageRepoId AS VARCHAR); 
		if (@debug is not null) PRINT '44: prod repo name=' +@prodRepoName;
		
		if (@sourceStageRepoId IS NOT NULL)
		BEGIN
			if (@debug is not null) PRINT '48: check prod repo id  when soruce repo is not null';
			SELECT @sourceProdRepoId=STAGING_PROD_PARTNER_REPO_ID FROM B_MASTER_REPOSITORY with (nolock) WHERE MASTER_REPOSITORY_ID = @sourceStageRepoId;
			if (@sourceProdRepoId is null)  RAISERROR('Production Repository not found: %I64d', 16, 1, @sourceStageRepoId);
			if (@debug is not null) PRINT '51: source prod repo id=' + CAST(@sourceProdRepoId AS VARCHAR); 
			SELECT @prodSavedSetId=saved_Set_id FROM B_SAVED_SET with (nolock) WHERE MASTER_REPOSITORY_ID=@sourceProdRepoId and NAME = @stageSavedSetName and USER_ID=@savedSetUserId;
		END
		ELSE
		BEGIN
			if (@debug is not null) PRINT '56: check prod repo id  when soruce repo is null';
			SET @sourceProdRepoId=NULL;
			SELECT DISTINCT @prodSavedSetId=ss.SAVED_SET_ID FROM  B_SAVED_SET as ss INNER JOIN B_SAVED_SET_REPO AS ssr ON ss.SAVED_SET_ID = ssr.SAVED_SET_ID 
			WHERE (ss.MASTER_REPOSITORY_ID IS NULL) AND (ss.NAME = @stageSavedSetName) AND (ss.USER_ID = @savedSetUserId) AND (ssr.MASTER_REPOSITORY_ID = @prodRepoId);
		END
		if (@debug is not null) PRINT '61: prod saved set id=' + CAST(@prodSavedSetId AS VARCHAR); 
		IF (@prodSavedSetId is null)
		BEGIN
			if (@debug is not null) PRINT '64: create new prod saved set'; 
			INSERT INTO B_SAVED_SET(USER_ID, MASTER_REPOSITORY_ID, NAME, DESCRIPTION, SHARED_IND, CREATION_DATETIME, LAST_UPDATE_BY, LAST_UPDATE_DATETIME, TEMPORARY_IND) 
				SELECT USER_ID, @sourceProdRepoId, NAME, DESCRIPTION, SHARED_IND, GETDATE(), LAST_UPDATE_BY, GETDATE(), TEMPORARY_IND FROM B_SAVED_SET with (nolock) 
				WHERE SAVED_SET_ID=@stageSavedSetId;
			SELECT  @prodSavedSetId=SCOPE_IDENTITY();
			if (@prodSavedSetId is null)  RAISERROR('Prod Saved Set not created: %s', 16, 1, @stageSavedSetName);
		END
		ELSE
		BEGIN
			if (@debug is not null) PRINT '73: Remove contents from prod saved set' + @stageSavedSetName;				
			SET @RowsDeleted = 1
			WHILE (@RowsDeleted > 0)
			BEGIN
				DELETE TOP (10000) FROM B_SAVED_SET_ITEM WHERE saved_Set_id=@prodSavedSetId;
				SET @RowsDeleted = @@ROWCOUNT
			END
			DELETE  FROM B_SAVED_SET_REPO WHERE saved_Set_id=@prodSavedSetId;
		END
		if (@debug is not null) PRINT '82: add all prod repos and non stage/prod repos';
		INSERT INTO B_SAVED_SET_REPO (SAVED_SET_ID, MASTER_REPOSITORY_ID)
		SELECT DISTINCT @prodSavedSetId, MASTER_REPOSITORY_ID FROM (
		SELECT @prodSavedSetId AS prodSavedSetId, ssr.MASTER_REPOSITORY_ID AS MASTER_REPOSITORY_ID
		FROM  B_SAVED_SET_REPO AS ssr INNER JOIN
					   B_SAVED_SET AS ss ON ssr.SAVED_SET_ID = ss.SAVED_SET_ID INNER JOIN
					   B_MASTER_REPOSITORY ON ssr.MASTER_REPOSITORY_ID = B_MASTER_REPOSITORY.MASTER_REPOSITORY_ID
		WHERE (B_MASTER_REPOSITORY.STAGING_PROD_PARTNER_REPO_ID IS NULL) AND (ss.SAVED_SET_ID = @stageSavedSetId)
		UNION
		SELECT @prodSavedSetId AS prodSavedSetId, B_MASTER_REPOSITORY.STAGING_PROD_PARTNER_REPO_ID AS MASTER_REPOSITORY_ID
		FROM  B_SAVED_SET_REPO AS ssr INNER JOIN
					   B_SAVED_SET AS ss ON ssr.SAVED_SET_ID = ss.SAVED_SET_ID INNER JOIN
					   B_MASTER_REPOSITORY ON ssr.MASTER_REPOSITORY_ID = B_MASTER_REPOSITORY.MASTER_REPOSITORY_ID
		WHERE (B_MASTER_REPOSITORY.STAGING_PROD_PARTNER_REPO_ID IS NOT NULL) AND (ss.SAVED_SET_ID = @stageSavedSetId)) x;	
		if (@debug is not null) PRINT '97: Add all production Items to saved set for production repos';
		INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID)
		SELECT @prodSavedSetId, bmi.ITEM_ID
		FROM  B_MASTER_REPOSITORY_ITEM AS bmi INNER JOIN
					   B_SAVED_SET_ITEM AS ssi ON bmi.STAGING_ITEM_ID = ssi.ITEM_ID INNER JOIN
					   B_MASTER_REPOSITORY AS m ON bmi.REPOSITORY_ID = m.MASTER_REPOSITORY_ID
		WHERE (ssi.SAVED_SET_ID = @stageSavedSetId) AND (m.STAGING_PROD_PARTNER_REPO_ID IS NOT NULL);
		
		if (@debug is not null) PRINT '104: Add all nonproduction Items to saved set for non staging/prod repos';
		INSERT INTO B_SAVED_SET_ITEM (SAVED_SET_ID, ITEM_ID)
		SELECT @prodSavedSetId, bmi.ITEM_ID
		FROM  B_MASTER_REPOSITORY_ITEM AS bmi INNER JOIN
					   B_SAVED_SET_ITEM AS ssi ON bmi.ITEM_ID = ssi.ITEM_ID INNER JOIN
					   B_MASTER_REPOSITORY AS m ON bmi.REPOSITORY_ID = m.MASTER_REPOSITORY_ID
		WHERE (ssi.SAVED_SET_ID = @stageSavedSetId) AND (m.STAGING_PROD_PARTNER_REPO_ID IS NULL);

		if (@debug is not null) PRINT 'Done!'; 			
	
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;	
END
go

