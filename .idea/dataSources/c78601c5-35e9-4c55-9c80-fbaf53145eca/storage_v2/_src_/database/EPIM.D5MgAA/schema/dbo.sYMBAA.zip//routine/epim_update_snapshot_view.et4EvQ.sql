

create PROCEDURE [dbo].[epim_update_snapshot_view] ( 
		@repositporyId bigint,
		@itemIdList varchar(max) )
As
BEGIN
	declare @strViewText nvarchar(MAX);
	declare @strViewCol1Text nvarchar(MAX);
	declare @strViewCol2Text nvarchar(MAX);
    declare @tblFormatAttrIds table(RowID INT IDENTITY(1, 1), fmtAttrID int);
    declare @fmtAttrId int;
    declare @tblCount int;
    declare @iRow int;
    declare @cstrPrefViewPrefix nvarchar(20);
    declare @cstrFmtAttrPrefix nvarchar(10);
    declare @vName nvarchar(1000);
    declare @addedFmtAttrCount int;

    SET NOCOUNT ON;
    SET @cstrPrefViewPrefix  = 'B_SNAPSHOT_';
    SET @cstrFmtAttrPrefix      = 'F_';

    -- get the preferred projection list
    -- all names are prefixed with 'F_' 
    INSERT into @tblFormatAttrIds  SELECT f.FORMAT_ATTR_ID
			FROM         B_FORMAT_ATTR f INNER JOIN
								  B_REPOSITORY_FMT_ATTR_MAPPING rfm ON f.FORMAT_ATTR_ID = rfm.FORMAT_ATTR_ID
			WHERE     (rfm.SEARCHABLE_IND = 1) AND (rfm.MASTER_REPOSITORY_ID = @repositporyId) order by f.SEQUENCE_NUM;
    SET @tblCount = (select count(*) from @tblFormatAttrIds);

    if @tblCount > 0
    BEGIN
		-- construct the view
		-- standard columns
		SET @vName = @cstrPrefViewPrefix + cast(@repositporyId as varchar);
		SET @strViewText = 'DELETE FROM ' + @vName + ' WHERE ITEM_ID IN (' + @itemIdList + ')';
		print @strViewText;
		execute (@strViewText);

		SET @strViewCol1Text = '';
		SET @strViewCol2Text = '';
		-- xml columns
		SET @iRow = 1;
		SET @addedFmtAttrCount = 0;
		WHILE @iRow < @tblCount
		begin
			SELECT @fmtAttrId = fmtAttrID FROM @tblFormatAttrIds WHERE RowID = @iRow;
			if @fmtAttrId > 0
			begin
				if @addedFmtAttrCount > 0
				begin
				  SET @strViewCol1Text = @strViewCol1Text + cast(',' as nvarchar(MAX));
				  SET @strViewCol2Text = @strViewCol2Text + cast(',' as nvarchar(MAX));
				end;
				SET @strViewCol1Text = @strViewCol1Text + cast(' ' as nvarchar(MAX))
					+ cast(@cstrFmtAttrPrefix as nvarchar(MAX))  
					+ cast(@fmtAttrId as nvarchar(MAX));
				SET @strViewCol2Text = @strViewCol2Text + cast(' dbo.epim_rtrim(dbo.epim_convert_xml_special_chars (NULLIF(' as nvarchar(MAX))
					+ cast(dbo.epim_get_xml_attribute(@fmtAttrId, 1) as nvarchar(MAX)) 
					+ cast(',''''))) as ' as nvarchar(MAX)) + cast(@cstrFmtAttrPrefix as nvarchar(MAX))  
					+ cast(@fmtAttrId as nvarchar(MAX));
				SET @addedFmtAttrCount = @addedFmtAttrCount + 1;
			end;
			SET @iRow = @iRow + 1;
		end;

		-- last xml column  (no comma)
		SELECT @fmtAttrId = fmtAttrID FROM @tblFormatAttrIds WHERE RowID = @iRow;
		if @fmtAttrId > 0
		begin
			if @addedFmtAttrCount > 0
			begin
				SET @strViewCol1Text = @strViewCol1Text + cast(',' as nvarchar(MAX));
				SET @strViewCol2Text = @strViewCol2Text + cast(',' as nvarchar(MAX));
			end;
			SET @strViewCol1Text = @strViewCol1Text + cast(' ' as nvarchar(MAX))
				+ cast(@cstrFmtAttrPrefix as nvarchar(MAX))  
				+ cast(@fmtAttrId as nvarchar(MAX));
			SET @strViewCol2Text = @strViewCol2Text + cast(' dbo.epim_rtrim(dbo.epim_convert_xml_special_chars (NULLIF(' as nvarchar(MAX))
				+ cast(dbo.epim_get_xml_attribute(@fmtAttrId, 1) as nvarchar(MAX))
				+ cast(',''''))) as ' as nvarchar(MAX)) + cast(@cstrFmtAttrPrefix as nvarchar(MAX))  
				+ cast(@fmtAttrId as nvarchar(MAX));
		end;

		SET @strViewText = 'INSERT INTO ' + @vName + ' (item_id, DATA_LAST_UPDATE_DATETIME, ' + @strViewCol1Text 
						   + ' ) select item_id, getDate(),  ' + @strViewCol2Text;

		-- from clause
		SET @strViewText = @strViewText + cast(' from b_master_repository_item bmri' as nvarchar(MAX));
		-- where clause
		SET @strViewText = @strViewText + cast(' where bmri.repository_id = ' as nvarchar(MAX)) 
			+ cast(@repositporyId as nvarchar(MAX)); 
		-- where clause
		SET @strViewText = @strViewText + cast(' and bmri.item_id IN (' as nvarchar(MAX)) 
			+ @itemIdList + cast(')' as nvarchar(MAX)); 

		-- real create
		-- make sure this user has 'create view' privilege!
		print @strViewText;
		execute (@strViewText);

	END;
END

go

