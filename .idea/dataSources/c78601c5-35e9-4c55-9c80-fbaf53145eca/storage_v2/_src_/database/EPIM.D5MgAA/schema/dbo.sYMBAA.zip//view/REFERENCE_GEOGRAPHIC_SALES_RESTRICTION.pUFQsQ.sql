CREATE VIEW dbo.[REFERENCE_GEOGRAPHIC_SALES_RESTRICTION] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004441 AS [EPM_Reference_Code], F_1004442 AS [System_Name], F_1004443 AS [Value] FROM dbo.B_SNAPSHOT_10233 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to dbadmin
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to ewsys
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to boomi
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to informatica
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to som
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to apttus
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to epmdev
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to MDMAdmin
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to produser1
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to produser3
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to produser2
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to VIEW_ACCESS
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to integration_team
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to ecmxread
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to MPOPOV_TEST
go

grant select on REFERENCE_GEOGRAPHIC_SALES_RESTRICTION to digital
go

