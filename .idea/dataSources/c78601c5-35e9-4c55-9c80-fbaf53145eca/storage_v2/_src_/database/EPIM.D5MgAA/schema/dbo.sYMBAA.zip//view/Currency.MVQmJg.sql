CREATE VIEW dbo.[Currency] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1005250 AS [Currency_Alphabetic_Code], F_1005252 AS [Currency_Minor_Unit], F_1005249 AS [Currency_Name], F_1005251 AS [Currency_Numeric_Code] FROM dbo.B_SNAPSHOT_10299 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on Currency to boomi
go

grant select on Currency to informatica
go

grant select on Currency to som
go

grant select on Currency to apttus
go

grant select on Currency to epmdev
go

grant select on Currency to ecmxread
go

grant select on Currency to MPOPOV_TEST
go

grant select on Currency to digital
go

