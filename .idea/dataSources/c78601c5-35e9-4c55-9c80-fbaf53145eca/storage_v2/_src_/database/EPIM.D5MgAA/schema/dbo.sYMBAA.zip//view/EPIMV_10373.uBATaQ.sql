create view EPIMV_10373 as select ID, PLT_10375."F_1" as F_1004364, PLT_10375."F_12662" as F_1004727 from PLT_10375
go

