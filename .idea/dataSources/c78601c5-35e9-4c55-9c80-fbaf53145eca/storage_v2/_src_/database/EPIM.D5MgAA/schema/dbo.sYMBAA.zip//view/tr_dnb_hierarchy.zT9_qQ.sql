create   view tr_dnb_hierarchy as
select --count(*),
       ps.party_id,
       ps.guid,
       ps.DUNS_Number  as party_duns_number,
       dnb.DUNS_Number as dnb_duns_number,
       dnb.Legal_Parent_DUNS_Number,
       dnb.Legal_Domestic_Ultimate_DUNS_Number,
       dnb.Legal_Global_Ultimate_DUNS_Number,
       dnb.Operational_Parent_DUNS_Number,
       dnb.Operational_Domestic_Ultimate_DUNS_Number,
       dnb.Operational_Global_Ultimate_DUNS_Number
from ECM_Party_Staging ps
         left join ecm_dnb dnb on ps.DUNS_Number = dnb.DUNS_Number
go

