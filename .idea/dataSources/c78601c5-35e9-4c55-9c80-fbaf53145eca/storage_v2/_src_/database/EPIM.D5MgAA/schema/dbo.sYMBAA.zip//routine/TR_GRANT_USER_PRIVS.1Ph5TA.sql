create   procedure [dbo].[TR_GRANT_USER_PRIVS] @tr_db_user_name varchar(128) = null
as
    if @tr_db_user_name is null or upper(@tr_db_user_name) = 'NULL'
        begin
            select t.tr_db_user_name, t.tr_db_user_role from [TR_DB_USERS] t;
            declare @query_all_users varchar(max);
            declare tr_db_privs_for_all_users cursor
                for
                select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'epmprod'
                  and (t2.table_name like 'product%_production' or t2.table_name like 'technical%_production'
                    or t2.table_name like 'reference_%'
                    or t2.table_name in
                       (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'epmprod'))
                union all
                select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'epmstg'
                  and (t2.table_name like '%kv' or t2.table_name like 'technical%_staging' or
                       t2.table_name like 'product%_staging'
                    or t2.table_name like 'reference_%'
                    or t2.table_name in
                       (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'epmstg'))
                union all
                select 'grant all on [ecmx_delta_control] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'epmstg'
                  and t2.table_name = 'ecmx_delta_control'
                union all
                select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'ecmxprod'
                  and (t2.table_name like 'ec%_production'
                    or t2.table_name like 'ec%_source'
                    or t2.table_name like 'reference_%'
                    or t2.table_name in
                       (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'ecmxprod'))
                union all
                select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'ecmxstg'
                  and (t2.table_name like 'ec%_staging'
                    or t2.table_name like '%_kv')
                union all
                select 'grant all on [ecmx_delta_control] to ' + tr.tr_db_user_name + ';' as query
                from tr_db_users tr,
                     information_schema.tables t2
                where tr.tr_db_user_role = 'ecmxstg'
                  and t2.table_name = 'ecmx_delta_control';
            open tr_db_privs_for_all_users;
            fetch next from tr_db_privs_for_all_users into @query_all_users;
            while @@fetch_status = 0
                begin
                    print @query_all_users;
                    fetch next from tr_db_privs_for_all_users into @query_all_users
                    exec (@query_all_users)
                end;

            close tr_db_privs_for_all_users;
            deallocate tr_db_privs_for_all_users;
        end
    else
        if @tr_db_user_name is not null
            begin
                select t.tr_db_user_name, t.tr_db_user_role
                from [TR_DB_USERS] t
                where t.tr_db_user_name = @tr_db_user_name;

                declare @query_single_user varchar(max);
                declare tr_db_privs_for_single_user cursor
                    for
                    select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'epmprod'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and (t2.table_name like 'product%_production' or t2.table_name like 'technical%_production'
                        or t2.table_name like 'reference_%'
                        or t2.table_name in
                           (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'epmprod'))
                    union all
                    select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'epmstg'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and (t2.table_name like '%kv' or t2.table_name like 'technical%_staging' or
                           t2.table_name like 'product%_staging'
                        or t2.table_name like 'reference_%'
                        or t2.table_name in
                           (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'epmstg'))
                    union all
                    select 'grant all on [ecmx_delta_control] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'epmstg'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and t2.table_name = 'ecmx_delta_control'
                    union all
                    select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'ecmxprod'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and (t2.table_name like 'ec%_production'
                        or t2.table_name like 'ec%_source'
                        or t2.table_name like 'reference_%'
                        or t2.table_name in
                           (select tr_db_object_name from tr_db_exception_tables where tr_db_user_role = 'ecmxprod'))
                    union all
                    select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'ecmxstg'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and (t2.table_name like 'ec%_staging'
                        or t2.table_name like '%_kv')
                    union all
                    select 'grant all on [ecmx_delta_control] to ' + tr.tr_db_user_name + ';' as query
                    from tr_db_users tr,
                         information_schema.tables t2
                    where tr.tr_db_user_role = 'ecmxstg'
                      and tr.tr_db_user_name = @tr_db_user_name
                      and t2.table_name = 'ecmx_delta_control'
                open tr_db_privs_for_single_user;
                fetch next from tr_db_privs_for_single_user into @query_single_user;
                while @@fetch_status = 0
                    begin
                        print @query_single_user;
                        fetch next from tr_db_privs_for_single_user into @query_single_user
                        exec (@query_single_user)
                    end;
                close tr_db_privs_for_single_user;
                deallocate tr_db_privs_for_single_user;
            end
go

