

CREATE PROCEDURE [dbo].[TR_DynamicPriceChangeHash2CompareHash1]
    @internalRecordId int,  -- Internal Record ID of Change Request
    @priceHash1 varchar(max),     -- First price hash used to compare against 2nd price hash
    @source VARCHAR(10)	-- Name of source repo (Staging, Clone)

AS BEGIN

    -- TR_DynamicPriceChangeHash2CompareHash1 - Creates a second hash for the price records associated to product
    -- variants located within a request. Compares the first price hash to the second price hash to
    -- determine if price records changed.
    --
    --
    -- Example SQL:
    --
    --  EXEC TR_DynamicPriceChangeHash2CompareHash1 5770496,'0x73c8824b5c091c11db479434be2b28e6a7516c144688a11de74c9a9ca11ee5ef','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_DynamicPriceChangeHash2CompareHash1 %itemIds%,'%priceHash1%','Change'
    --
    -- Create second price hash based on price records values associated to product variants
    -- within a price change request. Compare first price hash to second price hash. If changes = True, else False


    DECLARE @sql nVARCHAR(max)

    Declare @priceHash2 varchar(max);
    set @sql = ' Select  @priceHash2 = CONCAT(@priceHash2, ' +
               'convert(varchar(max),pvp.Price_Type,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Type_Term,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Start_Date,0),''|'', ' +
               'convert(varchar(max),pvp.Price_End_Date,0),''|'', ' +
               'convert(varchar(max),pvp.Price,0),''|'', ' +
               'convert(varchar(max),pvp.Currency,0),''|'', ' +
               'convert(varchar(max),pvp.Multi_Year_Eligible,0),''|'', ' +
               'convert(varchar(max),pvpt.Price_Tier_Maximum,0),''|'', ' +
               'convert(varchar(max),pvpt.Price_Tier_Minimum,0),''|'', ' +
			   'convert(varchar(max),pvpt.Price,0),''|'', ' +
               'convert(varchar(max),pvp.Price_Tier_Units,0),''|'', ' +
               'convert(varchar(max),pvp.Price_of_Incremental_User,0),''|'', ' +
               'convert(varchar(max),pvp.Customer_Type,0),''|'', ' +
               'convert(varchar(max),pvp.Service_Type,0),''('', ' +
               'row_number() over(order by pvp.Product_Variant_ID, pvp.Product_Price_ID asc),'')'') ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_ID ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'left outer join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pv.Product_Variant_ID = pvp.Product_Variant_ID ' +
               'left outer join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' pvpt on pvpt.Product_Price_ID = pvp.Product_Price_ID ' +
               'and pvp.Product_Variant_ID is not null ' +
               'and pvp.Product_Price_ID is not null ' +
               'and r.InternalRecordId = ' + cast(@internalRecordId as varchar);

    print @sql
    BEGIN TRY
        exec sp_executesql @sql, N'@priceHash2 varchar(max) out', @priceHash2 out
    END TRY
    BEGIN CATCH
        set @priceHash2 = 'none';
    END CATCH

    set @priceHash2 =  master.dbo.fn_varbintohexstr(HASHBYTES('SHA2_256', @priceHash2));
    SELECT  @priceHash2 as priceHash1, case when @priceHash1 = @priceHash2
                                                then 'False' else 'True' end as hasPriceChanges

END
go

