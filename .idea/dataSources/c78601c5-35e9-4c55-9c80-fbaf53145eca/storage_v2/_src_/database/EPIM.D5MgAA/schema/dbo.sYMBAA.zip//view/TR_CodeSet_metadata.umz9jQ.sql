
create view TR_CodeSet_metadata as 
    
    select cs.NAME, csd.CODE, csd.DESCRIPTION, csd.IS_ACTIVE_IND from B_CODE_SET_DETAIL as csd 
        inner join B_CODE_SET as cs on cs.CODE_SET_ID = csd.CODE_SET_ID
        inner join  B_CODE_SET_TYPE as cst on cst.CODE_SET_TYPE_ID = cs.CODE_SET_TYPE_ID
        where
         cst.name = 'TR'

go

grant select on TR_CodeSet_metadata to boomi
go

grant select on TR_CodeSet_metadata to informatica
go

grant select on TR_CodeSet_metadata to som
go

grant select on TR_CodeSet_metadata to apttus
go

grant select on TR_CodeSet_metadata to epmdev
go

grant select on TR_CodeSet_metadata to MDMAdmin
go

grant select on TR_CodeSet_metadata to ecmxread
go

grant select on TR_CodeSet_metadata to MPOPOV_TEST
go

grant select on TR_CodeSet_metadata to digital
go

