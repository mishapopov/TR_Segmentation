--#BEGIN#

create procedure [dbo].[epim_promote_from_item_list] (
	@itemIdList varchar(max),	
	@validationTypeInd int,
	@stagingRepositoryName nvarchar(255),
	@productionRepositoryName nvarchar(255),
	@otherProdAttrsToUpdateXml XML,
	@otherStagAttrsToUpdateXml XML,
	@statusProdToUpdateXml XML,
	@statusStagToUpdateXml XML,
	@saveProdAttrsXml XML,      
	@productionItemIdList varchar(max) OUTPUT,
	@resultLog nvarchar(max) OUTPUT )
As
BEGIN
	DECLARE @strSql NVARCHAR(max)
	DECLARE @itemId BIGINT
	DECLARE @stagingRepoId nvarchar(10)
	DECLARE @productionRepoId nvarchar(10)
	DECLARE @productionItemId varchar(max)	
	DECLARE @profileId INT
	DECLARE @numPriKeys INT
	DECLARE @index INT
	DECLARE @pkCol1Value nvarchar(512)
	DECLARE @pkCol2Value nvarchar(512)
	DECLARE @pkCol3Value nvarchar(512)
	DECLARE @pkCol4Value nvarchar(512)
	DECLARE @pkCol5Value nvarchar(512)
	DECLARE @attrData XML
	DECLARE @epim592StatusCols nvarchar(255)
	DECLARE @epim593StatusCols nvarchar(255)
	DECLARE @epim592StatusVals nvarchar(255)
	DECLARE @epim593StatusVals nvarchar(255)    
	DECLARE @keyValuesProd TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, AttrSystemName nvarchar(20), AttrValue nvarchar(512)) ;
	DECLARE @keyValuesStag TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, AttrSystemName nvarchar(20), AttrValue nvarchar(512)) ;
	DECLARE @statusValuesProd TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, StatusAttrName nvarchar(50), StatusValue nvarchar(512)) ;
	DECLARE @statusValuesStag TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, StatusAttrName nvarchar(50), StatusValue nvarchar(512)) ;
	DECLARE @saveAttrs TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, SysName nvarchar(50), AttrValue nvarchar(512)) ;
	DECLARE @saveAttrsToUse TABLE (SaveAttrId BIGINT IDENTITY(1,1)  PRIMARY KEY, SysName nvarchar(50), AttrValue nvarchar(512)) ;
	DECLARE @attrSystemName nvarchar(20)
	DECLARE @sysName nvarchar(20)
	DECLARE @attrValue nvarchar(512)
	DECLARE @statusAttrName nvarchar(50)
	DECLARE @statusValue nvarchar(512)
	DECLARE @priKeyWhereClause nvarchar(512)
	DECLARE @quotedValue nvarchar(max)
	DECLARE @profileIdProd int
	DECLARE @profileIdStag int
	DECLARE @epimVersion nvarchar(20)
	DECLARE @productionInsert int
	DECLARE @itemSql nvarchar(4000)
	DECLARE @attrVal nvarchar(max)
	declare @id int
	declare @params nvarchar(500)
	declare @saveAttrId bigint
	declare @hasErrorValue int
	declare @okToPromote int
	DECLARE @ParmDefinition as NVARCHAR(MAX)
	Declare @find nvarchar(5);
	Declare @replace nvarchar(5);
	DECLARE @separator_position INT
	DECLARE @separator CHAR(1)
	DECLARE @itemIdList_value varchar(max) 

	SET NOCOUNT ON;

	Set @find = ''+ char(39) +'';
	Set @replace = ''+char(39)+char(39)+'';
	Set @separator = ',';
	SET @productionItemId = '';

	INSERT INTO @saveAttrs (SysName, AttrValue) 
		SELECT ParamValues.systemNames.value('.','NVARCHAR(20)') as SysName, '' as AttrValue
		FROM @saveProdAttrsXml.nodes('/SaveAttr/systemNames/sysName') as ParamValues(systemNames);

	INSERT INTO @keyValuesProd (AttrSystemName, AttrValue) 
		SELECT ParamValues.keyValuePair.value('attrSystemName[1]','NVARCHAR(20)') as AttrSystemName,
		ParamValues.keyValuePair.value('attrValue[1]','NVARCHAR(512)') as AttrValue
		FROM @otherProdAttrsToUpdateXml.nodes('/Attrs/keyValuePair') as ParamValues(keyValuePair);

	INSERT INTO @keyValuesStag (AttrSystemName, AttrValue) 
		SELECT ParamValues.keyValuePair.value('attrSystemName[1]','NVARCHAR(20)') as AttrSystemName,
		ParamValues.keyValuePair.value('attrValue[1]','NVARCHAR(512)') as AttrValue
		FROM @otherStagAttrsToUpdateXml.nodes('/Attrs/keyValuePair') as ParamValues(keyValuePair);

	INSERT INTO @statusValuesProd (StatusAttrName, StatusValue) 
		SELECT ParamValues.keyValuePair.value('statusAttrName[1]','NVARCHAR(50)') as StatusAttrName,
		ParamValues.keyValuePair.value('statusValue[1]','NVARCHAR(512)') as StatusValue
		FROM @statusProdToUpdateXml.nodes('/Status/keyValuePair') as ParamValues(keyValuePair);

	INSERT INTO @statusValuesStag (StatusAttrName, StatusValue) 
		SELECT ParamValues.keyValuePair.value('statusAttrName[1]','NVARCHAR(50)') as StatusAttrName,
		ParamValues.keyValuePair.value('statusValue[1]','NVARCHAR(512)') as StatusValue
		FROM @statusStagToUpdateXml.nodes('/Status/keyValuePair') as ParamValues(keyValuePair);

	SET @epimVersion = 'epim593';
	SET @epim592StatusCols = 'item_action_status, publication_status, subscriber_state, message_id, recipient_state1, transaction_id';
	SET @epim593StatusCols = 'record_state, production_state, workflow_state, message_id, transaction_id';
	SET @epim592StatusVals = '0,0,0,null,0,null';
	SET @epim593StatusVals = '1,0,0,null,null';
	SET @resultLog = '';

	-- Get the repository IDs
	SELECT @stagingRepoId = cast(master_repository_id as nvarchar), @profileId = profile_id, @profileIdStag = profile_id from b_master_repository  with (nolock) where name = @stagingRepositoryName;
	SELECT @productionRepoId = cast(master_repository_id as nvarchar), @profileIdProd = profile_id from b_master_repository  with (nolock) where name = @productionRepositoryName;


	-- make sure both repositories use the same profile
	if (@profileIdProd <> @profileIdStag)
		SET @resultLog = 'ERROR:  profiles of these repositories do not match!';
	else
	BEGIN TRY

		-- Get the number of primary keys in the profile
		SELECT @numPriKeys = count(*) from b_format_attr  with (nolock) where profile_id=@profileId and pkey_seq_num>0;

		SET @itemIdList = @itemIdList + @separator

		-- Loop through the string searching for separtor characters
		WHILE PATINDEX('%' + @separator + '%', @itemIdList) <> 0 
		BEGIN
			-- patindex matches the a pattern against a string
			SELECT  @separator_position = PATINDEX('%' + @separator + '%',@itemIdList)
			SELECT  @itemIdList_value = LEFT(@itemIdList, @separator_position - 1)
			-- This is where you process the values passed.

			-- Replace this select statement with your processing
			-- @array_value holds the value of this element of the array
			SELECT  @itemId = @itemIdList_value
			-- This replaces what we just processed with and empty string
			SELECT  @itemIdList = STUFF(@itemIdList, 1, @separator_position, '')

			Delete FROM @saveAttrsToUse

			-- obtain the attrData, has_error_ind, pkCol1, pkCol2, etc values for this item
			SELECT @pkCol1Value = PK_COL_1,  @pkCol2Value = PK_COL_2, @pkCol3Value = PK_COL_3, @pkCol4Value = PK_COL_4, 
			@pkCol5Value = PK_COL_5, @attrData = attr_data, @hasErrorValue = has_error_ind  
			from b_master_repository_Item  with (nolock) where item_id = @itemId;

			SET @okToPromote = 1;
			-- check the has_error_ind if necessary
			--print('215: itemId = ' + cast(@itemId as nvarchar(20)) + ' hasErrorValue = ' + cast(@hasErrorValue as nvarchar(5)));
			if (@validationTypeInd = 1 and (@hasErrorValue is null or @hasErrorValue > 0)) SET @okToPromote = 0;
			--print('217: itemId = ' + cast(@itemId as nvarchar(20)) + ' okToPromote = ' + cast(@okToPromote as nvarchar(5)));

			if (@okToPromote = 1)
			BEGIN
				--print('221: itemId = ' + cast(@itemId as nvarchar(20)) + ' is being promoted ');

				-- check for null pk values
				--if (@pkCol1Value is null)  RAISERROR('NULL pri key value #1 for itemID: %s', 16, 1, @itemId);
				--if (@numPriKeys > 1 and @pkCol2Value is null) RAISERROR('NULL pri key value #2 for itemID: %s', 16, 1, @itemId);
				--if (@numPriKeys > 2 and @pkCol3Value is null) RAISERROR('NULL pri key value #3 for itemID: %s', 16, 1, @itemId);
				--if (@numPriKeys > 3 and @pkCol4Value is null) RAISERROR('NULL pri key value #4 for itemID: %s', 16, 1, @itemId);
				--if (@numPriKeys > 4 and @pkCol5Value is null) RAISERROR('NULL pri key value #5 for itemID: %s', 16, 1, @itemId);

				SET @productionInsert = 0;
				exec @priKeyWhereClause = dbo.epim_compose_priKey_where_clause @numPriKeys, @pkCol1Value, @pkCol2Value, @pkCol3Value, @pkCol4Value, @pkCol5Value;
				--print '232:' + @priKeyWhereClause

				-- determine if item already exists in the Production repository
				SET @id = null;
				SET @itemSql = 'select @id = item_id from b_master_repository_item  with (nolock) where attr_data is not null and repository_id = ' + 
				cast(@productionRepoId as nvarchar(50)) + cast(@priKeyWhereClause as nvarchar(500));
				SET @params = '@id int output';
				--print '239:' + @itemSql
				EXEC sp_executesql @itemSql, @params, @id OUTPUT;
				if (@id is null)
				SET @productionInsert = 1;

				-- create a history item for the Production item if it already exists in the Production repository

				if (@id is not null)
				BEGIN
					SET @strSql = 'insert into b_repository_item_history (MASTER_REPOSITORY_ID,ATTR_DATA, ' +
					'MODIFICATION_DATETIME, MODIFIED_BY, MODIFY_ACTION, ITEM_ID,RECLOCK,USER_LOGIN,';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
					SET @strSql = @strSql + ',STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO ) select ' + @productionRepoId + 
					',ATTR_DATA, ' +
					' case when bmi.LAST_UPDATE_DATETIME is null then bmi.CREATION_DATETIME else bmi.LAST_UPDATE_DATETIME end, ' +
					' case when bmi.LAST_UPDATE_BY is null then bmi.CREATED_BY else bmi.LAST_UPDATE_BY end, MODIFY_ACTION, ' +
					cast(@id as nvarchar) + ',bmi.RECLOCK,bu.LOGIN, ';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
					SET @strSql = @strSql + ', null,null,null  from b_master_repository_item bmi  with (nolock) , ' +
					'b_user bu  with (nolock) where item_id = ' + cast(@id as nvarchar) + ' and bu.user_id=case when bmi.last_update_by is null then bmi.created_by else bmi.last_update_by end';

					EXECUTE (@strSql); 
				END;

				-- INSERT the Staging item into Production if the item does not exist in Production
				if (@productionInsert = 1)
				BEGIN        
					SET @strSql = 'insert into b_master_repository_item (repository_id, has_error_ind, sync_action, ' +
					'sync_action_delete, is_duplicate,';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
					--print('272: production insert: ' + @strSql);
					--SET @strSql = @strSql + ', attr_data, ';
					SET @strSql = @strSql + ', ';
					SET @index=0;
					WHILE @index < @numPriKeys
					BEGIN
						SET @index = @index + 1;
						SET @strSql = @strSql + ' PK_COL_' + cast(@index as nvarchar) + ',';
					END

					SET @strSql = @strSql + 'creation_datetime, created_by, modify_action, attr_last_update_datetime, attr_last_update_by) values ( ' +
					@productionRepoId + ',' + cast(@hasErrorValue as varchar(max)) +',0,0,0,';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusVals;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusVals;

					-- DAS 6/9/2011  SET @strSql = @strSql + ',@my_attr_data, ';
					--SET @strSql = @strSql + ',cast(''' + replace( cast(@attrData as nvarchar(max)) ,@find,@replace) + ''' as XML), ';
					SET @strSql = @strSql + ',';
					SET @index=0;
					WHILE @index < @numPriKeys
					BEGIN
						SET @index = @index + 1;
						--IF @index = 1 SET @strSql = @strSql + '''' + replace(@pkCol1Value,@find,@replace) + ''',';
						--IF @index = 2 SET @strSql = @strSql + '''' + replace(@pkCol2Value,@find,@replace) + ''',';
						--IF @index = 3 SET @strSql = @strSql + '''' + replace(@pkCol3Value,@find,@replace) + ''',';
						--IF @index = 4 SET @strSql = @strSql + '''' + replace(@pkCol4Value,@find,@replace) + ''',';
						--IF @index = 5 SET @strSql = @strSql + '''' + replace(@pkCol5Value,@find,@replace) + ''',';


						if (@index = 1) 
						begin
							if (@pkCol1Value is null)
								SET @strSql = @strSql + ' NULL, ';
							else
								SET @strSql = @strSql + '''' + replace(@pkCol1Value,@find,@replace) + ''',';
						end
						if (@index = 2)
						begin
							if (@pkCol2Value is null)
								SET @strSql = @strSql + ' NULL, ';
							else
								SET @strSql = @strSql + '''' + replace(@pkCol2Value,@find,@replace) + ''',';
						end
						if (@index = 3) 
						begin
							if (@pkCol3Value is null)
								SET @strSql = @strSql + ' NULL, ';
							else
								SET @strSql = @strSql + '''' + replace(@pkCol3Value,@find,@replace) + ''',';
						end
						if (@index = 4) 
						begin
							if (@pkCol4Value is null)
								SET @strSql = @strSql + ' NULL, ';
							else
								SET @strSql = @strSql + '''' + replace(@pkCol4Value,@find,@replace) + ''',';
						end
						if (@index = 5)
						begin
							if (@pkCol5Value is null)
								SET @strSql = @strSql + ' NULL, ';
							else
								SET @strSql = @strSql + '''' + replace(@pkCol5Value,@find,@replace) + ''',';
						end

					END
					SET @strSql = @strSql + 'getDate(),1,''CREATE'',null,null); select @id = scope_identity()';

					--EXECUTE (@strSql); 
					-- DAS 6/9/2011  SET @ParmDefinition = N'@my_attr_data xml, @id int output' 
					SET @ParmDefinition = '@id int output' 
					--print('345: strSql = ' + @strSql)
					-- DAS 6/9/2011  EXEC sp_executesql  @strSql, @ParmDefinition,  @my_attr_data = @attrData, @id = @id OUTPUT;
					EXEC sp_executesql  @strSql, @ParmDefinition,  @id = @id OUTPUT;
					--print('348: newly inserted prod item: ' + cast(@id as nvarchar));
				END;

				-- before UPDATE item attr_data in Production, get any attr data to save

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrs );
				--print('354: saveAttrId: ' + cast(@saveAttrId as nvarchar));

				WHILE @saveAttrId is not null
				BEGIN
					SELECT @sysName = SysName from @saveAttrs where SaveAttrId = @saveAttrId;
					--print('359:sysName: ' + @sysName);
					if (@productionInsert = 1)
						SET @itemSql = 'select @attrVal=' + @sysName + ' from b_snapshot_' + @stagingRepoId + '  with (nolock)  where item_id = ' + cast(@itemId as nvarchar);
					else
						SET @itemSql = 'select @attrVal=' + @sysName + ' from b_snapshot_' + @productionRepoId + '  with (nolock)  where item_id = ' + cast(@id as nvarchar);

					EXEC sp_executesql @itemSql, @params = N'@attrVal nvarchar(max) OUTPUT', @attrVal = @attrVal OUTPUT;
					INSERT INTO @saveAttrsToUse (SysName, AttrValue) values (@sysName, @attrVal); 
					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrs WHERE  SaveAttrId > @saveAttrId)
					END
				--print '369: Loop of save attrs over'
				-- UPDATE item attr_data in Production
				if (@attrData is not null)
				BEGIN
					--print ('373:update item');
					SET @strSql = 'update b_master_repository_item set attr_last_update_datetime = getDate(), last_update_datetime = getDate(), ' +
					'modify_action=''update'', attr_data = @my_attr_data, has_error_ind = ' + cast(@hasErrorValue as varchar(max)) + 
					' where repository_id = ' + @productionRepoId + ' and item_id = ' + cast(@id as nvarchar);
					SET @ParmDefinition = N'@my_attr_data xml' 
					EXECUTE sp_executesql @strSql, @ParmDefinition,  @my_attr_data = @attrData
				END

				-- replace the saved attr data 

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrsToUse );

				WHILE @saveAttrId is not null
				BEGIN
					SELECT @sysName = SysName, @attrValue = AttrValue from @saveAttrsToUse where SaveAttrId = @saveAttrId;
					--print '388:' + convert(nvarchar(100), getdate(), 120) + ' Begin Loop in SaveAttrs to Use ' + @sysname
					if @attrValue IS NOT NULL
					begin
						SET @strSql = 'update b_master_repository_item set ' +
						'attr_data.modify(''replace value of (/Item/' + @sysName + 
						'/text())[1] with "' + @attrValue + '" '')  where attr_data is not null and repository_id = ' + @productionRepoId  +
						' and item_id = ' + cast(@id as varchar);

						EXECUTE (@strSql); 
						SET @strSql = 'update b_master_repository_item set ' +
						' attr_data.modify(''insert <' + @sysName + '>' + @attrValue +
						'</' + @sysName + '>  into (/Item)[1]'') where attr_data is not null and attr_data.exist(''/Item/' + @sysName + 
						''') !=1 and repository_id = ' + @productionRepoId  + ' and item_id = ' + cast(@id as varchar);

						EXECUTE (@strSql); 
					end
					if @attrValue IS NULL
					begin
						SET @strSql = 'update b_master_repository_item set ' +
						' attr_data.modify(''delete /Item/' + @sysName + '[1]'') where attr_data is not null and repository_id = ' + 
						@productionRepoId  + ' and item_id = ' + cast(@id as varchar);
												 EXECUTE (@strSql); 
						--print '411:' + convert(nvarchar(100), getdate(), 120) + ' UPDATE BMasterRepoItem when attrval is null is over' 
					end

					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @saveAttrsToUse WHERE  SaveAttrId > @saveAttrId)
				END
				--print '416: looping in save attr to use over'
				-- update otherAttributes in Production requested by the caller

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesProd );

				WHILE @saveAttrId is not null
				BEGIN
					select @attrSystemName = AttrSystemName, @attrValue = AttrValue from @keyValuesProd where SaveAttrId=@saveAttrId;
					--print '424:' + convert(nvarchar(100), getdate(), 120) + 'Begin looping in @keyValuesProd for @attrSystemName'
					if @attrValue IS NOT NULL
					begin

						SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						'attr_data.modify(''replace value of (/Item/' + @attrSystemName + 
						'/text())[1] with "' + @attrValue + '" '')  where attr_data is not null and repository_id = ' + @productionRepoId  +
						' and item_id = ' + cast(@id as nvarchar);

						EXECUTE (@strSql); 

						SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						' attr_data.modify(''insert <' + @attrSystemName + '>' + @attrValue +
						'</' + @attrSystemName + '>  into (/Item)[1]'') where attr_data is not null and attr_data.exist(''/Item/' + @attrSystemName + 
						''') !=1 and repository_id = ' + @productionRepoId  + ' and item_id = ' + cast(@id as nvarchar);
						EXECUTE (@strSql); 

					end
					--print '442: if @attrValue IS NOT NULL check over'

					if @attrValue IS NULL
					begin
						--print('446: null attrValue')
						SET @strSql = 'update b_master_repository_item set ' +
						' attr_data.modify(''delete /Item/' + @attrSystemName + '[1]'') where attr_data is not null and repository_id = ' + 
						@productionRepoId  + ' and item_id = ' + cast(@id as nvarchar);

						EXECUTE (@strSql); 
						--print '452:' + convert(nvarchar(100), getdate(), 120) + ' UPDATE BMasterRepoItem when attrval is null over' 
					end

					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesProd WHERE  SaveAttrId > @saveAttrId)
				END
				--print '457: looping in    @keyValuesProd over'
				-- update status values in Production requested by the caller

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesProd );

				WHILE @saveAttrId is not null
				BEGIN
					select @statusAttrName = StatusAttrName, @statusValue = StatusValue from @statusValuesProd where SaveAttrId=@saveAttrId;
					--print '465:' + convert(nvarchar(100), getdate(), 120) + ' begin looping in @statusValuesProd for ' + @statusAttrName
					exec @quotedValue = dbo.epim_compose_quoted_value @statusAttrName, @statusValue;

					SET @strSql = 'update b_master_repository_item set ' + @statusAttrName + ' = ' + @quotedValue + 
					' where repository_id = ' + @productionRepoId  + ' and item_id = ' + cast(@id as nvarchar);

					EXECUTE (@strSql);                     
					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesProd WHERE  SaveAttrId > @saveAttrId)
				END
				--print '474: Looping in @statusValuesProd over'
				-- if otherStagAttributes is not null, create a history item for the Staging item 

				if (LEN( CAST(@otherStagAttrsToUpdateXml as nvarchar(max))) > 20)
				BEGIN

					SET @strSql = 'IF EXISTS(select item_id from b_master_repository_item  with (nolock) where repository_id = ' + @stagingRepoId +
					' and item_id = ' + cast(@itemId as varchar) + ' )  insert into b_repository_item_history (MASTER_REPOSITORY_ID,ATTR_DATA, ' +
					'MODIFICATION_DATETIME, MODIFIED_BY, MODIFY_ACTION, ITEM_ID,RECLOCK,USER_LOGIN,';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
					SET @strSql = @strSql + ',STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO ) select ' + @stagingRepoId + ',ATTR_DATA, ' +
					' case when bmi.LAST_UPDATE_DATETIME is null then bmi.CREATION_DATETIME else bmi.LAST_UPDATE_DATETIME end, ' +
					' case when bmi.LAST_UPDATE_BY is null then bmi.CREATED_BY else bmi.LAST_UPDATE_BY end, MODIFY_ACTION, ' +
					'(select item_id from b_master_repository_item  with (nolock) where repository_id = ' + @stagingRepoId + 
					' and item_id = ' + cast(@itemId as varchar) +  ' ),bmi.RECLOCK,bu.LOGIN, ';
					IF @epimVersion = 'epim592' SET @strSql = @strSql + @epim592StatusCols;
					IF @epimVersion = 'epim593' SET @strSql = @strSql + @epim593StatusCols;
					SET @strSql = @strSql + ', null,null,null  from b_master_repository_item bmi  with (nolock) , ' +
												'b_user bu  with (nolock) where item_id = ' + cast(@itemId as varchar) + ' and bu.user_id=case when bmi.last_update_by is null then bmi.created_by else bmi.last_update_by end';

					--print '495:' + convert(nvarchar(100), getdate(), 120) + 'inside if (LEN( CAST(@otherStagAttrsToUpdateXml as nvarchar(max))) > 20) ' + @strSql 
					EXECUTE (@strSql); 
					--print '497:' + convert(nvarchar(100), getdate(), 120) +  + 'inside if (LEN( CAST(@otherStagAttrsToUpdateXml as nvarchar(max))) > 20) over'
				END

				-- update otherAttributes in Staging requested by the caller

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesStag );

				WHILE @saveAttrId is not null
				BEGIN
					select @attrSystemName = AttrSystemName, @attrValue = AttrValue from @keyValuesStag where SaveAttrId=@saveAttrId;
					--print '507:' + convert(nvarchar(100), getdate(), 120) + ' looping in @keyValuesStag for '+ @attrSystemName
					if @attrValue IS NOT NULL
					begin                
						SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						'attr_data.modify(''replace value of (/Item/' + @attrSystemName + 
						'/text())[1] with "' + @attrValue + '" '')  where attr_data is not null and repository_id = ' + @stagingRepoId  +
						' and item_id = ' + cast(@itemId as varchar);
						--print '514: update Staging otherAttributes: ' + @strSql;
						EXECUTE (@strSql); 

						SET @strSql = 'update b_master_repository_item set LAST_UPDATE_DATETIME = getDate(), ATTR_LAST_UPDATE_DATETIME = getDate(), ' +
						'attr_data.modify(''insert <' + @attrSystemName + '>' + @attrValue +
						'</' + @attrSystemName + '>  into (/Item)[1]'') where attr_data is not null and attr_data.exist(''/Item/' + @attrSystemName + 
						''') !=1 and repository_id = ' + @stagingRepoId  + ' and item_id = ' + cast(@itemId as varchar);

						EXECUTE (@strSql); 
					end
					if @attrValue IS NULL
					begin
						--print('526: null attrValue')
						SET @strSql = 'update b_master_repository_item set ' +
						' attr_data.modify(''delete /Item/' + @attrSystemName + '[1]'') where attr_data is not null and repository_id = ' + 
						@stagingRepoId + ' and item_id = ' + cast(@itemId as varchar);

						--print('531: @strSql: ' + @strSql)
						EXECUTE (@strSql); 
					end

					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @keyValuesStag WHERE  SaveAttrId > @saveAttrId)
				END
				--print '537: looping in @keyvaluesStag over'
				-- update status values in Staging requested by the caller

				SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesStag );

				WHILE @saveAttrId is not null
				BEGIN
					select @statusAttrName = StatusAttrName, @statusValue = StatusValue from @statusValuesStag where SaveAttrId=@saveAttrId;
					--print '545:' + convert(nvarchar(100), getdate(), 120) + 'looping in @statusValuesStag for ' + @statusAttrName
					exec @quotedValue = dbo.epim_compose_quoted_value @statusAttrName, @statusValue;

					SET @strSql = 'update b_master_repository_item set ' + @statusAttrName + ' = ' + @quotedValue + 
					' where repository_id = ' + @stagingRepoId  + ' and item_id = ' + cast(@itemId as varchar);
					--print '550: ' + @strSql
					EXECUTE (@strSql);                     

					SET @saveAttrId = (SELECT MIN(SaveAttrId) FROM  @statusValuesStag WHERE  SaveAttrId > @saveAttrId)
				END
				--print '549:'
				--print '557: @productionItemId='+ @productionItemId
				--print '555: saving id =' + cast(@id as varchar(max))
				if (@productionItemId is null) set @productionItemId='';
				if (@productionItemId ='') 
					set @productionItemId=cast(@id as varchar(max));
				else
					set @productionItemId = @productionItemId + @separator + cast(@id as varchar(max));
				--print '557: @productionItemId='+ @productionItemId                    
				SET @productionItemIdList = @productionItemId;
			END  
			--print '561: build snapshot'+ @productionItemId                    
			if (@productionRepoId is not null)
			begin
				if (@productionItemIdList is not null)
				begin
					if (@productionItemIdList <>'')
					begin
					exec epim_update_snapshot_view @productionRepoId, @productionItemIdList					
					end
				end
			end	
		END
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
		@ErrorSeverity = ERROR_SEVERITY(),
		@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;

	--SELECT @resultLog
	--print('581: RESULT LOG:' + @resultLog)

END;
go

