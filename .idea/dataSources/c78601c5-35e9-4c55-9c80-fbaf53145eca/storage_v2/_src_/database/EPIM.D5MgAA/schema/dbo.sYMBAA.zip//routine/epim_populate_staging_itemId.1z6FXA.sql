
--#BEGIN#

-- This stored procedure is used to populate the STAGING_ITEM_ID value in items from 
-- a Production repository with the corresponding Staging repository ITEM_ID.
--
-- The following input parameters are expected:
--	savedSetId			- id of the savedSet from the Staging repository containing items to "promote"
--	stagingRepositoryId             - id of the Staging repository
--	productionRepositoryId          - id of the Production repository where items will be "promoted" to
--	debug				- indicator for debugging
--                                    0 = No, 1 = yes
--
--
--
--

CREATE procedure [dbo].[epim_populate_staging_itemId] (
	@stagingRepoId bigint,
	@productionRepoId bigint,
	@profileId bigint,
	@savedSetId bigint,
	@debug int)
As
BEGIN

	DECLARE @pkey1 bigint;
	DECLARE @pkey2 bigint;
	DECLARE @pkey3 bigint;
	DECLARE @pkey4 bigint;
	DECLARE @pkey5 bigint;
	DECLARE @pkey1NullInd bigint;
	DECLARE @pkey2NullInd bigint;
	DECLARE @pkey3NullInd bigint;
	DECLARE @pkey4NullInd bigint;
	DECLARE @pkey5NullInd bigint;
	DECLARE @pkey1DataType nvarchar(32);
	DECLARE @pkey2DataType nvarchar(32);
	DECLARE @pkey3DataType nvarchar(32);
	DECLARE @pkey4DataType nvarchar(32);
	DECLARE @pkey5DataType nvarchar(32);
	DECLARE @strSql NVARCHAR(max);
	DECLARE @strSqlLookup NVARCHAR(max);
	DECLARE @RowsAffected int;
	DECLARE @elapseStartTime DATETIME;
	DECLARE @startTime DATETIME;
	DECLARE @stopTime DATETIME;
	DECLARE @id BIGINT;
	DECLARE @lookupId int;
	DECLARE @startItemId int;
	DECLARE @endItemId int;
	DECLARE @stagingSql nvarchar(max);
	DECLARE @strSqlLookupPart1 nvarchar(max);
	DECLARE @strTemp nvarchar(max);
	DECLARE @strTempSave nvarchar(max);

	if (@debug<>1) SET @debug=null; 
	if (@debug is null) SET NOCOUNT ON;	

	SET @elapseStartTime = CURRENT_TIMESTAMP;

	BEGIN TRY

		-- check saved set
		if (@savedSetId is null)  RAISERROR('Saved Set name must be defined: %s', 16, 1, @stagingRepoId );
		
		--get primary keys of profile	
		SELECT @pkey1=FORMAT_ATTR_ID, @pkey1NullInd=NULL_IND,@pkey1DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=1;
		SELECT @pkey2=FORMAT_ATTR_ID, @pkey2NullInd=NULL_IND,@pkey2DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=2;
		SELECT @pkey3=FORMAT_ATTR_ID, @pkey3NullInd=NULL_IND,@pkey3DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=3;
		SELECT @pkey4=FORMAT_ATTR_ID, @pkey4NullInd=NULL_IND,@pkey4DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=4;
		SELECT @pkey5=FORMAT_ATTR_ID, @pkey5NullInd=NULL_IND,@pkey5DataType=DATA_TYPE FROM B_FORMAT_ATTR with (nolock) WHERE PROFILE_ID=@profileId AND PKEY_SEQ_NUM=5;
		if (@pkey1 is null)  RAISERROR('Primary key not found: %s', 16, 1, @stagingRepoId);

		--create temp table of itemids for stage and prod
		if (@debug is not null) PRINT 'Create temp table;';
		CREATE TABLE #StagingItemIds
		(
			ID BIGINT IDENTITY(1,1) NOT NULL,
			STAGING_ITEM_ID BIGINT
			PRIMARY KEY (ID)
		)
		CREATE TABLE #StageProdRecordIds
		(
			ID BIGINT IDENTITY(1,1) NOT NULL,
			STAGE_ITEM_ID BIGINT,
			PROD_ITEM_ID BIGINT
			PRIMARY KEY (ID)
		)


		--populate temp table
		if (@debug is not null) PRINT 'Add to temp table';
		SET @strSql = 'INSERT INTO #StageProdRecordIds (STAGE_ITEM_ID, PROD_ITEM_ID) ';
		SET @strSqlLookup = 'SELECT ts.ITEM_ID, tp.ITEM_ID FROM ';
		SET @strSqlLookup = @strSqlLookup + '(SELECT s.ITEM_ID, s.PK_COL_1 as pk1 ';
		SET @strSqlLookup = @strSqlLookup + dbo.epim_compose_priKey_lookup ('s', @pkey2, @pkey3, @pkey4, @pkey5,
                                                          @pkey2NullInd, @pkey3NullInd, @pkey4NullInd, @pkey5NullInd);
		SET @strSqlLookup = @strSqlLookup + ' FROM B_MASTER_REPOSITORY_ITEM AS s with (nolock) ';
		SET @strSqlLookupPart1 = 'SELECT s.ITEM_ID FROM B_MASTER_REPOSITORY_ITEM AS s with (nolock) ';
		SET @strTemp = ' INNER JOIN B_SAVED_SET_ITEM AS ssi with (nolock) ON s.ITEM_ID=ssi.ITEM_ID ';
		SET @strTemp = @strTemp + ' WHERE (s.REPOSITORY_ID = ' + CAST(@stagingRepoId as varchar) + ') ';
		SET @strTemp = @strTemp + ' AND (ssi.SAVED_SET_ID = ' + CAST(@savedSetId as varchar) + ')'
		SET @strSqlLookup = @strSqlLookup + @strTemp;
		SET @strSqlLookupPart1 = @strSqlLookupPart1 + @strTemp;
		SET @strSqlLookup = @strSqlLookup + ' AND (s.item_id>=@startItemId  AND s.item_id<@endItemId )) ts ';
		 
		SET @strSqlLookup = @strSqlLookup + ' INNER JOIN ';
		SET @strSqlLookup = @strSqlLookup + ' (SELECT p.ITEM_ID, p.PK_COL_1 as pk1 ';
		SET @strSqlLookup = @strSqlLookup + dbo.epim_compose_priKey_lookup ('p', @pkey2, @pkey3, @pkey4, @pkey5,
                                                          @pkey2NullInd, @pkey3NullInd, @pkey4NullInd, @pkey5NullInd);
		SET @strSqlLookup = @strSqlLookup + ' FROM B_MASTER_REPOSITORY_ITEM AS p with (nolock) ';
		SET @strSqlLookup = @strSqlLookup + ' WHERE (p.REPOSITORY_ID = ' + CAST(@productionRepoId as varchar) + ') ';
		SET @strSqlLookup = @strSqlLookup + ') tp ';
		SET @strSqlLookup = @strSqlLookup + ' ON ts.pk1=tp.pk1 ';
		if (@pkey2 is not null) SET @strSqlLookup = @strSqlLookup + ' AND ts.pk2=tp.pk2 ';
		if (@pkey3 is not null) SET @strSqlLookup = @strSqlLookup + ' AND ts.pk3=tp.pk3 ';
		if (@pkey4 is not null) SET @strSqlLookup = @strSqlLookup + ' AND ts.pk4=tp.pk4 ';
		if (@pkey5 is not null) SET @strSqlLookup = @strSqlLookup + ' AND ts.pk5=tp.pk5 ';
		SET @strSql = @strSql + @strSqlLookup;
		if (@debug is not null) PRINT ('strSql = ' + @strSql);
		if (@debug is not null) PRINT ('strSqlLookupPart1 = ' + @strSqlLookupPart1);
		
		--populate temp table containing just staging item_ids
		SET @stagingSql = 'INSERT INTO #StagingItemIds (STAGING_ITEM_ID) ' + @strSqlLookupPart1 + ' order by s.item_id';
		if (@debug is not null) PRINT @stagingSql;
		EXEC (@stagingSql);

		--populate StageProdRecordIds temp table in batches 
		SET @strTempSave = @strSql;
		SET @lookupId = (SELECT MIN(Id) FROM  #StagingItemIds );
		WHILE @lookupId is not null
		BEGIN
		        SET @strSql = @strTempSave;
			SET @startItemId = (select STAGING_ITEM_ID from #StagingItemIds where Id = @lookupId);
			SET @endItemId = (select STAGING_ITEM_ID from #StagingItemIds where Id = (@lookupId + 20000));
			if (@endItemId is null)
			   SET @endItemId = (select STAGING_ITEM_ID from #StagingItemIds where Id = (select max(id) from #StagingItemIds)) + 1;
			if (@debug is not null) PRINT ('startItemId = ' + cast(@startItemId as nvarchar(max)));
			if (@debug is not null) PRINT ('endItemId = ' + cast(@endItemId as nvarchar(max)));
			SET @startTime = CURRENT_TIMESTAMP;
			SET @strSql = replace(@strSql, '@startItemId', cast(@startItemId as nvarchar));
			SET @strSql = replace(@strSql, '@endItemId', cast(@endItemId as nvarchar));
			if (@debug is not null) PRINT @strSql;
			EXEC (@strSql);	
		
			SET @lookupId = (SELECT MIN(Id) FROM  #StagingItemIds WHERE  Id >= @lookupId + 20000);
		END
		
		SET @stopTime = CURRENT_TIMESTAMP;
		if (@debug is not null) PRINT 'Query Time: ' +  CAST(DATEDIFF(MS, @startTime, @stopTime) as varchar)+ '(ms)';
		if (@debug is not null) PRINT 'Elapsed Time: ' +  CAST(DATEDIFF(MS, @elapseStartTime, @stopTime) as varchar)+ '(ms)';


		if (@debug is not null)
		BEGIN
			SELECT @RowsAffected=COUNT(*) FROM #StageProdRecordIds with (nolock)WHERE PROD_ITEM_ID IS NOT NULL;
			PRINT 'Found ' + cast(@RowsAffected as varchar) + ' staging production record matches to update';
		END


		if (@debug is not null) PRINT 'Update prod with staging_item_id';
		SET @Id = (SELECT MIN(id) FROM  #StageProdRecordIds );
		WHILE @Id is not null
		BEGIN
			SET @startTime = CURRENT_TIMESTAMP;
			UPDATE B_MASTER_REPOSITORY_ITEM
			SET STAGING_ITEM_ID =  s.ITEM_ID
			FROM  B_MASTER_REPOSITORY_ITEM INNER JOIN  #StageProdRecordIds AS spr with (nolock) ON
				B_MASTER_REPOSITORY_ITEM.ITEM_ID = spr.PROD_ITEM_ID INNER JOIN
				B_MASTER_REPOSITORY_ITEM AS s with (nolock) ON spr.STAGE_ITEM_ID = s.ITEM_ID
			WHERE B_MASTER_REPOSITORY_ITEM.REPOSITORY_ID= @productionRepoId 
				AND (spr.id>=@id AND spr.id< (@id + 50000));
			SET @stopTime = CURRENT_TIMESTAMP;
			if (@debug is not null) PRINT 'Query Time: ' +  CAST(DATEDIFF(MS, @startTime, @stopTime) as varchar)+ '(ms)';
			if (@debug is not null) PRINT 'Elapsed Time: ' +  CAST(DATEDIFF(MS, @elapseStartTime, @stopTime) as varchar)+ '(ms)';	
			SET @Id = (SELECT MIN(id) FROM  #StageProdRecordIds WHERE  id >= @Id + 50000);
		END

		if (@debug is not null) PRINT 'Drop Temp table #StageProdRecordIds';
		SET @startTime = CURRENT_TIMESTAMP;
		DROP TABLE #StageProdRecordIds;
		SET @stopTime = CURRENT_TIMESTAMP;
		if (@debug is not null) PRINT 'Query Time: ' +  CAST(DATEDIFF(MS, @startTime, @stopTime) as varchar)+ '(ms)';
		if (@debug is not null) PRINT 'Elapsed Time: ' +  CAST(DATEDIFF(MS, @elapseStartTime, @stopTime) as varchar)+ '(ms)';
		

	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;


		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
	END CATCH;
		
END;
go

