
create procedure epim_update_bulk_from_sql_timeout 
    (@repositoryNameP nvarchar(200), @attrNameP nvarchar(200), @attrValueP nvarchar(400), 
	@sqlqueryP nvarchar(max), @optionsP nvarchar(max), @lockTimeout int)
as  
begin


  declare @attrSql nvarchar(max);
  declare @attrSysName nvarchar(20);
  declare @repositoryId bigint;
  declare @isDelete int;
  declare @shouldCreateHistory int;
  declare @optionsIndex1 int;
  declare @optionsIndex2 int;
  declare @optionsValue nvarchar(200);
  declare @dateStr nvarchar(200);
  declare @Resource int;
  DECLARE @includeKV bigint;
  DECLARE @kvName nvarchar(max);
  declare @fmtAttrIdFromSysName integer;
  declare @attrRealName nvarchar(max);
  declare @attrRestrictedName nvarchar(max);

    
  BEGIN TRAN T1
  
  EXEC sp_getapplock @Resource = 'epim_update_bulk_from_sql', @Lockmode = 'Exclusive', @LockTimeout = @lockTimeout
  print ('sp_getapplock result is: ' + cast(@Resource as nvarchar))   
	   
  set @shouldCreateHistory = 0;
  set @dateStr = '';
       
  if (@optionsP is null or len(@optionsP)=0)
     set @shouldCreateHistory = 0;
  else
  begin
     -- look for CreateHistory tag
     set @optionsIndex1 = CHARINDEX('<CreateHistory>', @optionsP);
     if (@optionsIndex1 > 0)
     begin
        set @optionsIndex2 = CHARINDEX('</CreateHistory>', @optionsP);
        set @optionsValue = SUBSTRING(@optionsP, @optionsIndex1+15, @optionsIndex2);
        print ('createHistoryValue = ' + @optionsValue);
        set @optionsValue = UPPER(LTRIM(@optionsValue));
        print ('createHistoryValue = ' + @optionsValue);
        if (LEFT(@optionsValue,1) = 'Y')
           set @shouldCreateHistory = 1;
     end
  end
  print ('shouldCreateHistory = ' + cast(@shouldCreateHistory as nvarchar));
      
  if (@optionsP is null or len(@optionsP)=0)
     set @dateStr = '';
  else
  begin
     -- look for ModifyDate tag
     set @optionsIndex1 = CHARINDEX('<ModifyDate>', @optionsP);
     if (@optionsIndex1 > 0)
     begin
        set @optionsIndex2 = CHARINDEX('</ModifyDate>', @optionsP);
        set @optionsValue = SUBSTRING(@optionsP, @optionsIndex1+12, @optionsIndex2);
        print ('ModifyDateValue = ' + @optionsValue);
        set @optionsValue = UPPER(LTRIM(@optionsValue));
        print ('ModifyDateValue = ' + @optionsValue);
        if (LEFT(@optionsValue,1) = 'Y')
           set @dateStr = 'attr_last_update_datetime = getDate(), last_update_datetime = getDate(), ';
        if (@shouldCreateHistory = 1) 
           set @dateStr = @dateStr + 'modify_action = ''update'', ';
     end
  end
  print ('dateStr = ' + @dateStr);

  if (@attrValueP is null or len(@attrNameP)=0 or len(@attrValueP)=0)
     set @isDelete = 1;
      
  select @attrSysName='F_'+cast(f.FORMAT_ATTR_ID	as nvarchar(20)), @repositoryId=m.MASTER_REPOSITORY_ID
  from B_FORMAT_ATTR f, B_MASTER_REPOSITORY m, B_REPOSITORY_FMT_ATTR_MAPPING mp
  where f.FORMAT_ATTR_ID=mp.FORMAT_ATTR_ID 
       and m.MASTER_REPOSITORY_ID=mp.MASTER_REPOSITORY_ID
       and m.NAME=@repositoryNameP
       and f.NAME=@attrNameP
       
  print @attrSysName;
   
   
  if (@isDelete = 1) 
  begin
   set @attrSql = 'update b_master_repository_item set ' +
				'attr_data.modify(''delete /Item/' + @attrSysName + 
				''') where repository_id = ' + cast(@repositoryId as nvarchar(20)) +
				' and item_id in ('+@sqlqueryP+') and attr_data is not null';
   print @attrSql;
   exec (@attrSql);
				
   -- set to null in snapshot
   if exists(select * from INFORMATION_SCHEMA.columns where TABLE_NAME='B_SNAPSHOT_'+cast(@repositoryId as nvarchar(20)) and COLUMN_NAME=@attrSysName)
   begin
     set @attrSql = 'update B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+' set '+@attrSysName+'=null'+
         ', DATA_LAST_UPDATE_DATETIME=getDate() where item_id in ('+@sqlqueryP+')';
     print @attrSql;
     exec (@attrSql);
    end
    else
	begin
	    SELECT @includeKV = INCLUDE_SNAPSHOT_KV_IND from B_MASTER_REPOSITORY where master_repository_id = @repositoryId;
	    if (@includeKV is null)
		    SET @includeKV = 0;
	    if (@includeKV = 1)
	    BEGIN
			SET @kvName = 'B_SNAPSHOT_' + CAST(@repositoryId as varchar) + '_KV';
			SELECT @includeKV = id from sysobjects where name = @kvName;
			if (@includeKV is null)
				SET @includeKV = 0;
			if (@includeKV > 0)
			BEGIN
		    	SET @fmtAttrIdFromSysName = cast(substring(@attrSysName, 3, len(@attrSysName)) as integer);
		    	SELECT @attrRealName = name, @attrRestrictedName = restricted_name from B_FORMAT_ATTR where format_attr_id=@fmtAttrIdFromSysName;
				if (@attrRestrictedName is null)
			    	set @attrRestrictedName = '';
		    	set @attrSql = 'delete from B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+'_KV where KeyName=''' +
		        	replace(@attrRealName,'''','''''') + ''' and item_id in ('+@sqlqueryP+')';
		    	print ' delete from snapshot_KV: ' + @attrSql;
		    	exec (@attrSql);
		
		    	set @attrSql = 'insert into B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+'_KV (ITEM_ID, KeyName,KeyRestrictedName,KeyValue) ' +
			    	' select item_id, ''' + replace(@attrRealName,'''','''''') + ''',''' + @attrRestrictedName + ''', null from ('+@sqlqueryP+') tmp';
		    	print ' insert into snapshot_KV: ' + @attrSql;
		    	exec (@attrSql);
			END
	    END
    end
  end
  -- else update
  else	
  begin
  
    if (@shouldCreateHistory = 1) 
    begin
       set @attrSql = 'declare @history table(item_history_id bigint, item_id bigint) insert into b_repository_item_history( MASTER_REPOSITORY_ID,ATTR_DATA, MODIFICATION_DATETIME, MODIFIED_BY, MODIFY_ACTION, ITEM_ID,RECLOCK,USER_LOGIN,RECORD_STATE,PRODUCTION_STATE,WORKFLOW_STATE, MESSAGE_ID,TRANSACTION_ID,STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO) ' +
	'output INSERTED.repository_item_history_id, INSERTED.item_id into @history select REPOSITORY_ID,ATTR_DATA, case when bmi.LAST_UPDATE_DATETIME is null then bmi.CREATION_DATETIME else bmi.LAST_UPDATE_DATETIME end, case when bmi.LAST_UPDATE_BY is null then bmi.CREATED_BY else bmi.LAST_UPDATE_BY end, MODIFY_ACTION, ITEM_ID,bmi.RECLOCK,bu.LOGIN,RECORD_STATE,PRODUCTION_STATE,WORKFLOW_STATE, MESSAGE_ID,TRANSACTION_ID,STATE_UPDATE_TIME,STATE_UPDATE_MSG, EXTERNAL_SESSION_INFO ' +
	'from b_master_repository_item bmi, b_user bu where item_id in ('+@sqlqueryP+')' + 
	' and (bu.user_id = bmi.LAST_UPDATE_BY or bu.user_id = bmi.CREATED_BY) select * from @history';
       print @attrSql;
 
       exec (@attrSql);
    end

  -- update epim xml
  set @attrSql = 'update b_master_repository_item set ' + @dateStr +
				'attr_data.modify(''replace value of (/Item/' + @attrSysName + 
				'/text())[1] with "'+@attrValueP+'" '')  where repository_id = ' + cast(@repositoryId as nvarchar(20)) +
				' and item_id in ('+@sqlqueryP+') and attr_data is not null';
  print @attrSql;
 
  exec (@attrSql);
  
  -- do insert if needed
  set @attrSql = 'update b_master_repository_item set ' + @dateStr +
				' attr_data.modify(''insert <' + @attrSysName + '>' +@attrValueP+
				'</' + @attrSysName + '>  into (/Item)[1]'') where repository_id = ' + cast(@repositoryId as nvarchar(20)) + 
				' and item_id in ('+@sqlqueryP+') and attr_data is not null and attr_data.exist(''/Item/' + @attrSysName + 
				''') !=1';
  print @attrSql;
  exec (@attrSql);
  
  -- update snapshot table column 
  if exists(select * from INFORMATION_SCHEMA.columns where TABLE_NAME='B_SNAPSHOT_'+cast(@repositoryId as nvarchar(20)) and COLUMN_NAME=@attrSysName)
  begin
     set @attrSql = 'update B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+' set '+@attrSysName+'='''+@attrValueP+''''+
         ', DATA_LAST_UPDATE_DATETIME=getDate() where item_id in ('+@sqlqueryP+')';
     print @attrSql;
     exec (@attrSql);
  end
    else
	begin
	    SELECT @includeKV = INCLUDE_SNAPSHOT_KV_IND from B_MASTER_REPOSITORY where master_repository_id = @repositoryId;
	    if (@includeKV is null)
		    SET @includeKV = 0;
	    if (@includeKV = 1)
	    BEGIN
			SET @kvName = 'B_SNAPSHOT_' + CAST(@repositoryId as varchar) + '_KV';
			SELECT @includeKV = id from sysobjects where name = @kvName;
			if (@includeKV is null)
				SET @includeKV = 0;
			if (@includeKV > 0)
			BEGIN
		        SET @fmtAttrIdFromSysName = cast(substring(@attrSysName, 3, len(@attrSysName)) as integer);
		        SELECT @attrRealName = name, @attrRestrictedName = restricted_name from B_FORMAT_ATTR where format_attr_id=@fmtAttrIdFromSysName;
			    if (@attrRestrictedName is null)
			        set @attrRestrictedName = '';
		        set @attrSql = 'delete from B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+'_KV where KeyName=''' +
		            replace(@attrRealName,'''','''''') + ''' and item_id in ('+@sqlqueryP+')';
		        print ' delete from snapshot_KV: ' + @attrSql;
		        exec (@attrSql);
		
		        set @attrSql = 'insert into B_SNAPSHOT_'+CAST(@repositoryId as nvarchar(20))+'_KV (ITEM_ID, KeyName,KeyRestrictedName,KeyValue) ' +
			        ' select item_id, ''' + replace(@attrRealName,'''','''''') + ''',''' + @attrRestrictedName + ''', '''+@attrValueP+''' from ('+@sqlqueryP+') tmp';
		        print ' insert into snapshot_KV: ' + @attrSql;
		        exec (@attrSql);
			END
	    END
    end
 
  end
  
  EXEC sp_releaseapplock @Resource = 'epim_update_bulk_from_sql'
  COMMIT TRAN T1
 end
go

