CREATE   PROCEDURE [dbo].[MPOPOV_TEST_PROC] @tr_db_user_name varchar(128)
AS
BEGIN
    declare @query varchar(max);

    DECLARE cursor_TR_DB_PRIVS CURSOR
        FOR
        select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'EPMPROD'
          and tr.tr_db_user_name = @tr_db_user_name
          and (t2.table_name like 'PRODUCT%_'
            or t2.table_name like 'REFERENCE_%')
        union all
        select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'EPMSTG'
          and tr.tr_db_user_name = @tr_db_user_name
          and (t2.table_name like '%KV'
            or t2.table_name like 'REFERENCE_%')
        union all
        select 'grant all on [ECMX_Delta_Control] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'EPMSTG'
          and t2.table_name = 'ECMX_Delta_Control'
        union all
        select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'ECMXPROD'
          and tr.tr_db_user_name = @tr_db_user_name
          and (t2.table_name like 'EC%_PRODUCTION'
            or t2.table_name like 'EC%_SOURCE'
            or t2.table_name like 'REFERENCE_%')
        union all
        select 'grant select on [' + t2.table_name + '] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'ECMXSTG'
          and tr.tr_db_user_name = @tr_db_user_name
          and (t2.table_name like 'EC%_STAGING'
            or t2.table_name like '%_KV')
        union all
        select 'grant all on [ECMX_Delta_Control] to ' + tr.tr_db_user_name + ';' as query
        from tr_db_users tr,
             INFORMATION_SCHEMA.TABLES t2
        where tr.tr_db_user_role = 'ECMXSTG'
          and tr.tr_db_user_name = @tr_db_user_name

          and t2.table_name = 'ECMX_Delta_Control'
    OPEN cursor_TR_DB_PRIVS;
    FETCH NEXT FROM cursor_TR_DB_PRIVS INTO
        @query;
    WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT @query;
            FETCH NEXT FROM cursor_TR_DB_PRIVS INTO @query
            exec (@query)
        END;
    CLOSE cursor_TR_DB_PRIVS;
    DEALLOCATE cursor_TR_DB_PRIVS;
end
go

