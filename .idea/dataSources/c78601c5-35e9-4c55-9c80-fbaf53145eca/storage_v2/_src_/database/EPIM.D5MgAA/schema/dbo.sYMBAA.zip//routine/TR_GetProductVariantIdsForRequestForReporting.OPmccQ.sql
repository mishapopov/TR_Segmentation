
  CREATE PROCEDURE [dbo].[TR_GetProductVariantIdsForRequestForReporting]
  	@requestId VARCHAR(200),  -- Internal Record ID for the Request
  	@source VARCHAR(10)	-- Name of source (Build, Clone, Change, State)
    AS BEGIN
    
        -- TR_GetProductVariantIdsForRequestForReporting - Retrieves a delimited list of Product Variant IDs that
        -- are in the request for reporting purposes.
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_GetProductVariantIdsForRequestForReporting '5713512','State'
        --
        -- Workflow Activity:
        --
        -- EXEC TR_GetProductVariantIdsForRequestForReporting '%itemIds%','%source%'
        
        DECLARE @sql NVARCHAR(max)
        DECLARE @productVariant VARCHAR(max)
        DECLARE @productVariantIds VARCHAR(max)

        -----------------------------------------------------------------------------
        -- Get list of product variant records by Product Variant ID
        -----------------------------------------------------------------------------
        
        set @sql = 'SELECT @productVariant = isnull(STUFF((select '','' + cast(pv.Product_Variant_ID as VARCHAR) as [text()] ' +
		'from Request_' + @source + ' r ' +
		'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
		'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
		'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
		print 'productVariantIds - ' + @sql;
		exec sp_executesql @sql, N'@productVariant varchar(max) out', @productVariant out
   
        -----------------------------------------------------------------------------
        -- Get list of product variant records by Internal Record ID
        -----------------------------------------------------------------------------
        
        set @sql = 'SELECT @productVariantIds = isnull(STUFF((select '','' + cast(pv.InternalRecordId as VARCHAR) as [text()] ' +
		'from Request_' + @source + ' r ' +
		'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
		'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
		'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
		print 'productVariantIds - ' + @sql;
		exec sp_executesql @sql, N'@productVariantIds varchar(max) out', @productVariantIds out
   
         	
        -----------------------------------------------------------------------------
       	-- Return all ids
        -----------------------------------------------------------------------------

       	select 	@productVariant as productVariant,
       		@productVariantIds as productVariantIds
 		
    END
  go

