

CREATE PROCEDURE [dbo].[TR_CheckOtherForChanges]
@internalRecordId int  -- Internal Record ID of Change Request
AS BEGIN

    -- TR_CheckOtherForChanges - Checks the Other data for the Product Variants in a Change Request
    -- for any changes.  Returns true if changes were found.
    --
    -- Change History
    -- 04/03/2019  MVT  Removed references to Technical Product, Technical Product to Constraint and Technical Product to Constraint Link
    -- 05/01/2019  MVT  Added Contact to Product Variant Link change and Staging Joins. Also added a check to see if changes were made to "Role of Contact"
    -- 10/21/2019  AR   Removed product_type and product_name check as both attributes were moved to product
    -- 01/17/2020  AR   Added in missing product variant attributes for scoping logic
    -- 06/22/2020  RJ   Removed Strategic attribute inorder to delete it from Profile as per TR request

    -- Example SQL:
    --
    --  EXEC TR_CheckOtherForChanges 5729772
    --
    -- Workflow Activity:
    --
    -- EXEC TR_CheckOtherForChanges %itemIds%

    -- Check if any Other data has changed.  If new Technical Produts to Technical Constraints are added, it will appear as a change

    select case when changedRows > 0 then 'true' else 'false' end as hasOtherChanges
    from (
             select count(*) as changedRows
             from Request_Change r
                      join Request_To_Product_Variant_Link_Change rpvl on r.Request_ID = rpvl.Request_ID
                      join PRODUCT_VARIANT_Change pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID
                      left outer join PRODUCT_VARIANT_Staging spv on pv.Product_Variant_ID = spv.Product_Variant_ID
                 --
                      left outer join CONTACT_TO_PRODUCT_VARIANT_LINK_Change cpvl on pv.Product_Variant_ID = cpvl.Product_Variant_ID
                      left outer join CONTACT_TO_PRODUCT_VARIANT_LINK_Staging scpvl on pv.Product_Variant_ID = scpvl.Product_Variant_ID
                  --
             where (
                         isnull(pv.Bridge_Eligibility,'') <> isnull(spv.Bridge_Eligibility,'')
                     or isnull(pv.Bundle_Type,'') <> isnull(spv.Bundle_Type,'')
                     or isnull(pv.Customer_Sales_Restriction, '') <> isnull(spv.Customer_Sales_Restriction, '')
                     or isnull(pv.Customer_Segment, '') <> isnull(spv.Customer_Segment, '')
                     or isnull(pv.External_Product_Description, '') <> isnull(spv.External_Product_Description, '')
                     or isnull(pv.Geographic_Sales_Restriction, '') <> isnull(spv.Geographic_Sales_Restriction, '')
                     or isnull(pv.Internal_Product_Description, '') <> isnull(spv.Internal_Product_Description, '')
                     or isnull(cast(pv.Launch_Date as VARCHAR), '') <> isnull(cast(spv.Launch_Date as VARCHAR), '')
                     or isnull(pv.Make_Royalty_Payments, '') <> isnull(spv.Make_Royalty_Payments, '')
                     or isnull(pv.Official_Product_Name,'') <> isnull(spv.Official_Product_Name,'')
                     or isnull(pv.Product_Delivery,'') <> isnull(spv.Product_Delivery,'')
                     or isnull(pv.Product_Id,0) <> isnull(spv.Product_Id,0)
                     or isnull(pv.Product_Language, '') <> isnull(spv.Product_Language, '')
                     or isnull(pv.Product_Sale_Status, '') <> isnull(spv.Product_Sale_Status, '')
                     or isnull(pv.Product_Variant_GUID,'') <> isnull(spv.Product_Variant_GUID,'')
                     or isnull(pv.Product_Version,'') <> isnull(spv.Product_Version,'')
                     or isnull(cast(pv.Proposed_End_of_Life_Date as VARCHAR), '') <> isnull(cast(spv.Proposed_End_of_Life_Date as VARCHAR), '')
                     or isnull(cast(pv.Proposed_Migration_Date as VARCHAR), '') <> isnull(cast(spv.Proposed_Migration_Date as VARCHAR), '')
                     or isnull(pv.Source_System,'') <> isnull(spv.Source_System,'')
                     or isnull(pv.Source_System_Product_ID,'') <> isnull(spv.Source_System_Product_ID,'')
                     or isnull(pv.Target_Audience, '') <> isnull(spv.Target_Audience, '')
                     --
                     or isnull(cpvl.Role_of_Contact, '') <> isnull(scpvl.Role_of_Contact, '')
                 --
                 )
               and r.InternalRecordId = @internalRecordId) v

END
go

