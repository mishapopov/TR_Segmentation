
CREATE PROCEDURE [dbo].[TR_GetIdsForRequestForCleanupById]
    @requestId VARCHAR(200),  -- Internal Record ID of the Request
    @source VARCHAR(10)	-- Name of source (Build, Clone, Change, State)
AS BEGIN

    -- TR_GetIdsForRequestForCleanupById - Retrieves the IDs of all linked records for the designated
    -- request record (by InternalRecordId) in the designated request pre-stage repository (Clone, Build, Change, or
    -- State).  Returns a commad-delimited list of all linked Ids of each repository.  If a repository has no
    -- linked records, return 'none' instead of the IDs.
    --
    -- Change History
    -- 04/03/2019  MVT  Removed references to Technical Product, Technical Product to Constraint and
    --                  Technical Product to Constraint Link, & Contact
    --
    -- Example SQL:
    --
    --  EXEC TR_GetIdsForRequestForCleanupById '5716042','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetIdsForRequestForCleanupById '%itemIds%','%source%'

    DECLARE @sql NVARCHAR(max)
    DECLARE @requestToProductVariantLink VARCHAR(max)
    DECLARE @productVariant VARCHAR(max)
    DECLARE @productVariantTax VARCHAR(max)
    DECLARE @productVariantNote VARCHAR(max)
    DECLARE @productVariantPrice VARCHAR(max)
    DECLARE @productVariantToProductVariantLink VARCHAR(max)
    DECLARE @contactToProductVariant VARCHAR(max)
    DECLARE @productVariantToTechnicalProduct VARCHAR(max)
    DECLARE @productVariantPriceTier VARCHAR(max)

    -----------------------------------------------------------------------------
    -- Get list of request to product variant link records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @requestToProductVariantLink = isnull(STUFF((select distinct '','' + cast(rpvl.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'requestToProductVariantLink - ' + @sql;
    exec sp_executesql @sql, N'@requestToProductVariantLink varchar(max) out', @requestToProductVariantLink out

    -----------------------------------------------------------------------------
    -- Get list of product variant records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariant = isnull(STUFF((select distinct '','' + cast(pv.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariant - ' + @sql;
    exec sp_executesql @sql, N'@productVariant varchar(max) out', @productVariant out

    -----------------------------------------------------------------------------
    -- Get list of product variant price records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantPrice = isnull(STUFF((select distinct '','' + cast(pvp.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantPrice - ' + @sql;

    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantPrice varchar(max) out', @productVariantPrice out
    END TRY
    BEGIN CATCH
        set @productVariantPrice = 'none';
    END CATCH

    -- Get list of product variant price Tier records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantPriceTier = isnull(STUFF((select distinct '','' + cast(pvpt.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_PRICE_' + @source + ' pvp on pvp.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' pvpt on pvpt.Product_Price_ID = pvp.Product_Price_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantPriceTier - ' + @sql;

    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantPriceTier varchar(max) out', @productVariantPriceTier out
    END TRY
    BEGIN CATCH
        set @productVariantPriceTier = 'none';
    END CATCH


    -----------------------------------------------------------------------------
    -- Get list of product variant tax records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantTax = isnull(STUFF((select distinct '','' + cast(pvt.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_TAX_' + @source + ' pvt on pvt.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantTax - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantTax varchar(max) out', @productVariantTax out
    END TRY
    BEGIN CATCH
        set @productVariantTax = 'none';
    END CATCH

    -----------------------------------------------------------------------------
    -- Get list of product variant note records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantNote = isnull(STUFF((select distinct '','' + cast(pvn.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_NOTE_' + @source + ' pvn on pvn.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantNote - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantNote varchar(max) out', @productVariantNote out
    END TRY
    BEGIN CATCH
        set @productVariantNote = 'none';
    END CATCH

    -----------------------------------------------------------------------------
    -- Get list of product variant to product variant link records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantToProductVariantLink = isnull(STUFF((select distinct '','' + cast(pvpvl.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_' + @source + ' pvpvl on pvpvl.From_Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantToProductVariantLink - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantToProductVariantLink varchar(max) out', @productVariantToProductVariantLink out
    END TRY
    BEGIN CATCH
        set @productVariantToProductVariantLink = 'none';
    END CATCH

    -----------------------------------------------------------------------------
    -- Get list of contact to product variant records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @contactToProductVariant = isnull(STUFF((select distinct '','' + cast(cpvl.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join CONTACT_TO_PRODUCT_VARIANT_LINK_' + @source + ' cpvl on cpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'contactToProductVariant - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@contactToProductVariant varchar(max) out', @contactToProductVariant out
    END TRY
    BEGIN CATCH
        set @contactToProductVariant = 'none';
    END CATCH



    -----------------------------------------------------------------------------
    -- Get list of product variant to technical product records
    -----------------------------------------------------------------------------

    set @sql = 'SELECT @productVariantToTechnicalProduct = isnull(STUFF((select distinct '','' + cast(pvtpl.InternalRecordId as VARCHAR) as [text()] ' +
               'from Request_' + @source + ' r ' +
               'join Request_To_Product_Variant_Link_' + @source + ' rpvl on r.Request_ID = rpvl.Request_Id ' +
               'join PRODUCT_VARIANT_' + @source + ' pv on rpvl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'join PRODUCT_VARIANT_TO_TECHNICAL_PRODUCT_LINK_' + @source + ' pvtpl on pvtpl.Product_Variant_ID = pv.Product_Variant_ID ' +
               'where r.InternalRecordId = ' + @requestId + ' FOR XML PATH('''')), 1, 1, ''''), ''none'')  ';
    print 'productVariantToTechnicalProduct - ' + @sql;
    -- Catch errors in case repository doesn't exist
    BEGIN TRY
        exec sp_executesql @sql, N'@productVariantToTechnicalProduct varchar(max) out', @productVariantToTechnicalProduct out
    END TRY
    BEGIN CATCH
        set @productVariantToTechnicalProduct = 'none';
    END CATCH

    -----------------------------------------------------------------------------
    -- Return all ids
    -----------------------------------------------------------------------------

    select @requestToProductVariantLink as requestToProductVariantLink,
           @productVariant as productVariant,
           @productVariantTax as productVariantTax,
           @productVariantNote as productVariantNote,
           @productVariantPrice as productVariantPrice,
           @productVariantPriceTier as productVariantPriceTier,
           @productVariantToProductVariantLink as productVariantToProductVariantLink,
           @contactToProductVariant as contactToProductVariant,
           @productVariantToTechnicalProduct as productVariantToTechnicalProduct

END
go

