CREATE VIEW dbo.[Automated Sort Node] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1000512 AS [Export_MergeSort_Template], F_1000513 AS [Pre_Populate_Sort_Attributes], F_1000514 AS [Sort_Spec_ID], F_1000515 AS [Taxonomy_Node_ID], F_1000516 AS [Taxonomy_Node_Name] FROM dbo.B_SNAPSHOT_10028 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

