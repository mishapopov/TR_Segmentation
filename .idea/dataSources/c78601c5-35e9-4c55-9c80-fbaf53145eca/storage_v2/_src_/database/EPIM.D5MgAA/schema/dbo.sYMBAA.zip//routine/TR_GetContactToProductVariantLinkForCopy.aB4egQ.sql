
  CREATE PROCEDURE [dbo].[TR_GetContactToProductVariantLinkForCopy]
  	@itemIds VARCHAR(200),  -- Delimited list of source product variants
  	@savedSetId int,	-- Saved set ID of source product variants
  	@source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
  	@target VARCHAR(10)	-- Name of target (Clone, Change, State)
    AS BEGIN
    
        -- TR_GetContactToProductVariantLinkForCopy - Retrieves the source and target Contact To Product Variant Link
        -- records for the specified list of Product Variant Item IDs or the saved set from the designated source 
        -- repository to be copied to the designated target repository.  Returns the internal record Id of each 
        -- source Contact To Product Variant Link record along with the Internal Record Id of the corresponding 
        -- target Contact To Product Variant Link record (or null if it doesn't exist).  Not to be used for cloning
        -- as cloning will need new IDs for all cloned records.
        -- 
        --
        --
        -- Example SQL: 
        --
        --  EXEC TR_GetContactToProductVariantLinkForCopy '5707059,5707061,5707054,5707055,5707056',null,'Staging','Change'
        --
        --  EXEC TR_GetContactToProductVariantLinkForCopy null,10548,'Staging','Change'
		--
        -- Workflow Activity:
        --
        -- EXEC TR_GetContactToProductVariantLinkForCopy '%itemIds%',%savedSetId%,'Staging','Change'
        
        DECLARE @sql VARCHAR(max)
        
        -- Determine if saved set was specified
        
        IF @savedSetId IS NULL
        BEGIN
        	-- No code set - use itemIds
        	SET @sql = 'SELECT scpvl.InternalRecordId as source, tcpvl.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'JOIN CONTACT_TO_PRODUCT_VARIANT_LINK_' + @source + ' scpvl on scpvl.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN CONTACT_TO_PRODUCT_VARIANT_LINK_' + @target + ' tcpvl ON tcpvl.Contact_To_Product_Variant_Link_ID = scpvl.Contact_To_Product_Variant_Link_ID ' +
        		'WHERE spv.InternalRecordId in (' + @itemIds + ')'
        END
        ELSE
        BEGIN
        	-- Code set - use it
        	SET @sql = 'SELECT scpvl.InternalRecordId as source, tcpvl.InternalRecordId as target ' +
        		'FROM PRODUCT_VARIANT_' + @source + ' spv ' +
        		'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spv.InternalRecordId ' +
        		'JOIN CONTACT_TO_PRODUCT_VARIANT_LINK_' + @source + ' scpvl on scpvl.Product_Variant_ID = spv.Product_Variant_ID ' +
        		'LEFT OUTER JOIN CONTACT_TO_PRODUCT_VARIANT_LINK_' + @target + ' tcpvl ON tcpvl.Contact_To_Product_Variant_Link_ID = scpvl.Contact_To_Product_Variant_Link_ID ' +
        		'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR) 
        END

       	print @sql
       	EXECUTE (@sql)
 		
    END
  go

