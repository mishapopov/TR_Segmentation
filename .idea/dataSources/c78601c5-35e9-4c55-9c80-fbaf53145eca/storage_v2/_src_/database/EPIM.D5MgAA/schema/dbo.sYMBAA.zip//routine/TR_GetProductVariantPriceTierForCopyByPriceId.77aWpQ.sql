
CREATE PROCEDURE [dbo].[TR_GetProductVariantPriceTierForCopyByPriceId]
    @itemIds VARCHAR(200),  -- Delimited list of source product variants
    @savedSetId int,	-- Saved set ID of source product variants
    @source VARCHAR(10),	-- Name of source (Staging, Clone, Change)
    @target VARCHAR(10)	-- Name of target (Clone, Change, State)
AS BEGIN

    -- TR_GetProductVariantPriceTierForCopyByPriceId - Retrieves the source and target Product Variant Price Tier records
    -- for the specified list of Product Variant Price IDs or the saved set from the designated source repository
    -- to be copied to the designated target repository.  Returns the internal record Id of each
    -- source Product Variant Price Tier record along with the Internal Record Id of the corresponding
    -- target Product Variant Price Tier record (or null if it doesn't exist).  Not to be used for cloning
    -- as cloning will need new IDs for all cloned records.
    --
    -- Example SQL:
    --
    --  EXEC EXEC TR_GetProductVariantPriceForCopyByPriceId '6318181,6318166,6318164',null,'Change','Staging'
    --
    --  EXEC TR_GetProductVariantPriceTierForCopyByPriceId null,10548,'Staging','Change'
    --
    -- Workflow Activity:
    --
    -- EXEC TR_GetProductVariantPriceForCopy '%itemIds%',%savedSetId%,'Staging','Change'

    DECLARE @sql VARCHAR(max)

    -- Determine if saved set was specified

    IF @savedSetId IS NULL
        BEGIN
            -- No code set - use itemIds
            SET @sql = 'select spvpt.InternalRecordId as source, tpvpt.InternalRecordId as target ' +
                       'FROM PRODUCT_VARIANT_PRICE_' + @source + ' spvp ' +
                       'join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' spvpt on spvpt.Product_Price_ID = spvp.Product_Price_ID ' +
                       'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_TIER_' + @target + ' tpvpt ON tpvpt.Price_Tier_ID = spvpt.Price_Tier_ID ' +
                       'WHERE spvp.InternalRecordId in (' + @itemIds + ')'
        END
    ELSE
        BEGIN
            -- Code set - use it
            SET @sql = 'select spvpt.InternalRecordId as source, tpvpt.InternalRecordId as target ' +
                       'FROM PRODUCT_VARIANT_PRICE_' + @source + ' spvp ' +
                       'JOIN B_SAVED_SET_ITEM ssi on ssi.ITEM_ID = spvp.InternalRecordId ' +
                       'join PRODUCT_VARIANT_PRICE_TIER_' + @source + ' spvpt on spvpt.Product_Price_ID = spvp.Product_Price_ID ' +
                       'LEFT OUTER JOIN PRODUCT_VARIANT_PRICE_TIER_' + @target + ' tpvpt ON tpvpt.Price_Tier_ID = spvpt.Price_Tier_ID ' +
                       'WHERE ssi.SAVED_SET_ID = ' + CAST(@savedSetId as VARCHAR)
        END

    print @sql
    EXECUTE (@sql)

END
go

