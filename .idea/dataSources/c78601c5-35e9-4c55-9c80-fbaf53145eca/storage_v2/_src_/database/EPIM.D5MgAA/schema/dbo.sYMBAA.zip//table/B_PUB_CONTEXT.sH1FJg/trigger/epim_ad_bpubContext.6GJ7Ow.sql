CREATE TRIGGER epim_ad_bpubContext ON B_PUB_CONTEXT
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = pub_context_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BpubContext', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BpubContext', @obj_id;
    END
go

