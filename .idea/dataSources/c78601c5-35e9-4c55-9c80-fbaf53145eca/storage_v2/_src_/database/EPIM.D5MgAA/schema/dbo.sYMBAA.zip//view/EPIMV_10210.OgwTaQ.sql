create view EPIMV_10210 as select ID, PLT_10212."F_10348" as F_1000427, PLT_10212."F_1" as F_1000426 from PLT_10212
go

