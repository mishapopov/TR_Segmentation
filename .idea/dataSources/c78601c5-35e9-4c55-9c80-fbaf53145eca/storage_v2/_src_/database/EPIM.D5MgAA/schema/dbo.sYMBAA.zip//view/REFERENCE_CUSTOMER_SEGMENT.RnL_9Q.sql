CREATE VIEW dbo.[REFERENCE_CUSTOMER_SEGMENT] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004450 AS [EPM_Reference_Code], F_1004451 AS [System_Name], F_1004452 AS [Value] FROM dbo.B_SNAPSHOT_10144 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_CUSTOMER_SEGMENT to dbadmin
go

grant select on REFERENCE_CUSTOMER_SEGMENT to ewsys
go

grant select on REFERENCE_CUSTOMER_SEGMENT to boomi
go

grant select on REFERENCE_CUSTOMER_SEGMENT to informatica
go

grant select on REFERENCE_CUSTOMER_SEGMENT to som
go

grant select on REFERENCE_CUSTOMER_SEGMENT to apttus
go

grant select on REFERENCE_CUSTOMER_SEGMENT to epmdev
go

grant select on REFERENCE_CUSTOMER_SEGMENT to MDMAdmin
go

grant select on REFERENCE_CUSTOMER_SEGMENT to produser1
go

grant select on REFERENCE_CUSTOMER_SEGMENT to produser3
go

grant select on REFERENCE_CUSTOMER_SEGMENT to produser2
go

grant select on REFERENCE_CUSTOMER_SEGMENT to VIEW_ACCESS
go

grant select on REFERENCE_CUSTOMER_SEGMENT to integration_team
go

grant select on REFERENCE_CUSTOMER_SEGMENT to ecmxread
go

grant select on REFERENCE_CUSTOMER_SEGMENT to MPOPOV_TEST
go

grant select on REFERENCE_CUSTOMER_SEGMENT to digital
go

