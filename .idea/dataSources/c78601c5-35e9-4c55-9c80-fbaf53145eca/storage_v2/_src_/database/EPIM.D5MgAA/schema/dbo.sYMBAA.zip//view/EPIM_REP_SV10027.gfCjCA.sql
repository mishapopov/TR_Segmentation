create view [dbo].[EPIM_REP_SV10027] as select  item_id, repository_id, has_error_ind, sync_action,  sync_action_delete, is_duplicate, record_state,  production_state, workflow_state, message_id, transaction_id, state_update_time, state_update_msg,   CAST(attr_data.query('data(Item/F_1000504)') as varchar(MAX))  as F_1000504,  CAST(attr_data.query('data(Item/F_1000505)') as nvarchar(MAX))  as F_1000505,  CAST(attr_data.query('data(Item/F_1000506)') as nvarchar(MAX))  as F_1000506,  CAST(attr_data.query('data(Item/F_1000507)') as varchar(MAX))  as F_1000507,  CAST(attr_data.query('data(Item/F_1000508)') as nvarchar(MAX))  as F_1000508,  CAST(attr_data.query('data(Item/F_1000509)') as varchar(MAX))  as F_1000509,  CAST(attr_data.query('data(Item/F_1000510)') as nvarchar(MAX))  as F_1000510,  CAST(attr_data.query('data(Item/F_1000511)') as varchar(MAX))  as F_1000511 from b_master_repository_item bmri where bmri.repository_id = 10027

go

grant select on EPIM_REP_SV10027 to boomi
go

