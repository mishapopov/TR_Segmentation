
CREATE FUNCTION epim_ltrim(@str nvarchar(MAX)) RETURNS nvarchar(MAX)
AS
BEGIN
DECLARE @trimchars nvarchar(10)
SET @trimchars = CHAR(9)+CHAR(10)+CHAR(13)+CHAR(32)
if (@str is not null)
begin
    IF @str LIKE '[' + @trimchars + ']%' SET @str = SUBSTRING(@str, PATINDEX('%[^' + @trimchars + ']%', @str), 8000)
end
RETURN @str
END
go

