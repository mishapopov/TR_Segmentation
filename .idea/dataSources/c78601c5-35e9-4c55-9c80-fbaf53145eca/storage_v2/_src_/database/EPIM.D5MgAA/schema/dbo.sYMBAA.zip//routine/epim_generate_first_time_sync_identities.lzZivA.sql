
Create Procedure epim_generate_first_time_sync_identities ( 
		@tableName varchar(50),
		@tp_id int,
		@numItems int,
        @gtinPrefix varchar(50) = ''		) 
As
    BEGIN
    	declare @strCmd varchar(1000);
    	declare @itemSql nvarchar(max);
    	declare @gtin_value varchar(50);
    	declare @num int;

	SET @num = 1;
	SET @strCmd = 'IF EXISTS (SELECT * FROM sysobjects WHERE name = ''' + @tableName + '_IDENT'' AND type = ''U'') DROP TABLE ' + @tableName + '_IDENT';
	--print @strCmd;
	execute (@strCmd);
	
	SET @strCmd = 'create table ' + @tableName + '_IDENT (epimv_id int, identity_val nvarchar(500))';
	execute (@strCmd);
	
	WHILE @num <= @numItems
        BEGIN
           SET @gtin_value = null;
           EXEC dbo.epim_auto_sequence  @gtin_value = @gtin_value OUTPUT, @tp_id = @tp_id 
           --print('gtin_value = ' + @gtin_value);
		   SET @gtin_value = @gtinPrefix + @gtin_value;

	   SET @strCmd = 'insert into ' + @tableName + '_IDENT values (' + cast(@num as nvarchar(50)) + ',''' + @gtin_value + ''') ';
	   --print('insert: ' + @strCmd);
	   execute (@strCmd);
	   SET @num = @num + 1;
	END

	return 0;
    END
go

