
CREATE PROCEDURE dbo.LockWorkflowActivity 
	@command NVARCHAR(10), 
	@activityName NVARCHAR(100), 
	@workItemId nvarchar(20),
	@expireMinutes int

--Returns a result set that indicates whether the requested acdtion was successful nor not
AS
BEGIN
    BEGIN TRAN
    DECLARE @lockStatus AS NVARCHAR(10)
    DECLARE @returnStatus AS NVARCHAR(10)
    DECLARE @attachCount as integer
    DECLARE @lockDate AS datetime
    DECLARE @count as integer
    DECLARE @newStatus AS NVARCHAR(10)
    SET @returnStatus = 'SUCCESS';
     
    -- Acquire lock to ensure only one caller is accessing table at one time
    EXEC sp_getapplock @Resource = @activityName, @Lockmode = 'Exclusive'

    if @command = 'LOCK'
    BEGIN
        -- Verify lock exists
        SELECT @count = count(*) from WorkflowLocks WHERE activityName = @activityName;
        if (@count = 0)
        BEGIN
            -- Lock doesn't exist - add it
            INSERT INTO WorkflowLocks values (@activityName,'','FREE',0,null);
        END
        -- Request for lock - check to see if lock is free
        SELECT @lockStatus = lockStatus, @lockDate = lockDate FROM WorkflowLocks WHERE activityName = @activityName;
         
        if @lockStatus = 'FREE' OR (@lockDate is not null and dateAdd(minute, @expireMinutes, @lockDate) < getDate())
        BEGIN
            -- Lock is currently free - acquire it
            UPDATE WorkflowLocks SET lockStatus = 'LOCKED', workItemId=@workItemId, attachCount=1, lockDate=getDate() WHERE activityName = @activityName;
        END
        ELSE
        BEGIN
            -- Lock is not free 
            SET @returnStatus = 'FAIL';
        END
    END
    ELSE
    BEGIN
        if @command = 'ATTACH'
        BEGIN
            -- Attach to lock if not free (acquire if not locked).  
            -- Verify lock exists
            SELECT @count = count(*) from WorkflowLocks WHERE activityName = @activityName;
            if (@count = 0)
            BEGIN
                -- Lock doesn't exist - add it
                INSERT INTO WorkflowLocks values (@activityName,'','FREE',0,null);
            END
            -- Request for lock - get current attach count
            SELECT @lockStatus = lockStatus, @attachCount = attachCount, @lockDate = lockDate FROM WorkflowLocks WHERE activityName = @activityName;
         
            -- Increment attach count & make sure status is locked
            UPDATE WorkflowLocks SET lockStatus = 'LOCKED', workItemId=@workItemId, attachCount = @attachCount + 1, lockDate=getDate() WHERE activityName = @activityName;
        END
        ELSE
        BEGIN
            if @command = 'FREE'
            BEGIN
                -- Free lock - make sure this work item Id owns the lock
                DECLARE @lockedWorkItemId AS NVARCHAR(20)
                SELECT @lockedWorkItemId = workItemId, @attachCount = attachCount FROM WorkflowLocks WHERE activityName = @activityName
                SET @attachCount = @attachCount - 1
                SET @newStatus = 'LOCKED'
                if @lockedWorkItemId = @workItemId OR @workItemId = '*'
                BEGIN
                    -- Owner of the lock - free only if no more attached
                    if @attachCount <= 0
                    BEGIN
            
                        -- Change status to FREE
                        SET @newStatus = 'FREE'
                        SET @attachCount = 0
                    END
                    -- Update lock
                    UPDATE WorkflowLocks SET lockStatus = @newStatus, workItemId='0', attachCount = @attachCount WHERE activityName = @activityName
                END
                ELSE
                BEGIN
                    -- Not owner of lock
                    SET @returnStatus = 'FAIL';
                END
            END
            ELSE
            BEGIN
                -- Detach lock - reduce count by 1
                SELECT @attachCount = attachCount FROM WorkflowLocks WHERE activityName = @activityName
                SET @attachCount = @attachCount - 1
                SET @newStatus = 'LOCKED'
                -- Owner of the lock - free only if no more attached
                if @attachCount <= 0
                BEGIN
            
                    -- Change status to FREE
                    SET @newStatus = 'FREE'
                    SET @attachCount = 0
                END
                -- Update lock
                UPDATE WorkflowLocks SET lockStatus = @newStatus, attachCount = @attachCount WHERE activityName = @activityName
            END
        END
    END
    -- Free the lock
    EXEC sp_releaseapplock @Resource = @activityName
    COMMIT
    SELECT @returnStatus AS Status
END
go

