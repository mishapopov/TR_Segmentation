
CREATE procedure [dbo].[epim_pending_request_import_delete] (
      @pendingImportTableName nvarchar(255),
      @repositoryId int,
      @approvalRequiredInd int,
      @numRequests int out,
      @numRequestDetails int out,
      @numRequestAttrs int out,
      @numRequestErrors int out,
      @numRequestItemErrors int out,
      @numRequestAttrErrors int out
       )
As
BEGIN
    DECLARE @sql          NVARCHAR(4000)
    DECLARE @profileId    bigint
    DECLARE @numPriKeys   INT
    DECLARE @numRequests1 INT
    DECLARE @numRequests2 INT
    DECLARE @numRequests3 INT
    DECLARE @numRequests4 INT
    DECLARE @numRequestDetails1   INT
    DECLARE @numRequestDetails2   INT
    DECLARE @numRequestDetails3   INT
    DECLARE @numRequestDetails4   INT
    DECLARE @numRequestAttrs1   INT
    DECLARE @numRequestAttrs2   INT
    DECLARE @numRequestAttrs3   INT
    DECLARE @numRequestAttrs4   INT

    -- initialize the key columns in the pendingImportTableName
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET ITEM_ID = NULL, FORMAT_ATTR_ID = NULL, REPOSITORY_ID = NULL, CREATED_BY = NULL, ERROR_IND = 0, RequestId = NULL,  ' +
    		'RequestDetailId = NULL,[USER_ERROR]=0,[REPO_ERROR]=0,[ATTR_ERROR]=0,[ITEM_ERROR]=0,[REQUEST_ERROR]=0,[DETAIL_ERROR]=0';
    EXECUTE (@sql);
    
    -- Get the profile ID
    SELECT @profileId = profile_id from b_master_repository where master_repository_id = @repositoryId;

    -- Get the number of primary keys
    SELECT @numPriKeys = count(*) from b_format_attr where profile_id=@profileId and pkey_seq_num > 0;

    -- Update the UserId    
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET CREATED_BY = B_USER.USER_ID FROM ' + @pendingImportTableName + ' INNER JOIN ' +
    		'B_USER ON ' + @pendingImportTableName + '.CREATED_BY_LOGIN = B_USER.LOGIN';
    EXECUTE (@sql);

    -- Update the UserId    
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET CREATED_BY = 0 WHERE CREATED_BY_LOGIN = ''NOTNULL'' ';
    EXECUTE (@sql);

    -- Update the RepositoryId    
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET REPOSITORY_ID = B_MASTER_REPOSITORY.MASTER_REPOSITORY_ID FROM ' + 
    		@pendingImportTableName + ' INNER JOIN B_MASTER_REPOSITORY ON ' + @pendingImportTableName + '.REPOSITORY_NAME = ' +
    		'B_MASTER_REPOSITORY.NAME';
    EXECUTE (@sql);

    -- Update the ItemId    
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID FROM ' + @pendingImportTableName + 
    		', B_MASTER_REPOSITORY_ITEM WHERE ' + @pendingImportTableName + '.PKEY1 = B_MASTER_REPOSITORY_ITEM.PK_COL_1 AND ' +
    		'B_MASTER_REPOSITORY_ITEM.REPOSITORY_ID = ' + CAST(@repositoryId as varchar(MAX));
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + 'AND ' + @pendingImportTableName + '.PKEY2 = B_MASTER_REPOSITORY_ITEM.PK_COL_2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + 'AND ' + @pendingImportTableName + '.PKEY3 = B_MASTER_REPOSITORY_ITEM.PK_COL_3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + 'AND ' + @pendingImportTableName + '.PKEY4 = B_MASTER_REPOSITORY_ITEM.PK_COL_4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + 'AND ' + @pendingImportTableName + '.PKEY5 = B_MASTER_REPOSITORY_ITEM.PK_COL_5 ';
    EXECUTE (@sql);
    
    -- Set rows to error if No Create By Id
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET ERROR_IND = 1,[USER_ERROR]=1 WHERE (CREATED_BY IS NULL)';
    EXECUTE (@sql);
    
    -- Set rows to error if No Repository Id
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET ERROR_IND = 1,[REPO_ERROR]=1 WHERE (REPOSITORY_ID IS NULL)';
    EXECUTE (@sql);

    -- Set rows to error if No Item Id
    SET @sql = 'UPDATE ' + @pendingImportTableName + ' SET ERROR_IND = 1,[ITEM_ERROR]=1 WHERE (ITEM_ID IS NULL)';
    EXECUTE (@sql);


	--no user and all pending request name
    -- delete pending request attrs    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_ATTR FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID INNER JOIN ' +
               'B_PENDING_REQUEST_ATTR ON B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) ) '
	PRINT 'no user and all pending request delete all attrs'
	PRINT @sql
	exec sp_executesql @sql
	set @numRequestAttrs4=@@rowcount
	print CAST(@numRequestAttrs4 as VARCHAR(max))

    -- delete pending request details    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_DETAIL FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) ) '
	PRINT 'no user and all pending request delete all details'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequestDetails4=@@rowcount
	print CAST(@numRequestDetails4 as VARCHAR(max))

    -- delete pending request repos    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_REPO WHERE MASTER_REPOSITORY_ID =  ' + cast(@repositoryId as varchar) +
			   ' AND PENDING_REQUEST_ID not in (select PENDING_REQUEST_ID from B_PENDING_REQUEST_DETAIL)'
    PRINT 'delete unreferenced pendingRequestRepo entries'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests1=@@rowcount
	print CAST(@numRequests1 as VARCHAR(max))

    -- delete pending request    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST FROM B_PENDING_REQUEST LEFT OUTER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE (B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID IS NULL) AND ' +
			   'EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) ) '
	PRINT 'no user and all pending request delete all requests'    
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests4=@@rowcount
	print CAST(@numRequests4 as VARCHAR(max))

	--no user and pending request name
    -- delete pending request attrs    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_ATTR FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID INNER JOIN ' +
               'B_PENDING_REQUEST_ATTR ON B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
	PRINT 'no user and specific pending request delete all attrs'
	PRINT @sql
	exec sp_executesql @sql
	set @numRequestAttrs3=@@rowcount
	print CAST(@numRequestAttrs3 as VARCHAR(max))

    -- delete pending request details    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_DETAIL FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
	PRINT 'no user and specific pending request delete all details'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequestDetails3=@@rowcount
	print CAST(@numRequestDetails3 as VARCHAR(max))

    -- delete pending request repos    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_REPO WHERE MASTER_REPOSITORY_ID =  ' + cast(@repositoryId as varchar) +
			   ' AND PENDING_REQUEST_ID not in (select PENDING_REQUEST_ID from B_PENDING_REQUEST_DETAIL)'
    PRINT 'delete unreferenced pendingRequestRepo entries'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests1=@@rowcount
	print CAST(@numRequests1 as VARCHAR(max))

    -- delete pending requests    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST FROM B_PENDING_REQUEST LEFT OUTER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE (B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID IS NULL) AND ' +
			   'EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(CREATED_BY = 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
	PRINT 'no user and specific pending request delete all requests'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests3=@@rowcount
	print CAST(@numRequests3 as VARCHAR(max))

	--Specific user and all pending request name
    -- delete pending request attrs    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_ATTR FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID INNER JOIN ' +
               'B_PENDING_REQUEST_ATTR ON B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) ) '
	PRINT 'Specific user and all pending request delete all attrs'
	PRINT @sql
	exec sp_executesql @sql
	set @numRequestAttrs2=@@rowcount
	print CAST(@numRequestAttrs2 as VARCHAR(max))

    -- delete pending request details    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_DETAIL FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) ) '
	PRINT 'Specific user and all pending request delete all details'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequestDetails2=@@rowcount
	print CAST(@numRequestDetails2 as VARCHAR(max))

    -- delete pending request repos    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_REPO WHERE MASTER_REPOSITORY_ID =  ' + cast(@repositoryId as varchar) +
			   ' AND PENDING_REQUEST_ID not in (select PENDING_REQUEST_ID from B_PENDING_REQUEST_DETAIL)'
    PRINT 'delete unreferenced pendingRequestRepo entries'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests1=@@rowcount
	print CAST(@numRequests1 as VARCHAR(max))

    -- delete pending requests    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST FROM B_PENDING_REQUEST LEFT OUTER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE (B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID IS NULL) AND ' +
			   'EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME = ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) ) '
   	PRINT 'Specific user and all pending request delete all requests'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests2=@@rowcount
	print CAST(@numRequests2 as VARCHAR(max))

	--Specific user and pending request name
    -- delete pending request attrs    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_ATTR FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID INNER JOIN ' +
               'B_PENDING_REQUEST_ATTR ON B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_DETAIL_ID = B_PENDING_REQUEST_ATTR.PENDING_REQUEST_DETAIL_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
	PRINT 'Specific user and pending request delete all attrs'
	PRINT @sql
	exec sp_executesql @sql
	set @numRequestAttrs1=@@rowcount
	print CAST(@numRequestAttrs1 as VARCHAR(max))

    -- delete pending request details    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_DETAIL FROM B_PENDING_REQUEST INNER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND (B_PENDING_REQUEST_DETAIL.ITEM_ID = ITEM_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
    PRINT 'Specific user and pending request delete all details'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequestDetails1=@@rowcount
	print CAST(@numRequestDetails1 as VARCHAR(max))

    -- delete pending request repos    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST_REPO WHERE MASTER_REPOSITORY_ID =  ' + cast(@repositoryId as varchar) +
			   ' AND PENDING_REQUEST_ID not in (select PENDING_REQUEST_ID from B_PENDING_REQUEST_DETAIL)'
    PRINT 'delete unreferenced pendingRequestRepo entries'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests1=@@rowcount
	print CAST(@numRequests1 as VARCHAR(max))

    -- delete pending requests    
    SET @sql = 'DELETE FROM B_PENDING_REQUEST FROM B_PENDING_REQUEST LEFT OUTER JOIN B_PENDING_REQUEST_DETAIL ON ' +
			   'B_PENDING_REQUEST.PENDING_REQUEST_ID = B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID ' +
			   'WHERE (B_PENDING_REQUEST_DETAIL.PENDING_REQUEST_ID IS NULL) AND ' +
			   'EXISTS (SELECT 1 FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 0) AND ' +
			   '(CHANGE_REQUEST_NAME <> ''NOTNULL'') AND ' +
			   '(B_PENDING_REQUEST.CREATED_BY = CREATED_BY) AND (CREATED_BY > 0) AND ' +
			   '(B_PENDING_REQUEST.REPOSITORY_ID = REPOSITORY_ID) AND ' +
			   '(B_PENDING_REQUEST.NAME LIKE ''%'' + CHANGE_REQUEST_NAME + ''%'') ) '
    PRINT 'Specific user and pending request delete all requests'
    PRINT @sql
    exec sp_executesql @sql
	set @numRequests1=@@rowcount
	print CAST(@numRequests1 as VARCHAR(max))

	--update record state for all items
    SET @sql = 'UPDATE B_MASTER_REPOSITORY_ITEM SET RECORD_STATE = 2 FROM ' + @pendingImportTableName + ' AS prt INNER JOIN ' +
			   'B_MASTER_REPOSITORY_ITEM ON prt.ITEM_ID = B_MASTER_REPOSITORY_ITEM.ITEM_ID ' +
			   'WHERE (prt.ITEM_ID IS NOT NULL) AND (prt.ERROR_IND = 0) AND (B_MASTER_REPOSITORY_ITEM.RECORD_STATE = 0)	'
    PRINT 'Set item status to changed for all synced records'
    PRINT @sql
    EXECUTE (@sql);	

	SET @numRequestAttrs = (@numRequestAttrs1 + @numRequestAttrs2 + @numRequestAttrs3 + @numRequestAttrs4);
	SET @numRequestDetails = (@numRequestDetails1 + @numRequestDetails2 + @numRequestDetails3 + @numRequestDetails4);
	SET @numRequests = (@numRequests1 + @numRequests2 + @numRequests3 + @numRequests4);

     -- get count of pending request errors
    SET @sql = 'SELECT @numRequestErrors=count(*) FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 1) ';
    exec sp_executesql @sql, @params = N'@numRequestErrors int OUTPUT', @numRequestErrors = @numRequestErrors OUTPUT;

     -- get count of pending request details errors
    SET @sql = 'SELECT @numRequestItemErrors=count(*) from (select DISTINCT PKEY1 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + ', PKEY2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + ', PKEY3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + ', PKEY4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + ', PKEY5 ';
    SET @sql = @sql + ' FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 1) ) t1';
    exec sp_executesql @sql, @params = N'@numRequestItemErrors int OUTPUT', @numRequestItemErrors = @numRequestItemErrors OUTPUT;

     -- get count of pending request details attr errors
    SET @sql = 'SELECT @numRequestAttrErrors=count(*) from (select PKEY1, ATTR_NAME ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 1
        SET @sql = @sql + ', PKEY2 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 2 
        SET @sql = @sql + ', PKEY3 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 3
        SET @sql = @sql + ', PKEY4 ';
    if @numPriKeys IS NOT NULL AND @numPriKeys > 4
        SET @sql = @sql + ', PKEY5 ';
    SET @sql = @sql + ' FROM ' + @pendingImportTableName + ' WHERE (ERROR_IND = 1) ) t1';
    exec sp_executesql @sql, @params = N'@numRequestAttrErrors int OUTPUT', @numRequestAttrErrors = @numRequestAttrErrors OUTPUT;

END;
go

