CREATE VIEW dbo.[Product_Change_Request] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004484 AS [Change_product_ID], F_1004481 AS [Change_Request_ID], F_1004487 AS [Change_Request_Type], F_1004483 AS [Request_Date], F_1004482 AS [Requestor] FROM dbo.B_SNAPSHOT_10155 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on Product_Change_Request to boomi
go

grant select on Product_Change_Request to informatica
go

grant select on Product_Change_Request to som
go

grant select on Product_Change_Request to apttus
go

grant select on Product_Change_Request to epmdev
go

grant select on Product_Change_Request to ecmxread
go

grant select on Product_Change_Request to MPOPOV_TEST
go

grant select on Product_Change_Request to digital
go

