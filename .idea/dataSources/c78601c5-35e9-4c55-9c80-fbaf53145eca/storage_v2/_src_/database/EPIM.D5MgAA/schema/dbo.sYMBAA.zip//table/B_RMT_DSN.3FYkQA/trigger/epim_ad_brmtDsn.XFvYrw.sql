CREATE TRIGGER epim_ad_brmtDsn ON B_RMT_DSN
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = rmt_dsn_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BrmtDsn', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BrmtDsn', @obj_id;
    END
go

