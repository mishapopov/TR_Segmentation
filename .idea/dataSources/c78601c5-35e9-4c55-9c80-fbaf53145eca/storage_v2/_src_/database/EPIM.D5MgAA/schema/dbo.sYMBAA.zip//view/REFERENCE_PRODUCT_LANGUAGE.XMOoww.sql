CREATE VIEW dbo.[REFERENCE_PRODUCT_LANGUAGE] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004456 AS [EPM_Reference_Code], F_1004457 AS [System_Name], F_1004458 AS [Value] FROM dbo.B_SNAPSHOT_10234 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_PRODUCT_LANGUAGE to dbadmin
go

grant select on REFERENCE_PRODUCT_LANGUAGE to ewsys
go

grant select on REFERENCE_PRODUCT_LANGUAGE to boomi
go

grant select on REFERENCE_PRODUCT_LANGUAGE to informatica
go

grant select on REFERENCE_PRODUCT_LANGUAGE to som
go

grant select on REFERENCE_PRODUCT_LANGUAGE to apttus
go

grant select on REFERENCE_PRODUCT_LANGUAGE to epmdev
go

grant select on REFERENCE_PRODUCT_LANGUAGE to MDMAdmin
go

grant select on REFERENCE_PRODUCT_LANGUAGE to produser1
go

grant select on REFERENCE_PRODUCT_LANGUAGE to produser3
go

grant select on REFERENCE_PRODUCT_LANGUAGE to produser2
go

grant select on REFERENCE_PRODUCT_LANGUAGE to VIEW_ACCESS
go

grant select on REFERENCE_PRODUCT_LANGUAGE to integration_team
go

grant select on REFERENCE_PRODUCT_LANGUAGE to ecmxread
go

grant select on REFERENCE_PRODUCT_LANGUAGE to MPOPOV_TEST
go

grant select on REFERENCE_PRODUCT_LANGUAGE to digital
go

