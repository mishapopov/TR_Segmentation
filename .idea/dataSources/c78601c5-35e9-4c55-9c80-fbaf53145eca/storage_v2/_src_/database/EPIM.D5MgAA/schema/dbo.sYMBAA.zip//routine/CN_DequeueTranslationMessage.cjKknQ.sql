 
create procedure CN_DequeueTranslationMessage
as
  set nocount on;
/*
	CN_DequeueTranslationMessage - dequeues a message from the Change Notification Translation
	queue unless the message is to be dequeued only when the record is in-sync and the record is not
	in-sync.  Each qualifying record is first tagged so it can be retrieved and 
	subsequently deleted.

	Example call:
	
	EXEC CN_DequeueTranslationMessage
	
*/
  
  -- First flag the records to be dequeued
  UPDATE ChangeNotificationTranslationQueue set work_item_id=1 
  	from ChangeNotificationTranslationQueue cn
  	join B_MASTER_REPOSITORY_ITEM i on i.ITEM_ID = cn.internalRecordId
      where cn.dequeueInSyncOnly = 0 OR i.RECORD_STATE = 0
      
  -- Next, return the records
  
  select seqNumber, batchId, repositoryName, translationName, internalRecordId, attributeName, 
      oldTranslatedValue, newValue, changedBy, changedDatetime, languageExt, translateLanguageExt
      from ChangeNotificationTranslationQueue with (rowlock, readpast)
      where work_item_id=1 
      order by seqNumber
      
  -- Finally, remove the records from the queue
  
  delete from ChangeNotificationTranslationQueue where work_item_id=1
  
/*  with cte as (
    select top(1) 
      seqNumber, batchId, repositoryName, translationName, internalRecordId, attributeName, 
      oldTranslatedValue, newValue, changedBy, changedDatetime, languageExt, translateLanguageExt
      from ChangeNotificationTranslationQueue with (rowlock, readpast)
      order by seqNumber)
  delete from cte
    output deleted.seqNumber, deleted.batchId, deleted.repositoryName, deleted.translationName,
    deleted.internalRecordId, deleted.attributeName, 
      deleted.oldTranslatedValue, deleted.newValue, deleted.changedBy, deleted.changedDatetime,
      deleted.languageExt, deleted.translateLanguageExt;*/
go

