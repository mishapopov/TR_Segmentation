CREATE VIEW dbo.[PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004419 AS [From_Product_Variant_ID], F_1004709 AS [Is_Mandatory], F_1004600 AS [Product_Variant_To_Product_Variant_Link_ID], F_1004421 AS [Product_Variant_to_Product_Variant_Relationship_Type], F_1004559 AS [To_Product_Variant_ID] FROM dbo.B_SNAPSHOT_10197 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to boomi
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to informatica
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to som
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to apttus
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to epmdev
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to ecmxread
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to MPOPOV_TEST
go

grant select on PRODUCT_VARIANT_TO_PRODUCT_VARIANT_LINK_Clone to digital
go

