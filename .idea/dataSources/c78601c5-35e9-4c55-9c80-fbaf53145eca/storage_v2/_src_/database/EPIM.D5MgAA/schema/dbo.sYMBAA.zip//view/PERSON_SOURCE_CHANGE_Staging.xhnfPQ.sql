CREATE VIEW dbo.[PERSON_SOURCE_CHANGE_Staging] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004947 AS [Action], F_1004984 AS [Create_Date], F_1004992 AS [Employee_ID], F_1005039 AS [Source_Record_ID], F_1005040 AS [Source_Type_Code] FROM dbo.B_SNAPSHOT_10253 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on PERSON_SOURCE_CHANGE_Staging to dbadmin
go

grant select on PERSON_SOURCE_CHANGE_Staging to ewsys
go

grant select on PERSON_SOURCE_CHANGE_Staging to boomi
go

grant select on PERSON_SOURCE_CHANGE_Staging to informatica
go

grant select on PERSON_SOURCE_CHANGE_Staging to som
go

grant select on PERSON_SOURCE_CHANGE_Staging to apttus
go

grant select on PERSON_SOURCE_CHANGE_Staging to epmdev
go

grant select on PERSON_SOURCE_CHANGE_Staging to MDMAdmin
go

grant select on PERSON_SOURCE_CHANGE_Staging to produser1
go

grant select on PERSON_SOURCE_CHANGE_Staging to produser3
go

grant select on PERSON_SOURCE_CHANGE_Staging to produser2
go

grant select on PERSON_SOURCE_CHANGE_Staging to integration_team
go

grant select on PERSON_SOURCE_CHANGE_Staging to digital
go

