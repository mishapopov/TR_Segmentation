CREATE VIEW dbo.[REFERENCE_MULTI_YEAR_ELIGIBLE] AS SELECT s.ITEM_ID AS InternalRecordId, r.creation_datetime as [Created], r.last_update_datetime AS [Last_Updated], r.attr_last_update_datetime as [Data_Last_Updated], s.DATA_LAST_UPDATE_DATETIME as [Snapshot_Last_Updated], F_1004547 AS [EPM_Reference_Code], F_1004548 AS [System_Name], F_1004549 AS [Value] FROM dbo.B_SNAPSHOT_10173 s, dbo.B_MASTER_REPOSITORY_ITEM r WHERE s.item_id = r.item_id
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to dbadmin
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to ewsys
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to boomi
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to informatica
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to som
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to apttus
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to epmdev
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to MDMAdmin
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to produser1
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to produser3
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to produser2
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to VIEW_ACCESS
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to integration_team
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to ecmxread
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to MPOPOV_TEST
go

grant select on REFERENCE_MULTI_YEAR_ELIGIBLE to digital
go

