
/*
	CN_DequeueMessage - dequeues a message from the Change Notification queue unless the
	message is to be dequeued only when the record is in-sync and the record is not
	in-sync.  Each qualifying record is first tagged so it can be retrieved and 
	subsequently deleted.

	Example call:
	
	EXEC CN_DequeueMessage
	
*/
create procedure CN_DequeueMessage
as
BEGIN
  set nocount on;
  
  -- First flag the records to be dequeued
  UPDATE ChangeNotificationQueue set work_item_id=1 
  	from ChangeNotificationQueue cn
  	join B_MASTER_REPOSITORY_ITEM i on i.ITEM_ID = cn.internalRecordId
      where cn.dequeueInSyncOnly = '0' OR i.RECORD_STATE = 0
      
  -- Next, return the records
  
  select cn.seqNumber, cn.changeId, cn.registryId, cn.repositoryName, cn.internalRecordId, cn.attributeName, 
      cn.oldValue, cn.newValue, cn.changedby, cn.changedDatetime, cn.languageExt
      from ChangeNotificationQueue cn with (rowlock, readpast)
      where cn.work_item_id=1 
      order by cn.seqNumber
      
  -- Finally, remove the records from the queue
  
  delete from ChangeNotificationQueue where work_item_id=1
  
/*
with cte as (
    select top(1) 
      seqNumber, changeId, registryId, repositoryName, internalRecordId, attributeName, 
      oldValue, newValue, changedby, changedDatetime, languageExt
      from ChangeNotificationQueue  with (rowlock, readpast)
      join B_MASTER_REPOSITORY_ITEM i on i.ITEM_ID = internalRecordId
      where dequeueInSyncOnly = '0' OR i.RECORD_STATE = 0
      order by seqNumber)
  delete from cte
    output deleted.seqNumber, deleted.changeId, deleted.registryId, deleted.repositoryName, 
    deleted.internalRecordId, deleted.attributeName, 
      deleted.oldValue, deleted.newValue, deleted.changedby, deleted.changedDatetime,
      deleted.languageExt;
      */
END

go

