CREATE TRIGGER epim_ad_bpubContextGroup ON B_PUB_CONTEXT_GROUP
FOR DELETE
AS 
    BEGIN
	declare @obj_id int;
	declare @created_by_id int;

	set nocount on;

	-- retrieve the object that was deleted
	select @obj_id = pub_context_group_id from deleted;

	-- referential integrity: remove the object permissions
	EXEC epim_delete_obj_privs 'BpubContextGroup', @obj_id;
	-- referential integrity: remove the object languages
	EXEC epim_delete_obj_langs 'BpubContextGroup', @obj_id;
    END
go

