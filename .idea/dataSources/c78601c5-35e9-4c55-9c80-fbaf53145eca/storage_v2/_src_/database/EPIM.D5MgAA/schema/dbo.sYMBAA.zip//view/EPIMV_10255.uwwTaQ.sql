create view EPIMV_10255 as select ID, PLT_10257."F_12349" as F_1004366, PLT_10257."F_1" as F_1004364 from PLT_10257
go

