create view EPIMV_10374 as select ID, PLT_10376."F_12379" as F_1004398, PLT_10376."F_1" as F_1004406 from PLT_10376
go

